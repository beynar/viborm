# Retained-memory diagnostic — 2026-09-28

## Outcome

No accumulating operation state was observed in the shared engine on the
exercised SQLite paths. After 20,000 warmup operations, the current build ran
200,000 further operations with post-GC heap near 10 MiB. A separate 1,000-client
disposal run settled near 10.5 MiB. This is finite workload evidence, not proof
that every workload is leak-free.

One separate, pre-existing unbounded cache was confirmed in the client proxy.
Arnaud chose to keep this pass limited to the engine, so that cache is unchanged.
No production code changed in this diagnostic pass.

## Evidence

| Measurement | Observed result |
| --- | --- |
| Current build, warm heap → after 200,000 operations | 10.111 → 10.296 MiB |
| Previous build, same workload | 10.192 → 9.214 MiB |
| Sampled completed handles/results, current build | 420/420 collected during sequential soak; 336/336 after bounded overlap |
| Deliberately held 500 completed handles, each with 100 rows | 10.103 → 20.334 MiB |
| After releasing those handles | 10.204 MiB |
| 1,000 fresh clients after 50 warmup clients | 9.874 → 10.502 MiB; last 500-client window 10.446–10.512 MiB |
| Sampled disposed clients/drivers/database wrappers/models | 5,000/5,000 collected |
| Unknown client property names, current build | +7.686 MiB per 10,000 distinct names |

The comparison build is the engine-candidate baseline, which already includes
the first optimization pass. It is not the original HEAD baseline. These are
one diagnostic run per build, not a statistically powered performance ranking.
V8 compilation and collection vary between runs; the lower absolute previous
heap is not evidence of a regression in the current build.

Current-build RSS during the steady phase rose from 102.08 to 120.73 MiB and
leveled off near the end. External memory and array buffers were stable across
its checkpoints. The extended disposal run included heap snapshots: its RSS
rose from 98.34 to 290.47 MiB, then plateaued. That run cannot isolate normal RSS
behavior from snapshot overhead. The before/after snapshot node summaries show
growth mainly in V8 code metadata; they are not a dominator/retainer analysis.

Raw evidence: [current.json](current.json), [baseline.json](baseline.json),
[lifecycle-1000.json](lifecycle-1000.json), [summary.json](summary.json).
The bounded launchers report 8.81 seconds / 174.9 MiB group RSS for the current
mixed run and 2.34 seconds / 341.5 MiB for the extended disposal run. Each
verified whole-group teardown. Group RSS includes coordinator and worker;
checkpoint RSS describes only the worker.

## Protocol and identity

The harness uses the stock owned SQLite3 transport with 100 users and 1,000
posts in a private in-memory database. Row counts remain fixed. Every block
mixes unique/missing reads with varying parameter values, filtered reads with
two projections, full scalar rows, nested author results, updates to existing
rows, and validation rejections. Successful operations check basic result
invariants; every rejected operation must be a ValidationError. This is not an
exhaustive correctness suite.

Each checkpoint yields to the event loop, forces GC, yields again, and forces
GC again. It samples process memory before dereferencing the sampled WeakRefs.
The harness keeps numeric checkpoint records and a bounded number of weak
references. It releases ordinary results and handles before collection. A
32-way overlapping batch covers 192 extra operations; it is not a sustained
concurrency load test. GC forcing is a diagnostic technique, not application
behavior to ship.

Client lifetime checks create a fresh schema, client, driver and database each
time, exercise all six operation cases, and disconnect. The first 100-client
run showed a small upward trend; the extended run was necessary to distinguish
continued growth from warmup. Sampled models were added to that extended run.

The positive control holds completed pending handles, rather than only result
rows, to test the graph a caller can retain. It then clears the array and
collects again. An initial harness setup attempt failed because the fixture
insert had six placeholders for five columns. It produced no memory evidence;
the placeholder count was corrected before the measured runs. Its failure log
is preserved as `fixture-setup-failed.log`.

- Runtime: Node 24.21.0 / V8 13.6.233.17-node.53, macOS arm64, Apple M4 Pro.
- Current build SHA-256: `1fd1b895b89ad4e56ea55cd737251b423c4b7a678f108158369a95305fd2eff2`.
- Previous build SHA-256: `e7931d3ba0b67605b6bd63c21933cc27e63f8387f0d672a9d197ba5ab69f2205`.
- Source/build provenance: [engine-candidates manifest](../engine-candidates/manifest.json).
- Exact measured harnesses: [initial-harness.mjs](initial-harness.mjs) and
  [lifecycle-harness.mjs](lifecycle-harness.mjs), kept as evidence snapshots.
  The executable benchmark preserves the measured workload; subsequent Biome
  cleanup only reordered imports/worker branches, formatted code, and added
  failure assertions for unreachable operation indices.
- This folder's [manifest](manifest.json) seals its evidence and the final
  executable harness. The large heap snapshots remain local under `/tmp`;
  `summary.json` records their paths and hashes plus aggregate node counts.

Run the executable from the repository root through the commands in
[benchmarks/README.md](../../../../benchmarks/README.md). It uses the existing
build; build first only if production source has changed.

## Ownership audit

`PreparedCommand` and `RoutedOperation` share methods through factory-scoped
prototypes. Neither factory keeps a registry of its instances. Their closures
retain engine infrastructure, not past operations. Readers and explicit
projections remain operation-local.

`EngineSchema` caches schema/adapter facts: physical fields, memberships,
clearability, scalar leaves and default projections. For a fixed schema and
adapter, these have a finite key space. Query values and explicit projection
combinations are not cache keys.

`PendingExecution` deliberately retains its settled promise for repeat awaits;
`PendingOperation` also retains its arguments and prepared state. If the caller
keeps completed handles, it keeps those graphs and their results or errors
alive. Clearing that state automatically would need contract analysis; there
is no need for such a change based on this evidence.

The confirmed unbounded path is `src/client/client.ts:createModelProxy`.
Its strong `children` Map accepts every string property except `then`, even
undeclared names and arbitrary deeper paths. A loop reading
`client.user["unknown_" + i]` added about 15.37 MiB after 20,000 unique names,
with no queries executed. The previous build exhibits the same growth. Ordinary
typed operation names use a finite set. Restricting memoization to declared
model and supported operation names is a proposed follow-up, not implemented.

## How to keep the guarantee meaningful

1. Keep operation inputs, prepared state and decoded results owned by their
   operation; share only metadata whose key space and lifetime are bounded.
   A WeakMap does not bound the contents stored under a still-live key.
2. Rerun this small diagnostic after changing engine allocation, cache ownership
   or lifecycle behavior. Inspect post-warmup heap trends and collection of
   sampled objects, alongside the deliberate retained-handle control. Do not
   turn a single machine's exact MiB value into a brittle CI threshold.
3. If a repeatable slope appears, isolate the growing case and compare heap
   snapshots to identify its retaining path. Post-GC live heap, external memory
   and RSS answer different questions; follow native allocations when RSS grows
   while JavaScript live heap is stable.
4. Cover extension/result-cache configurations and realistic bounded concurrency
   separately before claiming those paths are bounded. Unbounded in-flight work,
   caller-held histories and growing databases are outside this fixed-load soak.

No all-provider suite, full typecheck or rebuild was repeated for this pass.
