# VibORM vs Prisma 7 — SQLite, 2026-09-28

## Outcome

The optimized VibORM build used less CPU in all five pairs for ID lookups,
relation reads, returning inserts, and full-row reads at 20 and 1,000 rows.
Filtered-20 timing was too variable to establish a winner. Sampled JavaScript
allocation was lower for VibORM in all five pairs of every measured workload.

Every pair below is **VibORM / Prisma 7.9.1**. Lower is better. Values are
medians of five fresh-process replicates per library, workload and mode.

| Operation | CPU µs/op | Wall µs/op | Sampled JS allocation KiB/op |
| --- | ---: | ---: | ---: |
| Find one by ID | 12.96 / 43.60 | 12.17 / 42.70 | 23.93 / 41.28 |
| Filter + order, 20 rows | 150.72 / 145.25 | 146.82 / 142.59 | 37.84 / 47.12 |
| 20 rows + author | 57.56 / 114.72 | 52.07 / 101.23 | 46.86 / 107.84 |
| Insert + return one row | 23.62 / 48.82 | 20.74 / 44.69 | 29.35 / 44.84 |
| Read 20 full rows | 42.16 / 66.65 | 37.53 / 56.32 | 42.21 / 47.92 |
| Read 1,000 full rows | 738.07 / 1144.35 | 807.27 / 947.31 | 796.37 / 919.23 |

| Operation | VibORM CPU reduction | VibORM wall reduction | VibORM JS allocation reduction |
| --- | ---: | ---: | ---: |
| Find one by ID | +70.3% | +71.5% | +42.0% |
| Filter + order, 20 rows | -3.8% | -3.0% | +19.7% |
| 20 rows + author | +49.8% | +48.6% | +56.5% |
| Insert + return one row | +51.6% | +53.6% | +34.5% |
| Read 20 full rows | +36.7% | +33.4% | +11.9% |
| Read 1,000 full rows | +35.5% | +14.8% | +13.4% |

A positive reduction means less cost for VibORM; percentages compare the two
medians. They are not averages of the paired percentages. Full raw values,
min/max, MAD, paired reductions and statement counts are in [summary.json](summary.json).

Timing varied substantially more than in the previous Drizzle run. For example,
filtered-20 CPU is 150.72 ± 22.18 / 145.25 ± 6.71 µs (median ± MAD). Its 3.8%
median disadvantage for VibORM is not a clear timing result. The 1,000-row wall
comparison is also noisy: 807.27 ± 147.18 / 947.31 ± 101.66 µs, with one pair
reversing direction. MAD describes spread; it is not a confidence interval.
No outliers were discarded.

The VibORM build is unchanged from the [Drizzle comparison](../current-drizzle/report.md).
That was a separate measurement run, not part of these fresh pairs. Do not
combine absolute times across the two runs to infer a new three-way ranking.

Held public results take essentially equal heap space:

| Measurement | VibORM | Prisma 7.9.1 |
| --- | ---: | ---: |
| Held 1,000 rows | 203.74 KiB | 203.50 KiB |
| Held 10,000 rows | 2101.63 KiB | 2102.52 KiB |
| 1,000-row retained-mode worker peak RSS | 92.39 MiB | 169.78 MiB |
| 10,000-row retained-mode worker peak RSS | 219.38 MiB | 329.67 MiB |

Held-result numbers are signed forced-GC heap deltas while retaining 30 or 10
complete result graphs. Peak RSS is the median of process-lifetime high-water
marks, including imports, runtime initialization, warmup, the fixture and native
memory. These RSS values are not per-query cost or a production memory budget.

## Validation

- Prisma CLI, generated client runtime, and `@prisma/adapter-better-sqlite3`: **7.9.1**.
- Both use the exact same compiled **better-sqlite3 12.6.0** module; the harness
  asserts resolved native-module identity.
- Node **24.21.0**, V8 **13.6.233.17-node.53**, Apple M4 Pro, macOS arm64.
- VibORM build SHA-256: `1fd1b895b89ad4e56ea55cd737251b423c4b7a678f108158369a95305fd2eff2`.
- Compiled Prisma client SHA-256: `f0b7a6df6411780d72cf28743252cd61a0ff5704dacdf316bd6cfc0dc696c8e5`.
- Six preliminary Prisma workers verified all workload results. The measured
  comparison used 120 CPU/allocation workers and 20 retained-result workers.
- Each worker independently checks the full expected public answer, including
  booleans and order. Digests match across both libraries, and SQL witnesses
  remain stable within each library/workload.
- Fresh process per library/workload/mode/round, alternating library order,
  equal iteration counts, and timing scale 10 for warmup and measured work.
- JS heap allocation is sampled separately at a 4,096-byte interval, including
  collected objects. Retained-result measurements have their own workers.
- A read-only review found no material protocol issue; both changed executable
  harness files passed Biome checks. No production source or project dependency
  changes, rebuild, full typecheck or broad correctness suite were needed.

The SQLite schema matches the existing 100-user/1,000-post fixture; only the
10,000-row retained case grows the seed to 10,000 posts. Inserts add rows during
their worker. Both clients use normal model operations, stock adapters, default
safe-integer behavior and no application result cache or extension. The Prisma
client is generated in an isolated temporary directory, then transpiled once
to ES2022 ESM with TypeScript 5.9.3 outside measurement workers. Its stock query
compiler/runtime is preserved.

Prisma owns its in-memory connection. To seed the same native fixture, setup
temporarily captures the connection through `Database.prototype.prepare` while
running `SELECT 1`, then restores the exact method. The later SQL witness also
restores the exact instance method before warmup and measurement. No query
logging or instrumentation remains enabled during measured calls.

Observed SQL statement counts are one per operation in both libraries, except
the nested-author case: **VibORM 1, Prisma 2**. Prisma uses its stock SQLite
relation-loading strategy; no hand-written join or unsupported relation strategy
was substituted. These are equal public results, not identical SQL. The pinned
[Prisma adapter source](https://raw.githubusercontent.com/prisma/prisma/7.9.1/packages/adapter-better-sqlite3/src/better-sqlite3.ts)
documents the native connection path; [Prisma relation documentation](https://docs.prisma.io/docs/orm/v7/prisma-client/queries/relation-queries)
describes the provider scope of relation load strategies.

The CPU/allocation run took 269.18 seconds, with 393.2 MiB peak sampled process-
group RSS; the retained run took 16.71 seconds, with 407.4 MiB. The bounded
launcher verified whole-group teardown after every run. Group RSS includes the
coordinator and worker, unlike the worker-only memory measurements above.

An initial setup attempt resolved Prisma's package root as its CLI and failed
before generation. The setup now resolves the installed package's `bin.prisma`
entry. The failed log is preserved; it produced no measurement evidence.

Reproduce with the commands in [benchmarks/README.md](../../../../benchmarks/README.md).
The setup receipt returns the directory to use as `--prisma-dir`; project Prisma
files remain untouched. Evidence includes [setup.json](setup.json), the isolated
[dependency lockfile](prisma-package-lock.json), [generated client archive](generated-client.tar.gz),
[measured harness](benchmark.snapshot.mjs), [CPU/allocation receipt](cpu-allocation.json),
[retention receipt](retained.json), and [manifest.json](manifest.json).

## Risks

These results cover six warm SQLite workload shapes with these installed
versions. They do not establish cold-start performance, other providers, different
data distributions, arbitrary query shapes, or concurrency scaling.

Sampled allocation measures JavaScript heap churn, **excluding native and WASM
allocations**. Prisma's runtime has costs outside that metric. Retained heap and
RSS complement it, but neither is an exact total allocation count. The lower
allocation findings describe less temporary JavaScript garbage, not smaller
public result graphs or a leak-free guarantee.

The relation performance difference includes the stock one-query vs two-query
strategies. Timing variability limits the precision of the reported percentages,
particularly filtered reads and large-read wall time. Retain the raw distributions
when making claims; do not present this diagnostic as an all-workload winner.
