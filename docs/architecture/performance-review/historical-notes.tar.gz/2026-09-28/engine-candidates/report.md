# Outcome

Tested all five shared-engine candidates independently, then retained the
combined patch. SQLite was the measurement backend only. The baseline already
contains the three [previously kept optimizations](../implementation/report.md),
so the changes below are additional gains.

The strongest individual change is sharing prepared-operation and route methods
on prototypes instead of constructing method/getter functions per operation.
Each operation retains its own lazy admission, prepared read and cache codec.
The other changes share stateless read callbacks, build filter predicates in one
pass, remove per-field reader wrapper objects, and remove async forwarding
wrappers while preserving asynchronous rejection and write completion ordering.

Final before/after results: medians of five alternating pairs. CPU and wall are
microseconds per complete operation; allocation is sampled KiB per operation.
Negative percentages mean less cost.

| Workload | CPU before → after | CPU change | Wall before → after | Wall change | Allocation before → after | Allocation change |
|---|---:|---:|---:|---:|---:|---:|
| unique | 15.14 → 10.90 | -28.0% | 11.43 → 9.98 | -12.6% | 27.13 → 23.89 | -11.9% |
| filtered20 | 99.76 → 94.96 | -4.8% | 91.03 → 89.69 | -1.5% | 41.40 → 37.84 | -8.6% |
| relation20 | 52.54 → 46.40 | -11.7% | 43.11 → 41.31 | -4.2% | 51.24 → 46.72 | -8.8% |
| insert | 19.86 → 17.32 | -12.8% | 16.24 → 15.17 | -6.6% | 32.03 → 29.27 | -8.6% |
| rows20 | 36.92 → 31.56 | -14.5% | 29.36 → 27.48 | -6.4% | 45.10 → 41.96 | -7.0% |
| rows1000 | 477.57 → 476.00 | -0.3% | 469.46 → 470.88 | +0.3% | 805.75 → 796.53 | -1.1% |

Three screening blocks, each with a fresh process per candidate, workload and
measurement mode. Arm order changes between blocks. The baseline is shared
within each block; these are not five independent paired comparisons. Read each
small change against its per-round spread in [screen-summary.json](screen-summary.json).

| Candidate | Lookup CPU | Lookup allocation | Filtered-20 allocation | Full-20 allocation | Evaluation |
|---|---:|---:|---:|---:|---|
| callbacks | -3.2% | -0.6% | -0.1% | -0.3% | Keep: small lookup CPU signal; allocation benefit is near noise. |
| handles | -29.6% | -6.9% | -3.7% | -3.5% | Keep: strongest CPU and allocation result in every screening round. |
| filters | -0.0% | -0.4% | -0.6% | -0.6% | Keep: small one-pass simplification; no independent CPU claim. |
| readers | -3.9% | -1.3% | +0.4% | -1.1% | Keep: allocation gain on lookup and full rows; narrow projections remain noisy. |
| async | +1.0% | -3.0% | -1.1% | -2.3% | Keep: consistent allocation reduction; standalone CPU is inconclusive. |

The callback and filter changes are much smaller than the handle change. Their
allocation deltas are near the variation in control cases, so no independent
whole-query allocation percentage is established for them. The filter loop
removes the entry tuples and intermediate filtered array and simplifies the
existing nested dispatch. Shorthand scalar filters do reach it: admission
normalizes them through the existing shorthandFilter schema.

The reader change retains two arrays instead of an array of field/reader
objects. It saved allocation consistently for lookup and full-20 reads in the
screen, but the filtered projection's median did not improve. Async forwarding
saved allocation in all nine candidate/baseline screening comparisons; its CPU
result alone was mixed. No generic cache, object pool, driver bypass, or changed
validation rule was introduced.

# Validation

- 68 focused SQLite/result-boundary tests passed across eight files: prepared
  operations, filters, ordering, result decoding/placements, write-outcome
  composition, read-only build, and cacheable-read vocabulary.
- Three selected instrumentation tests passed. The existing observer-order test
  now covers both raw and model reads. The added direct prepared-execution
  witness checks that invalid admission returns a rejected promise and sends no
  SQL. Ten unrelated instrumentation tests were skipped deliberately.
- One whole-estate native typecheck and the final package build passed.
- The three changed production files passed Biome checks, and the scoped diff
  passed whitespace checks. Formatting the touched tests also reported an
  existing useTopLevelRegex warning for /^SELECT\b/ in prepared-operation.test.ts;
  that unrelated test expression was left unchanged.
- A separate read-only code review found no correctness defect. Internal
  consumers invoke handle methods with their receiver; parser readers remain
  local to each decoded batch. Mutation replay still creates an execution-local
  plan and context.

The individual screen used 108 workers. The final comparison used 120 workers:
six workloads × two modes × two arms × five rounds. Timing uses scale 10,
including warmup; allocation uses a 4,096-byte sampling interval with collected
objects included. Node 24.21.0, V8 13.6.233.17-node.53, Apple M4 Pro, macOS arm64,
better-sqlite3 12.6.0. All builds, tests and measurements were serialized under
the repository's bounded launchers.

Every measurement worker checks its complete public answer against an independent
fixture before its loop. Across arms and repetitions, SQL text witnesses and
result digests matched. Actual build hashes are recorded and checked by both
coordinators. Source patches and hashes identify the exact candidates; the final
working source was checked against the measured combined source.

Evidence: [screen.json](screen.json), [final.json](final.json),
[summary.json](summary.json), [checks.log](checks.log),
[observer-checks.log](observer-checks.log), [typecheck.log](typecheck.log),
[combined-build.log](combined-build.log), and [candidate-sources.json](candidate-sources.json).
Each candidate has its own adjacent patch, including [combined.patch](combined.patch).

Baseline built .mjs hash: e7931d3ba0b67605b6bd63c21933cc27e63f8387f0d672a9d197ba5ab69f2205.
Combined built .mjs hash: 1fd1b895b89ad4e56ea55cd737251b423c4b7a678f108158369a95305fd2eff2.

For reproduction, start from the source identity and production patch in the
previous implementation report, then apply the selected candidate patch here.
Build each variant with the same lockfile and package build configuration.
[locations.json](locations.json) records the local temporary source/build copies;
these paths are machine-local. The source copies deliberately have no separate
Git identity; provenance is the saved baseline plus the exact patches, not the
benchmark metadata's common checkout HEAD. [screen.mjs](screen.mjs) and
[compare.mjs](compare.mjs) show the executed protocols. The archived benchmark
snapshot must be placed under benchmarks/ for its repository-relative paths.

# Risks

The final combined comparison establishes the combined effect, not the sum of
independently attributable gains. Three screening rounds are diagnostic; the
small candidates do not have the same strength of evidence as shared methods.
Timing remains local to this runtime and machine. Use the per-pair values and
MADs in summary.json before extrapolating small deltas, particularly at 1,000 rows.

Allocation is temporary JavaScript heap churn, not retained heap or process RSS.
Other providers were not run, and Drizzle was not rerun in this evaluation.
Private engine handles now use prototype methods; detached calls and own-method
enumeration were not supported production consumption paths and are not added
as contracts. Existing public result, rejection, and lifecycle behavior is
covered by the focused checks above.
