# Outcome

The last construction patch did not establish the requested wall-time gain.
Its changed paths run once per query; they do not reduce database work or
per-row decoding. This diagnosis changes no production code.

The prior filtered20 candidate was slower in four of five wall-time pairs.
That must not be dismissed as harmless noise. A fresh time-only comparison with
adjacent baseline/candidate workers did not reproduce a stable regression:
filtered20 medians were 97.93 → 97.29 µs; rows1000 medians were 484.70 → 482.05 µs.
Their paired median changes were -0.02% and -0.97%, with large outliers in both
directions. These runs establish neither a reliable speedup nor a stable causal
regression. No V8 optimization/deoptimization cause was measured. The previous
2×MAD gate is an improvement heuristic, not a confidence or equivalence test.

## Measured costs

One fresh process per workload compares both builds and isolated stages over
the same fixture. Five rotating blocks follow warmup. These are independently
timed controls in µs/op, **not additive slices of a full operation**.

| Workload | Current full ORM | ORM prepare/render | Native prepare + fetch | Reused native statement + fetch | Prepared result parse |
| --- | ---: | ---: | ---: | ---: | ---: |
| unique | 10.91 | 3.27 | 3.97 | 0.64 | 0.30 |
| filtered20 | 93.51 | 5.42 | 78.59 | 73.76 | 2.58 |
| rows20 | 27.06 | 3.39 | 16.00 | 10.46 | 3.33 |
| rows1000 | 483.88 | 5.49 | 302.71 | 293.41 | 157.68 |

Native controls use exact prepared SQL/parameters, object rows, and
`safeIntegers(true)`. Fetch includes database execution and native row creation.
Preparation alone costs 3.16/3.95/4.56/4.79 µs for these four workloads.
The parse control uses the existing private benchmark capability over a fixed,
frozen provider result. It includes prepared-path packaging and an extra outer
row map. Its input lifetime differs from fresh live results, so it diagnoses
decoder cost rather than measuring the exact live-path parse time.

Fresh full-operation CPU profiles support the stage measurements:

| Workload | Native Statement self | Native all self | decodeProjection inclusive | GC share of sampled time |
| --- | ---: | ---: | ---: | ---: |
| unique | 29.9% | 6.0% | below top-40 inclusive cutoff | 8.0% |
| filtered20 | 4.9% | 74.0% | 2.1% | 1.6% |
| relation20 | 16.4% | 32.0% | 14.0% | 3.9% |
| insert | 24.9% | 15.5% | below top-40 inclusive cutoff | 7.4% |
| rows20 | 16.5% | 27.8% | 11.2% | 5.2% |
| rows1000 | 2.1% | 30.9% | 28.6% | 1.9% |

Frame shares exclude GC and describe sampled main-thread time. Native attribution
can land in its JavaScript caller: rows1000 `runStatement` is 60.3% inclusive,
including native `all` and 26.9% self attribution. That self share is not proof
of JavaScript loop overhead. Inclusive shares overlap their children.

## Filtered20: database scan and sort dominate

The query examines an unindexed 1,000-row table, with 500 matches and a temporary
ordering structure to select 20. Native statement reuse only changes 78.59 →
73.76 µs; the scan/sort remains. ORM preparation is 5.42 µs and the decoder
control 2.58 µs. Construction micro-optimizations target a small part of the cost.

In a disposable fixture, adding `posts(published, views DESC, id ASC)` changes
the **full current ORM call** from 93.51 → 26.40 µs, about 3.5×, with the same
answer and prepared SQL/parameters. Native prepare/fetch changes 78.59 → 12.71
µs. The plan switches from SCAN plus temporary sorting to indexed SEARCH with no
temporary sorting. No application index was added. The full-operation gain is
smaller than the earlier 6× raw-SQL gain because ORM overhead remains.

## RowsN: repeated scalar work and output copying

The live Raptor3 path is `OperationContext.publish` → typed driver execution →
`publishedTerminal` → `publishedProjection` → `Queries.decodeProjection`.
Readers compile once per batch, but every physical scalar still does own-key
lookup, null/absence checks, driver parsing, adapter parsing, an input-capturing
adapter continuation, and scalar validation/conversion. Every row gets a new
object and field assignments. This fixture makes 60 scalar visits for filtered20,
120 for rows20, and 6,000 for rows1000.

The row allocation is at `shared/query.ts:5212`; `fieldReader` at line 795 creates
the adapter continuation per value. SQLite's adapter `parseField` always calls
`next()`. Its driver parser passes strings/integers through and handles boolean
and JSON representations. Removing generic parser calls would break extensions.

The old consumable-result protocol is **dormant**: SQLite registers a producer,
but `resolveConsumableResultCandidate` and `executeConsumableResultCandidate`
have no callers under `src`. The current decoder always copies rows. Root guide
Rule 5 describes a protocol that is not connected to this live path; the guide
does not prove active row reuse.

A diagnostic with safe integers disabled changes reused native rows1000 fetch
from 293.41 → 276.77 µs. It identifies representation cost, but is **not an
acceptable optimization**: valid integers outside JavaScript's safe range would
lose precision. The filtered20 difference is only 73.76 → 73.27 µs.

## Optimization priorities

1. **Shared engine:** bind scalar type/list/identifier dispatch when compiling
   the batch reader. Keep one codec owner and every value check. This targets
   repeated work, but only part of decoder time is removable; benchmark both
   decoding and full rowsN operations before adoption.
2. **Shared engine, more involved:** eliminate proven pass-through parser legs
   and per-value continuations. Custom parsers must retain behavior. Hoisting a
   callback over shared mutable input is unsafe under re-entry/retained callbacks.
3. **Shared engine, larger change:** connect proven native-row ownership to the
   active parser to avoid a second object per row. Keep a fresh public outer
   array, validation, parser middleware and borrowed-row isolation. The dormant
   protocol needs review before reuse; arbitrary mutation is not a micro change.
4. **Outside engine-only scope:** bounded per-connection native statement reuse
   could remove much of the measured 3–5 µs fixed preparation cost. It matters
   more to small reads, relations and inserts than this unindexed filter or
   rows1000. It requires bounded retention, close/reconnect cleanup, transaction
   ownership and invalidation rules. This probe validates one reused statement,
   not a production cache or write optimization.
5. **Database access path:** the index is the demonstrated large filtered20 win.
   No evidence here identifies a large, safe engine-only micro-optimization for
   the unindexed filter while retaining its query and schema.

No new query-shape cache or object pool is justified. The construction patch
remains present; it must not be described as a proven latency optimization.

# Validation

Four hypotheses were tested: scan/sort dominates the filter; row materialization
and parsing grow with result size; native preparation is a significant fixed
cost; the latest patch causes a stable regression. The first three are supported.
The fourth remains unresolved because rankings change across protocols and runs.

- Six current public-operation profiles: 6.99 seconds / 205.8 MiB peak group RSS.
- Four stage workers with five rotating blocks: 27.85 seconds / 348.5 MiB.
- Twenty adjacent time-only workers, five alternating pairs for filtered20 and
  rows1000: 68.87 seconds / 258.8 MiB. No allocation workers separate each pair.
- All bounded processes verified teardown. No production edits, rebuilds,
  typechecks or correctness-suite reruns were needed.

The stage fixture is extracted from the existing benchmark; exact provenance is
in `fixture-provenance.json`. It checks independently expected full answers and
compares prepared SQL and parameter arrays across both builds for all four read
workloads. The production source/build remain the engine-micro candidate.

**Evidence correction:** the engine-micro report claimed captured parameter
arrays matched. Its harness captured only SQL strings and checked full answers.
Its SQL/result claims stand; no parameter arrays were captured there. Prepared
parameter matching is established separately by this four-workload probe. The
old sealed report and manifest are preserved, with this correction beside them.

[Stage medians](stage-summary.json), [raw stages/plans](stages.json),
[adjacent timings](adjacent-summary.json), [raw worker receipts](adjacent.json),
[mapped profiles](profile-summary.json), and [file identities](manifest.json).
Run `probe.mjs` and `adjacent.mjs` through `scripts/run-node-safe.mjs 768 180000`.
They use the baseline path saved by engine-micro and assert both build hashes.

# Risks

Stage timings are not additive; JIT, input lifetime and host scheduling differ.
Five blocks in one process are not five independent fresh-process trials. The
indexed control follows the unindexed controls in its disposable worker. CPU
samples are not a precise wall-time partition. No proposed decoder, ownership,
or cache change was implemented or benchmarked, so none has a demonstrated gain.
