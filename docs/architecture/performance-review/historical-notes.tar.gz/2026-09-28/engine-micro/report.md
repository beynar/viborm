# Outcome

Implemented three small allocation reductions in the shared engine and measured
them together. They reduce temporary JavaScript allocation on the two small
reads. This comparison does **not** establish a wall-time improvement.

- Ordering uses append loops instead of nested `flatMap` calls and entry tuples.
  Identity completion avoids temporary key arrays when no cursor fields exist.
- Explicit selection reads its admitted record directly when there is no
  include to merge, and visits own keys without entry tuples.
- Filter preparation inlines a once-called operand callback. Singleton AND/OR
  lowering avoids a mapped array and callback while retaining the adapter call.

These changes introduce no cache, pool, retained query state, or new SQL path.
Default projections keep their existing schema-lifetime cache. Include merging
still creates a separate object. Deterministic ordering, null placement, cursor
behavior, input validation, and result decoding remain unchanged.

Five alternating baseline/candidate pairs, with a fresh process per workload
and mode. CPU and wall values are microseconds per complete public operation.
Allocation is sampled JavaScript KiB per operation, excluding native allocations.

| Workload | Wall before → after | Wall change | CPU before → after | JS allocation before → after | Allocation change |
| --- | ---: | ---: | ---: | ---: | ---: |
| filtered20 | 92.29 → 93.74 | +1.6% | 97.39 → 97.61 | 37.83 → 36.38 | -3.8% |
| rows20 | 29.20 → 28.52 | -2.3% | 33.57 → 32.46 | 42.03 → 41.26 | -1.8% |
| rows1000 | 484.33 → 489.03 | +1.0% | 485.92 → 490.91 | 796.66 → 796.57 | -0.01% |

The allocation reductions for filtered20 and rows20 occur in all five pairs and
exceed twice the larger arm's median absolute deviation (MAD). No wall-time or
CPU improvement passes that threshold. Wall-time MADs before/after are 0.85/1.40
µs, 0.83/0.56 µs, and 2.33/5.31 µs respectively. The small timing differences
do not establish either a speedup or a regression; equivalence is not proved.
Large-row allocation is also within sampling variation.

The patch is retained for the measured allocation reductions. The requested
wall-time gain remains unproven. No individual change receives an independent
performance claim from this combined comparison.

# Validation

All 65 existing focused tests passed across six files: filters, ordering and
projection, read verbs and pagination, empty/negated predicates, parity repairs,
and prepared operations. Tests were run once; no new behavior required new tests.

The full typecheck initially found a widened `kind` literal after inlining the
operand callback. An explicit `satisfies PreparedOperand` restores its literal
type without emitted runtime code. The final typecheck and package build pass.
Production source and the two evidence scripts pass Biome. The first script
lint attempt applied a test-only assertion rule to standalone evidence scripts;
file-scoped explanations now exclude that rule while keeping every assertion.
Both failed receipts remain in this directory.

A separate read-only review checked the copy-removal boundary: operation
admission creates fresh ordinary records and dense order arrays; upsert validates
its projection separately; inspection exposes detached snapshots. The changed
walkers neither mutate nor retain the admitted records.

The 60 benchmark workers use the existing fixture and independent expected full
answers. All result digests, captured SQL text, and parameter arrays match across
both builds and all rounds. Timing uses `--time-scale 10`; allocation uses the
existing 4,096-byte sampling interval in separate workers. The source, harness,
and both built artifacts were checked for changes during the comparison.

The bounded comparison completed in 90.57 seconds with 269.0 MiB peak sampled
process-group RSS and verified teardown. Node 24.21.0, V8 13.6.233.17-node.53,
Apple M4 Pro, macOS arm64, better-sqlite3 12.6.0. SQLite is the measurement
backend; all production changes are in the shared engine.

- Baseline build SHA-256: `1fd1b895b89ad4e56ea55cd737251b423c4b7a678f108158369a95305fd2eff2`.
- Candidate build SHA-256: `3299ea848d57f061696acab2160e1932b21c4548ee4e347467be21670c3bf19f`.
- The baseline source matches the previous combined optimization specimen.
  Only `src/query-engine/raptor3/shared/query.ts` changes in the production tree.

[Exact task patch](candidate.patch), [summary with all samples and MADs](summary.json),
[raw comparison](comparison.json), [correctness receipt](checks.log),
[final typecheck](typecheck.log), [build receipt](build.log), and
[file identities](manifest.json) retain the evidence. `locations.json` names the
machine-local baseline copy; `compare.mjs` and `summarize.mjs` reproduce this
specific comparison through the bounded Node launcher. The harness snapshot must
be restored at its normal `benchmarks/` location for relative imports to resolve.

# Risks

This is local evidence for three SQLite workloads. It does not establish a
wall-time win, another provider's performance, or gains for every query shape.
CPU samples include background runtime work. Sampled allocation is temporary
heap churn, not retained heap or process RSS; no retention improvement is claimed.
Drizzle and Prisma were not rerun, so their earlier reports remain historical
comparisons against the baseline build.
