# Current VibORM vs Drizzle — SQLite, 2026-09-28

## Outcome

The optimized build uses less CPU on ID lookup, relation reads and returning
inserts in this workload set. It allocates less temporary JavaScript memory on
all measured reads. Small-list and 1,000-row timing differences are close/noisy;
insert allocation is effectively tied. Held public result graphs are similar.

Every pair below is **VibORM / Drizzle**. Lower is better. Values are medians of
five fresh-process replicates per library, workload and measurement mode.

| Operation | CPU µs/op | Wall µs/op | Sampled allocation KiB/op |
| --- | ---: | ---: | ---: |
| Find one by ID | 11.29 / 17.68 | 10.38 / 17.24 | 23.97 / 25.13 |
| Filter + order, 20 rows | 97.69 / 94.81 | 94.06 / 93.41 | 37.87 / 40.07 |
| 20 rows + author | 47.91 / 67.21 | 42.83 / 63.57 | 46.85 / 95.67 |
| Insert + return one row | 17.82 / 20.01 | 15.46 / 19.11 | 29.37 / 29.78 |
| Read 20 full rows | 33.80 / 32.90 | 29.57 / 31.08 | 42.18 / 47.77 |
| Read 1,000 full rows | 477.28 / 489.14 | 472.94 / 479.25 | 794.98 / 923.50 |

| Operation | CPU change | Wall change | Allocation change |
| --- | ---: | ---: | ---: |
| Find one by ID | -36.1% | -39.8% | -4.6% |
| Filter + order, 20 rows | +3.0% | +0.7% | -5.5% |
| 20 rows + author | -28.7% | -32.6% | -51.0% |
| Insert + return one row | -10.9% | -19.1% | -1.4% |
| Read 20 full rows | +2.7% | -4.9% | -11.7% |
| Read 1,000 full rows | -2.4% | -1.3% | -13.9% |

Percentages compare the two medians, not the median of paired percentages.
Negative means less cost for VibORM. Lookup and relation CPU improved in all
five pairs. Insert CPU improved in all five, but its first pair was only 0.9%
lower; wall time was also noisy in that pair. Filtered-read CPU has a +3.0%
median difference, with one substantial Drizzle timing outlier retained in the
raw data. Full-20 CPU is +2.7%; the difference is small relative to dispersion.
At 1,000 rows, neither the CPU nor wall difference establishes a clear lead.
The 1.4% insert allocation difference is also small and one pair reverses.

Allocation sampling uncertainty is separate from run-to-run spread. The larger,
consistent read allocation savings are more useful than assigning importance
to tiny percentages. Full samples, min/max, MAD and paired percentages are in
[summary.json](summary.json); MAD is descriptive, not a confidence interval.

## Retained memory

| Held result | VibORM | Drizzle |
| --- | ---: | ---: |
| 1,000 rows | 203.74 KiB | 203.23 KiB |
| 10,000 rows | 2101.61 KiB | 2101.75 KiB |

These are post-GC heap deltas while holding complete results: 30 held results
for the 1,000-row case, 10 for the 10,000-row case. They are useful estimates,
not exact object sizes or a long-running leak comparison. The optimized engine
mainly reduces temporary allocations, while returned data still needs storage.

| Retained-mode worker | VibORM peak RSS | Drizzle peak RSS |
| --- | ---: | ---: |
| rows1000 | 93.64 MiB | 272.88 MiB |
| rows10000 | 219.16 MiB | 280.81 MiB |

Peak RSS is the median of process-lifetime high-water marks, including imports,
warmup, fixture, V8 and native SQLite memory. It is not per-query cost or proof
that a production service will use this amount. Allocation samples do not
fully account for native SQLite memory.

The separate [VibORM retention soak](../retention/report.md) used this same
build: 200,000 operations held near 10.1–10.3 MiB post-GC heap; 1,000 disposed
client lifecycles settled near 10.5 MiB. Drizzle was not run through that soak.
The pre-existing unknown-property client proxy cache issue remains unchanged,
per the user's engine-only scope decision.

## Validation and reproduction

- Installed Drizzle **0.43.1**, better-sqlite3 **12.6.0**.
- Node **24.21.0**, V8 **13.6.233.17-node.53**, Apple M4 Pro, macOS arm64.
- Exact optimized build: `1fd1b895b89ad4e56ea55cd737251b423c4b7a678f108158369a95305fd2eff2`.
- The engine source and harness hashes were checked against the completed
  [candidate evaluation](../engine-candidates/manifest.json) before running.
- 120 CPU/allocation workers plus 20 retained-result workers. Separate fresh
  processes per mode, alternating library order, five pairs per case.
- Timing scale 10 lengthens iterations and warmup. Allocation remains separately
  sampled at a 4,096-byte interval, including collected objects.
- Independent full-result checks, booleans, ordering and result digests passed
  in every worker. Both use stock transport paths and the same awaited harness;
  Drizzle's underlying SQLite calls are synchronous and VibORM's asynchronous.
- Same seed/schema/public answers; SQL may differ by ORM. No application cache,
  plugins or reused prepared-query objects. Returning inserts grow their table.
- All workers ran serially under the bounded launcher with verified teardown.
  No production edit, rebuild, typecheck or broad test suite was needed.

```sh
node scripts/run-node-safe.mjs 768 600000 benchmarks/better-drizzle-compare.mjs \
  --libraries viborm,drizzle \
  --workloads unique,filtered20,relation20,insert,rows20,rows1000 \
  --modes time,alloc --time-scale 10 --rounds 5 --output /absolute/cpu-allocation.json
node scripts/run-node-safe.mjs 768 180000 benchmarks/better-drizzle-compare.mjs \
  --libraries viborm,drizzle --workloads rows1000,rows10000 \
  --modes retained --rounds 5 --output /absolute/retained.json
```

Raw receipts: [cpu-allocation.json](cpu-allocation.json), [retained.json](retained.json),
[CPU/allocation log](cpu-allocation.log), [retained log](retained.log).
[manifest.json](manifest.json) seals the evidence and measured harness.
These results apply to the installed versions and these SQLite workloads.
They are not an all-provider, all-runtime or newest-release performance claim.
