# Why the filtered-read case is expensive

## Outcome

The dominant cost in this fixture is native database execution of an unindexed
filter and sort. The measurements do not establish a large remaining defect in
VibORM's filter preparation. No production behavior or database schema changed.

The full-operation Drizzle comparison was 97.69 / 94.81 µs CPU for VibORM /
Drizzle, a roughly 3% median difference. In the more variable Prisma run it was
150.72 / 145.25 µs, with enough dispersion to prevent a timing conclusion. Those
differences are not evidence that filter parsing itself is slow.

The case is a boolean filter plus descending sort and limit on 1,000 posts:

```sql
SELECT id, title, views
FROM posts
WHERE published = 1
ORDER BY views DESC, id ASC
LIMIT 20;
```

There is only a primary-key index. Half the posts match the boolean condition.
`EXPLAIN QUERY PLAN` reports `SCAN q0` and `USE TEMP B-TREE FOR ORDER BY` for
VibORM's emitted SQL. Drizzle has the same scan/temporary-sort plan. The limit
reduces returned rows; it does not allow this plan to examine only 20 rows.

The controlled native probe ran captured SQL directly through the same
better-sqlite3 module. Each timed call prepared the SQL, enabled safe integers,
and fetched object rows. This equal native boundary isolates SQL cost; it does
not reproduce Drizzle's own array-row transport/mapping path.

| Raw SQL variant | No supporting index: CPU µs/op | With supporting index: CPU µs/op |
| --- | ---: | ---: |
| Captured VibORM SQL | 79.67 | 13.21 |
| VibORM SQL with the extra ID sort term removed | 78.83 | 14.29 |
| Captured Drizzle SQL | 78.23 | 11.53 |
| Drizzle SQL with an ID sort term added | 78.38 | 12.68 |

The disposable indexed fixture adds:

```sql
CREATE INDEX posts_filter_order
ON posts (published, views DESC, id ASC);
```

Every indexed plan then reports `SEARCH ... USING INDEX posts_filter_order
(published=?)`, with no temporary sort. VibORM's raw query falls by about 83%,
or roughly 6×. This is a diagnostic of the database workload, not an implemented
ORM optimization or a measured full-operation speedup.

The additional `id ASC` was a separate hypothesis: VibORM's pagination owner
completes scalar ordering with the model identity so ties are deterministic.
Drizzle and Prisma did not request that extra term. However, removing it changes
the unindexed VibORM SQL by only 0.84 µs, while its five-block MAD is 1.61 µs.
Adding it to Drizzle changes 0.15 µs. These data do not support blaming the
tie-breaker for a material slowdown. The fixture has unique `views` values,
although the schema does not declare `views` unique.

The current-build CPU profile gives the same broad answer:

| Profile attribution | VibORM | Drizzle |
| --- | ---: | ---: |
| Native `all` self samples | 72.60% | 73.95% |
| Native statement constructor self samples | 5.63% | 4.96% |
| VibORM driver `runStatement`, inclusive | 81.36% | — |
| VibORM `Queries.read` construction, inclusive | 5.13% | — |
| VibORM projection decoding, inclusive | 1.82% | — |

These are active non-GC sampled main-thread shares, not aggregate process CPU.
Inclusive shares must not be added to the child/self shares. The native `all`
frame includes database execution and native row materialization. Sampling does
not establish a precise cost for every small or inlined filter function.

## Validation

Three hypotheses were tested: database scan/sort dominates; the extra identity
sort term is material; ORM read construction/decoding dominates. The first is
supported. The tie-breaker probe did not show a material unindexed effect, and
the current profile does not show construction/decoding as the main cost.

The native probe uses two fresh workers, one per index configuration, each with
five rotating blocks of four SQL variants and 6,000 calls per variant per block.
It checks the complete expected result before and after each variant. Parameters
are `(1, 20)`, row count and data remain fixed, and every variant returns the same
20 rows. This within-process diagnostic is not a production adoption gate.

Two separate fresh workers profile current VibORM and Drizzle on the full
filtered operation through the existing harness. No broad test suite, typecheck,
package rebuild, or unrelated workload was run. Both bounded commands completed
with verified teardown: native probe 12.05 seconds / 128.0 MiB group RSS; profiles
4.51 seconds / 303.8 MiB. The new executable probe passed Biome checks.

Build SHA-256 remains
`1fd1b895b89ad4e56ea55cd737251b423c4b7a678f108158369a95305fd2eff2`.
Node 24.21.0, better-sqlite3 12.6.0, installed Drizzle 0.43.1.

Evidence: [native query plans and timings](raw-sql.json),
[full-operation profile receipt](profiles.json),
[mapped profile summary](profile-summary.json), and [manifest](manifest.json).
`raw-harness.snapshot.mjs` is the exact measured probe; the executable later
received formatting/import-order cleanup only.

```sh
node scripts/run-node-safe.mjs 768 180000 benchmarks/filter-sql-probe.mjs \
  --output /absolute/filter-sql.json
```

## Risks

This diagnosis does not prove that every filter shape is efficient. It tests one
boolean predicate, one projection and one sort. The raw probe cannot quantify
ORM overhead by subtracting its numbers from another run's full-operation
timings. Native transport settings and sampling also prevent that subtraction.

To make the benchmark more informative for future shared-engine changes, retain
the unindexed case as a database-heavy control and add an indexed case with the
same explicit total order for each ORM. That would expose preparation and
decoding overhead with less database work in the way. This report proposes that
additional full-operation case; it does not change existing benchmark semantics
or remove VibORM's deterministic pagination guarantee.
