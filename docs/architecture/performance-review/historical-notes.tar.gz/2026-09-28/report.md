# SQLite CPU and memory baseline — 2026-09-28

## Outcome

VibORM is already competitive with the installed Drizzle **0.43.1**. There is
no general latency deficit to close in this SQLite workload set. The strongest
remaining targets are fixed setup allocations and CPU on small multi-row reads.
Production code, dependencies, and the lockfile are unchanged. This report
proposes optimizations; it does not claim that any has shipped.

### Measured baseline

Apple M4 Pro, macOS arm64, Node **24.21.0**, V8 **13.6.233.17-node.53**,
better-sqlite3 **12.6.0**, source commit
`778912983181e6b4049a3639a5f498b4cb9e83d0`.
Each cell has five fresh-process replicates per library and measurement mode,
with alternating library order. Values below are medians; **each pair is
VibORM / Drizzle**, lower is better. CPU/wall use the longer timing run;
allocation uses its separate, unslowed-by-CPU-profiling allocation workers.

| Operation | CPU µs/op | Wall µs/op | Sampled allocation KiB/op |
|---|---:|---:|---:|
| Find one by ID | 15.66 / 17.50 | 11.68 / 16.95 | 28.36 / 24.90 |
| Filter + order, 20 rows | 100.78 / 91.84 | 91.92 / 90.35 | 42.67 / 39.93 |
| 20 rows + author | 53.86 / 66.48 | 44.44 / 61.95 | 53.18 / 96.08 |
| Insert + return one row | 19.98 / 19.71 | 16.22 / 18.60 | 32.96 / 29.89 |
| LIMIT 0 control | 21.53 / 21.07 | 17.43 / 20.90 | 26.95 / 27.94 |
| Read 1 full row | 23.65 / 21.46 | 19.21 / 21.06 | 31.04 / 29.20 |
| Read 20 full rows | 38.28 / 32.44 | 29.90 / 30.66 | 47.34 / 47.83 |
| Read 1,000 full rows | 483.10 / 481.20 | 472.84 / 471.09 | 811.08 / 919.39 |
| Read 10,000 full rows | 5105.01 / 4876.37 | 4945.68 / 4736.36 | 7821.58 / 8929.04 |

The useful distinctions:

- ID lookup: about **31% less wall time and 11% less CPU**, but **14% more
  allocation** for VibORM.
- Relation read: about **28% less wall time, 19% less CPU, and 45% less
  allocation** for VibORM.
- Filter/order 20: about **10% more CPU and 7% more allocation**. Its 1.7% wall
  difference is small relative to the dispersion; do not sell that as a clear
  latency regression.
- Unfiltered 20 full rows: **18% more CPU**, with similar allocation and slightly
  lower wall time. This is a useful small-read optimization target.
- 1,000 rows: CPU/wall are effectively tied, with **12% less allocation** for
  VibORM. At 10,000 rows allocation remains about **12% lower**; the observed
  roughly 4–5% time/CPU disadvantage is noisier and needs confirmation before
  becoming an optimization gate.

CPU is aggregate process user + system time, including background V8 work;
it can exceed wall time. Short windows gave a different lookup ranking:
**27.10 / 22.06 µs CPU**, versus **15.66 / 17.50 µs** in the longer run.
Both receipts are retained. The longer run multiplies measured iterations and
warmup by ten, reducing startup/JIT spillover per operation. It does not prove
that all workloads or runtimes have reached a universal steady state. The insert
run also grows a larger table, so its short/long difference is not solely JIT.

For example, longer-run CPU median ± MAD is **100.78 ± 0.23 / 91.84 ± 0.88 µs**
for filtered20 and **38.28 ± 0.13 / 32.44 ± 0.13 µs** for rows20. Full min/max,
MAD, counts, checksums, SQL witnesses, runtime and build hashes are in
[sqlite-steady.json](sqlite-steady.json) and [sqlite.json](sqlite.json).
MAD is descriptive dispersion, not a confidence interval.

### Memory: allocation is not retention

Held result graphs are almost the same size in the large-read controls:

| Held result | VibORM | Drizzle |
|---|---:|---:|
| 1,000 rows | 203.31 KiB | 203.22 KiB |
| 10,000 rows | 2,101.63 KiB | 2,101.75 KiB |

These are signed forced-GC heap differences while holding 30 or 10 complete
results, respectively. Small-result measurements can be negative because other
objects are collected; they are not exact object-size measurements. Post-release
residuals remain in the raw receipt and are not interpreted as leaks: that window
can retain asynchronous execution state and roughly one last large result.
A long-lived leak/plateau experiment was not performed.

Median process-lifetime peak RSS for the retained-mode 1,000-row worker was
**99.94 / 273.03 MiB**; for 10,000 rows, **223.77 / 280.52 MiB**. These include
imports, fixtures, provider memory and warmup, so they are not per-query memory
costs. V8 allocation samples exclude a complete accounting of native SQLite
memory. The useful initial optimization target is temporary garbage, not shrinking
public result graphs or claiming a leak.

### Proposed changes, in order

**1. Do not build unused projection outputs.**
[Queries.lowerProjection](../../../src/query-engine/raptor3/shared/query.ts#L3955)
always creates aliased `columns`, `[name, expression]` `entries`, and `names`.
Ordinary reads/returning writes use columns; DISTINCT needs names; the recursive
carrier is the only consumer of entries. Construct the additional representations
only when their existing consumers need them. Keep this responsibility in the
same lowering owner.

This function accounts for **2.13 KiB/op / 7.23%** of sampled lookup allocation
and **2.18 KiB/op / 6.44%** of insert allocation. Lookup self CPU is **2.52%**
of active non-GC samples. Those figures include necessary work: they are
**not predicted savings**. Preserve aliases, selected field order, DISTINCT
names, recursive carriers, and exactly the same SQL. This is the strongest
combination of a measured cost and demonstrably unused work.

**2. Remove temporary entry arrays during reader compilation.**
[Queries.compileReader](../../../src/query-engine/raptor3/shared/query.ts#L5039),
especially the member list at line 5138, uses `Object.entries(...).map(...)`.
Build the final member list from own keys without the intermediate entry tuples
and array. Apply the same scrutiny to the nearby variant-arm lists only where
the same change is relevant.

The whole compiler accounts for **1.92 KiB/op / 6.52%** of lookup allocation
and **2.03%** of its active self CPU. Again, only some of that cost is removable.
Keep readers batch-local: they capture the current provider parser. Caching them
on shared shapes would cross a real lifetime boundary. Preserve own-key
semantics, nullable/absent handling, variant order, and middleware behavior.

**3. Use the existing string overload for constant SQL fragments.**
For literal-only internal calls, compare `sql.raw` tagged `TRUE` with
`sql.raw("TRUE")`. The existing string overload avoids the tagged-template
reduction while still creating a fresh Sql and preserving snapshots. Relevant
constant call sites are in
[standard-sql.ts](../../../src/adapters/shared/standard-sql.ts) and
[sqlite-adapter.ts](../../../src/adapters/databases/sqlite/sqlite-adapter.ts).
Do not rewrite interpolated templates or alter the public raw implementation.

The isolated experiment measured **26.66 → 11.77 ns CPU** and approximately
**272 → 145 sampled bytes per construction** (medians, five fresh-process pairs).
This is a genuine *micro* result: roughly **15 ns and 127 bytes per call**, not
an ORM speedup. One candidate timing replicate was an outlier; the raw ranges
are retained. The raw frame represents roughly 3–4% of allocation in the small
workload profiles, but that includes non-constant calls too. Measure the complete
operation after changing actual constant call sites before claiming a saving.

**4. Remove an unnecessary asynchronous read-forwarding step.**
The route's [execute](../../../src/query-engine/raptor3/route/client-route.ts#L220)
awaits a result and then performs write-only post-work. The command
[execute](../../../src/query-engine/raptor3/commands/index.ts#L215) is another
forwarder worth checking separately. Their lookup self allocations total about
**0.97 KiB/op / 3.28%**; their self CPU totals roughly **0.75%**. Do not count
their large inclusive profile totals as removable work. Preserve synchronous
throw → promise rejection behavior, observer completion, and write notifications.
This is a hypothesis requiring a focused rejection/order witness, not a blanket
instruction to remove `async` or `return await`.

**5. Small targeted follow-ups, after those four.**
Fuse predicate `Object.entries/filter/map` at
[query.ts:1837](../../../src/query-engine/raptor3/shared/query.ts#L1837).
For backward cursor reads, reuse the reversed order currently computed twice at
[query.ts:3007](../../../src/query-engine/raptor3/shared/query.ts#L3007), and avoid
`flatMap`/spread intermediates in `completeOrder` at line 3070. These are concrete
bounded opportunities, but this baseline does not measure cursor workloads; add
one focused cursor case only when investigating that change.

All five areas are shared SQL/query-engine work, so improvements can benefit
other drivers. SQLite-specific provider changes would not automatically transfer.
Keep the next measurement loop on SQLite as requested.

### What the evidence says not to do first

- Do not replace numbered-placeholder array/join rendering wholesale. In the
  isolated experiment, string concatenation reduced CPU but allocated **12–39%
  more** for 5–1,000 parameters. At 1,000 parameters it was **21.15 → 13.86 µs**
  CPU but **62,019 → 86,016 bytes**. That is a tradeoff, not a CPU-and-memory win;
  it also does not target SQLite's `?` rendering path.
- Do not retain arbitrary arrays in a new raw fast path. An earlier immutable-only
  probe was faster, but extending it to the public array overload would change
  mutation/snapshot behavior. Its receipts are explicitly labelled
  `sql-micro-immutable-only`; they are excluded from recommendations.
- Do not disable safe integer handling. The driver/materialization boundary
  accounts for **82.84%** of sampled allocation at 1,000 rows; `safeIntegers(true)`
  protects values above 2^53 and cannot be discarded for a benchmark score.
- Do not start with generic caches, parser rewrites, removal of validation,
  JSON-carrier checks, or per-value fallback-closure tricks. Several common
  caches/flattening optimizations already exist. The hypothesized fallback
  closure was not a dominant independently attributed allocation site.
- The filtered20 CPU profile is **74.83% native `all`**. JS micro changes cannot
  remove that database floor. Profiles are diagnostic and do not account for
  all process background CPU; they cannot by themselves explain the entire
  aggregate CPU gap.

## Validation

The existing full-operation comparison was extended with selectable libraries,
separate timing/allocation/retained workers, longer timing windows, 0/1/20/10,000
row controls, runtime checks, RSS receipts, and saved CPU/allocation profiles.
No better-drizzle installation is needed for the two-library selection.
Complete expected public values, booleans, ordering and result digests are
checked outside timing. Stock VibORM transport/parser entry points stay intact.

The original fixtures remain 100 users and 1,000 posts; only rows10000 uses
10,000 posts. `rows0` is LIMIT 0, not a normal predicate matching no rows.
Drizzle uses its normal builder for scalar queries and relational API for the
nested query, with no reused/prepared-query cache. Both libraries are awaited by
the same harness; Drizzle's underlying SQLite API is synchronous and VibORM's
is asynchronous. The harness reports both CPU and wall rather than treating
those contracts as identical.

Evidence collected sequentially:

- 270 short-window CPU/allocation/retention workers across nine workloads.
- 90 longer-window timing workers, with five replicates for each library/case.
- 20 diagnostic profile workers: five cases × two libraries × CPU/allocation.
- 54 final-harness smoke workers checking all nine cases and three modes.
- **43 benchmark cases in five existing SQLite/provider-free suites**, including
  full-vs-raw, preparation, borrowed parser, query builder, and schema/client
  construction. Complete benchmark output is in
  [diagnostic-suites.json](diagnostic-suites.json).
- Two isolated SQL hypotheses, six shapes, five alternating pairs and two modes
  (**120 workers** in the final probe), with output and snapshot-isolation checks.
- Package build and the whole-estate TypeScript check passed. This check was run
  once for the changed TypeScript benchmark files; no production behavior changed.

The existing Drizzle SQLite/PGlite benchmark fixtures were repaired for boolean
mapping, object-shaped single-row answers, deterministic order, expected values,
and teardown. The PGlite diagnostic run had already completed before the request
to focus on SQLite. It is not used for the conclusions above; no further provider
runs are planned. Its first ordinary-lane attempt hit the RSS guard, and its
isolated PGlite-lane retry passed under the existing approved ceiling. Both logs
remain available rather than hiding the failed attempt.

Useful stage diagnostics: a 20-row relation took **27.17 µs** for exact raw driver
execution, **34.47 µs** with its prepared parser, and **48.60 µs** for the full
operation. Preparation alone was **9.18 µs** and borrowed parser alone **6.54 µs**.
These separately warmed seams are not an additive accounting identity. Schema
construction measured **5.63 µs** and schema + client construction **30.48 µs**;
that is warm in-process construction, not module import or a true process cold
start. The historical benchmark title is broader than what it measures.

Reproduction commands are in [benchmarks/README.md](../../../benchmarks/README.md).
The raw reports include code/build identities. Exact earlier harness bytes are
saved as `short-window-harness.mjs.txt`, `steady-harness.mjs.txt`, and
`profile-harness.mjs.txt`; the final harness smoke covers subsequent profiling
metadata and lint repairs. Production build hashes agree across these runs.
[profile-summary.json](profile-summary.json) maps profiles to current TypeScript
through sourcemaps, with self and overlapping inclusive attribution kept separate.
The only missing-map warning is for the benchmark's own uncompiled JavaScript.

## Risks

This is an exploratory SQLite baseline on one machine/runtime and the installed
Drizzle version, not a production concurrency, network, prepared-Drizzle, native
memory, or cross-provider qualification. Native profiling, allocation sampling,
and forced-GC observations have distinct limits. No promised percentage gain is
attached to an unimplemented change, and no microbenchmark result substitutes
for a full-operation before/after comparison.

The recommended next slice is **projection outputs first**, then reader temporary
arrays, then literal raw call sites. For each, use the affected SQLite workload
and the narrow correctness check for that boundary. Reuse this baseline, avoid
repeated broad test runs during tuning, and do one consolidated validation when
the chosen small patch is ready.
