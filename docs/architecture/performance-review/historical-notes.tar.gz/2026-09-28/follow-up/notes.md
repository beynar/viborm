# Remaining shared-engine allocation candidates

Read-only follow-up to the first three implemented micros. No production code
was changed. SQLite is only the measurement backend; the optimization scope is
the shared query engine. Three allocation profiles were captured from the verified candidate
build: `unique`, `rows20`, and `relation20`. No tests, build, or full timing matrix
was run. These observations identify places to measure; they do not establish
the performance of an unimplemented change.

## Small next changes

| Candidate | Current construction | Smallest proposed change | Boundary to preserve |
|---|---|---|---|
| Stateless read callbacks | `Queries.read` creates a local `rowSet` function and per-read result functions. `findUnique` and `findFirst` have identical first-row callbacks; `findMany` captures only the backward flag. | Use shared first-row, identity, and reverse-result functions; select the correct function while preparing the read. Move the stateless collection-shape constructor out of the per-read body. | Keep empty singular results as `null`, negative-take reversal, and fresh result/fallback objects. |
| Filter predicate intermediates | `prepareOperations` performs `Object.entries(filter).filter(...).map(...)`. | Build the final predicate list in one pass, avoiding entry tuples and the filtered array. | Preserve own-key order, `mode`/`path` exclusions, recursive `equals`/`not`, and freeze boundaries. Inputs here have already passed admission. |
| Reader member wrappers | `compileReader` builds `{ field, read }` for every selected field, once per decoded batch. | Retain the keys array and build a parallel readers array; consume them by index. | Keep readers batch-local and preserve member order, own-property reads, and fresh public rows. Measure the tradeoff before keeping the less self-describing representation. |
| Read-only asynchronous forwarding | The route awaits every operation although its post-work concerns writes; the prepared command's `execute` adds another async forwarding layer. | Give reads a direct promise-forwarding path. | Preserve synchronous-throw-to-rejection conversion, observer order, write notification timing, and rejection handling. This needs more care than the construction-only changes. |

Exact source locations at this snapshot:

- Read callbacks: [query.ts:3286](../../../../src/query-engine/raptor3/shared/query.ts#L3286).
- Filter intermediates: [query.ts:1837](../../../../src/query-engine/raptor3/shared/query.ts#L1837).
- Reader wrappers: [query.ts:5145](../../../../src/query-engine/raptor3/shared/query.ts#L5145).
- Async forwarding: [client-route.ts:220](../../../../src/query-engine/raptor3/route/client-route.ts#L220), [commands/index.ts:215](../../../../src/query-engine/raptor3/commands/index.ts#L215).

The stateless callbacks and filter intermediates are the best next small patch.
The reader representation and async forwarding deserve separate before/after
measurements so their tradeoffs are visible.

## Larger repeated function construction

The prepared-operation factory at
[commands/index.ts:158](../../../../src/query-engine/raptor3/commands/index.ts#L158)
declares three local helpers and returns two getters plus three methods for each
operation. The route at
[client-route.ts:169](../../../../src/query-engine/raptor3/route/client-route.ts#L169)
returns another getter and five methods. These implementations are identical
between operations; their captured state differs.

An implementation of these existing handles with shared prototype methods could
keep state per operation while avoiding repeated method-function construction.
This is worth a separate prototype, not a blanket conversion of closures into
classes. Preserve lazy admission, each handle's memoized args/read, detached-call
contracts where applicable, driver binding, and batch/error behavior. The two
factory frames together account for about 1.97 KiB/op of sampled lookup self
allocation; that includes necessary state and is not a forecast of savings.

## Current profile evidence

On the current `unique` profile, `compileReader` accounts for about **1.60 KiB/op
(5.92%)** of sampled self allocation. The route and prepared-command `execute`
frames together account for about **0.91 KiB/op (3.36%)**. The route's operation
factory accounts for another **1.11 KiB/op (4.13%)**, but its lazy handles also
own necessary state and behavior. These whole-function totals are **not
removable-allocation estimates**. The profiler does not isolate each proposed
closure or wrapper removal.

See [profiles.json](profiles.json) for workload counts and build/runtime
identities, [profile-summary.json](profile-summary.json) for source-mapped
allocation sites, and the three adjacent `.heapprofile` files for raw evidence.
The profile summaries use call-frame source positions, not allocation-site
instruction positions. One sample per workload is diagnostic, not a keep gate.

## Smaller opportunities and exclusions

- Backward cursor pagination computes the same reversed order twice. Compute it
  once in [query.ts:3007](../../../../src/query-engine/raptor3/shared/query.ts#L3007)
  and pass it to both consumers. None of the three profiled cases uses a cursor.
- Do not globally cache compiled readers or share `fieldReader`'s per-value
  fallback through mutable state. They capture execution-specific parsing and
  the current input; middleware can re-enter or retain callbacks. A new special
  bypass for stock parsers is not justified by these profiles.
- Model/operation proxies are already memoized, write-attempt state is already
  lazy on reads, and trusted execution contexts are reused. No new cache is
  needed for those mechanisms.
- Provider parameter conversion and SQLite statement caching are outside this
  shared-engine optimization scope.

Any next patch should reuse the SQLite comparison and a narrow correctness
selection. No performance percentage is promised before that comparison.
