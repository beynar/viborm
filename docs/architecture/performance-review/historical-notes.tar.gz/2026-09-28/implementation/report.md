# Outcome

Implemented the three measured simplifications in the shared query engine and
SQLite/shared SQL helpers. The combined patch reduces sampled allocation by
3.6–5.0% on the five small SQLite workloads. Timing is inconclusive. Keep the
patch for its consistent reduction in temporary allocations; do not advertise
an end-to-end CPU speedup.

1. Projection lowering builds only the aliased columns its SELECT or RETURNING
   consumer uses. DISTINCT obtains names only when required. Recursive JSON
   lowering uses the same per-field expression owner without unused aliased
   columns, tuple arrays, or the old wrapper object.
2. Reader compilation iterates internal shape keys directly, avoiding temporary
   Object.entries pairs. Reader lifetime, decoding, and result ownership stay
   with their existing owners.
3. Twenty-one constant SQL call sites use the existing string overload of
   sql.raw. Interpolated SQL and the public SQL implementation are unchanged.
   Each call still constructs its own fragment; there is no mutable global cache.

Sampled allocation, KiB per complete operation (five-run medians; lower is better):

| Workload | Before | After | Median change | Five paired changes |
|---|---:|---:|---:|---:|
| unique | 28.54 | 27.11 | -5.0% | -5.4% to -4.7% |
| filtered20 | 42.82 | 41.27 | -3.6% | -4.5% to -2.9% |
| relation20 | 53.48 | 51.16 | -4.3% | -4.9% to -3.7% |
| insert | 33.19 | 31.83 | -4.1% | -5.0% to -3.4% |
| rows20 | 47.15 | 45.21 | -4.1% | -4.6% to -3.5% |
| rows1000 | 804.15 | 802.78 | -0.2% | -0.3% to +0.5% |

The first five cases improve in every pair, saving approximately 1.4–2.3 KiB per
operation. The 1,000-row case is within sampling variation: one pair regresses,
and the median change is only 0.17%. These are allocation/churn measurements,
not retained-heap or process-RSS reductions.

CPU and wall time, microseconds per operation:

| Workload | CPU before → after | CPU median change | Median paired CPU change | Wall before → after | Wall median change |
|---|---:|---:|---:|---:|---:|
| unique | 16.34 → 15.36 | -6.0% | -9.0% | 12.20 → 11.50 | -5.7% |
| filtered20 | 104.66 → 102.13 | -2.4% | +0.8% | 97.07 → 93.72 | -3.4% |
| relation20 | 53.62 → 54.12 | +0.9% | +1.1% | 44.14 → 44.90 | +1.7% |
| insert | 20.14 → 20.24 | +0.5% | -0.2% | 16.45 → 16.59 | +0.9% |
| rows20 | 40.47 → 39.37 | -2.7% | -2.0% | 32.02 → 33.14 | +3.5% |
| rows1000 | 511.63 → 497.22 | -2.8% | +3.4% | 508.09 → 488.40 | -3.9% |

Do not read the negative CPU medians as proven speedups. Several cases change
sign between the ratio of medians and the median of paired ratios; relation and
insert CPU medians also rise slightly. For example, rows1000 CPU changes range
from −12.5% to +8.5% across pairs. The data do not resolve small timing gains or
regressions. Full values, median absolute deviations, ranges, and paired changes
are in [summary.json](summary.json).

# Validation

Five alternating before/after pairs, six workloads, separate fresh timing and
allocation workers: 120 measured workers, about 159 seconds total. Node 24.21.0,
V8 13.6.233.17-node.53, macOS arm64, Apple M4 Pro, better-sqlite3 12.6.0. Timing
uses the existing harness at scale 10, including warmup. Heap sampling uses a
4,096-byte interval and includes collected objects. No other tests, builds, or
benchmarks from this task ran concurrently with measurement.

The original built package was preserved before edits and its hash matched the
[initial baseline](../report.md). The candidate was built once after the edits.
Both arms used the same harness, dependencies, fixture, and warmup rules.
Complete public results were checked against independent expected answers before
each measured loop. SQL witnesses and result digests matched across all samples.
The current package build, saved candidate, source patch, harness, and lockfile
were checked again against the measurement identities after the run.

- Baseline source: 778912983181e6b4049a3639a5f498b4cb9e83d0.
- Baseline .mjs hash: 7cae80f49f7c0728b131dc5023b52e2f3a086afa5677210416b1396997505625.
- Candidate .mjs hash: e7931d3ba0b67605b6bd63c21933cc27e63f8387f0d672a9d197ba5ab69f2205.
- Exact source delta: [production.patch](production.patch).
- Raw measurements: [paired.json](paired.json), plus the ten per-arm JSON files.
- Coordinator: [compare.mjs](compare.mjs); build locations: [implementation-builds.json](../implementation-builds.json).
- Archived measured harness: [better-drizzle-compare.snapshot.mjs](better-drizzle-compare.snapshot.mjs).

The build directories are local temporary artifacts, not portable source
checkouts. To reproduce, build the baseline commit and that commit plus the
production patch in separate directories with the pinned lockfile, keep their
external dependencies resolvable, and give their dist paths to the harness with
--build-dir. The coordinator records the actual paths used for this run. The
harness snapshot is archival: restore it under benchmarks/ to preserve its
repository-relative paths.

The focused runtime checks passed: 66 tests across result decoding, result
placements, order/projection, SQLite recursive SQL, and projection preparation.
This covers nested DISTINCT, recursive carriers, RETURNING, and parser isolation.
The separately adapted memo-isolation review file is outside the configured test
include set; it was typechecked, not executed. One native whole-estate typecheck
and one package build passed. Logs: [checks.log](checks.log),
[projection-checks.log](projection-checks.log), [typecheck.log](typecheck.log),
[build.log](build.log). No broad runtime suite was run.

# Risks

This is a local SQLite comparison, not the cross-provider operation-pipeline
keep gate. Shared code changes can affect other databases, but their performance
was not measured. Drizzle was not rerun for this implementation comparison;
its earlier baseline remains separate. The effects of the three edits were
measured together, so no individual end-to-end gain is attributed to one edit.

Timing variation prevents a confident CPU or latency conclusion. No candidate
retained-heap measurement was taken. The supported result is reduced temporary
allocation on small operations, not a claim that the broader Drizzle gap is
closed or that resident memory use falls by the same percentage.
