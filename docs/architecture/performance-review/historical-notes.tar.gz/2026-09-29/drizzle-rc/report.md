# VibORM vs latest published Drizzle 1.0 RC — SQLite, 2026-09-29

## Outcome

**VibORM leads on ID lookup and the relation read. Drizzle leads on filtered
reads, returning inserts and full-row reads, and allocates less temporary
JavaScript memory in five of six cases.** The large flat-read and allocation
gaps are consistent across all five pairs. Insert wall time is less consistent:
Drizzle leads in four pairs, while its CPU cost is lower in all five.

Only **Drizzle 1.0.0-rc.5-5935859** was measured against VibORM. It was the newest
published `1.0.0-rc.*` build at registry lookup, published on 2026-09-09.
[registry-selection.json](registry-selection.json) records the selection.
The official `rc` tag still pointed at RC 4; that version was installed during
initial setup before the scope correction, but was never a measured comparison
arm. No third library was benchmarked.

Every pair below is **VibORM / Drizzle**. Lower is better. These are medians of
five fresh-process samples for each library, workload and measurement mode.

| Operation | Wall µs/op | CPU µs/op | Sampled JS allocation KiB/op |
| --- | ---: | ---: | ---: |
| Find one by ID | 10.26 / 12.93 | 11.18 / 13.36 | 23.78 / 9.88 |
| Filter + order, 20 rows | 91.30 / 85.80 | 95.60 / 86.78 | 36.15 / 15.24 |
| 20 rows + author | 41.77 / 54.54 | 46.55 / 57.07 | 45.50 / 55.44 |
| Insert + return one row | 15.49 / 14.51 | 17.72 / 15.36 | 29.33 / 10.53 |
| Read 20 full rows | 27.62 / 22.37 | 31.59 / 23.76 | 41.38 / 18.66 |
| Read 1,000 full rows | 482.24 / 309.04 | 486.16 / 315.54 | 797.26 / 318.41 |

Percent changes use Drizzle as the denominator. Negative means less cost for
VibORM; positive means more cost for VibORM.

| Operation | Wall change | CPU change | Allocation change |
| --- | ---: | ---: | ---: |
| Find one by ID | -20.6% | -16.3% | +140.6% |
| Filter + order, 20 rows | +6.4% | +10.2% | +137.2% |
| 20 rows + author | -23.4% | -18.4% | -17.9% |
| Insert + return one row | +6.8% | +15.4% | +178.5% |
| Read 20 full rows | +23.4% | +32.9% | +121.8% |
| Read 1,000 full rows | +56.0% | +54.1% | +150.4% |

The ranking for wall time and CPU agrees in all five pairs for each workload
except insert wall time. Allocation ranking agrees in all five pairs for every
workload. This is stronger evidence than a small difference between medians.
It is still a local benchmark, not a confidence interval or a production SLA.

| Operation | Wall MAD, VibORM / Drizzle (µs) | CPU MAD, VibORM / Drizzle (µs) |
| --- | ---: | ---: |
| Find one by ID | 0.12 / 0.09 | 0.14 / 0.09 |
| Filter + order, 20 rows | 0.47 / 0.24 | 0.10 / 0.04 |
| 20 rows + author | 0.13 / 0.50 | 0.13 / 0.32 |
| Insert + return one row | 0.31 / 0.22 | 0.17 / 0.27 |
| Read 20 full rows | 0.21 / 0.41 | 0.28 / 0.35 |
| Read 1,000 full rows | 7.32 / 3.63 | 7.14 / 2.10 |

Full samples, min/max, MAD, paired changes and SQL are in
[summary.json](summary.json). All outliers remain in the raw reports.

### Retained memory

| Held result | VibORM | Drizzle |
| --- | ---: | ---: |
| 1,000 full rows | 203.74 KiB | 203.28 KiB |
| 10,000 full rows | 2101.61 KiB | 2102.00 KiB |

Held results occupy essentially the same heap. These are post-GC deltas per
held result, measured while holding 30 results of 1,000 rows or 10 results of
10,000 rows. They measure returned data, not allocation churn or long-term
leak behavior. No retention soak was rerun for this comparison.

| Retained-mode worker | VibORM peak RSS | Drizzle peak RSS |
| --- | ---: | ---: |
| rows1000 | 93.33 MiB | 80.75 MiB |
| rows10000 | 219.53 MiB | 155.33 MiB |

RSS is the median of whole-worker lifetime high-water marks, including imports,
fixture, warmup, JavaScript and native SQLite memory. It is not per-query memory
or a steady-state service memory forecast.

## Validation

- Node 24.21.0, V8 13.6.233.17-node.53, Apple M4 Pro, macOS arm64.
- Exact shared native better-sqlite3 12.6.0 module. Isolated Drizzle install,
  exact version and registry integrity saved in [setup.json](setup.json).
- Local VibORM source includes all three performance passes from the prior
  investigation. This is a workspace build, not a measurement of a newly
  downloaded npm release. Its dist fingerprint is
  `3299ea848d57f061696acab2160e1932b21c4548ee4e347467be21670c3bf19f`.
- Source fingerprint:
  `ab303352a879b639ec85aae83a8c0c3966bed64fd83e75c4ab9dd20fcec228e9`.
  Source and dist match the prior verified build. The dist was copied into the
  isolated setup and fingerprinted before and after measurement.
- 120 CPU/allocation workers and 20 retained-result workers; five rounds,
  alternating library order. Every worker checked the complete public answer
  against the independent fixture. Cross-library result digests match.
- The two-worker relation smoke check is separate and excluded from results.
- Timed windows use scale 10: 100,000 ID lookups; 30,000 filtered, relation or
  20-row reads; 50,000 returning inserts; 4,000 reads of 1,000 rows. Warmup is
  one quarter of each timed count. Allocation runs use separate shorter windows
  and V8's 4,096-byte sampling interval, including collected objects.
- All six workloads produce one captured statement per operation in both ORMs.
  SQL capture is outside measurement and the original native prepare method is
  restored before warmup. Bound parameters are not intercepted by this harness.
- Stock driver paths, default mapper configuration, fresh query construction
  on every call, no plugins, application cache or reused prepared query handles.
  Both paths use the same awaited loop. Drizzle v1 uses its documented
  `defineRelations` and `{ client, relations }` driver configuration.
- Installed Drizzle `better-sqlite3/driver.js` calls
  `jitCompatCheck(config.jit)`; its implementation returns false when the option
  is absent. This measures the default non-JIT configuration, not opt-in JIT.
- Source, root package manifest, lockfile and measured benchmark remained
  unchanged throughout the run. No production changes or broad test suites.
- The bounded run completed in 144.13 seconds with 336.9 MiB sampled peak
  process-group RSS; teardown verified. That coordinator RSS differs from the
  per-worker retained-mode figures above.

Reproduce the measured run with the retained setup paths:

```sh
node scripts/run-node-safe.mjs 768 600000 \
  docs/architecture/performance-2026-09-29/drizzle-rc/run.mjs
```

[cpu-allocation-command.json](cpu-allocation-command.json) and
[retained-command.json](retained-command.json) contain the exact executable,
arguments and working directory. The reusable comparator accepts
`--drizzle-dir /absolute/isolated-install` alongside `--libraries viborm,drizzle`.
`setup.executed.mjs` preserves initial setup; `setup.mjs` now resolves and
installs only the newest published RC for future reproductions.

Raw receipts: [cpu-allocation.json](cpu-allocation.json),
[retained.json](retained.json), [run.log](run.log).
The measured harness is [benchmark.snapshot.mjs](benchmark.snapshot.mjs).

## Risks and interpretation limits

The fixture remains unchanged: 100 users, 1,000 posts, primary-key indexes only.
The 10,000-row memory case increases posts to 10,000. Filtered reads are still
unindexed. VibORM appends an ID tie-breaker; Drizzle orders only by views.
Views are unique in this fixture, so the actual ordered results are identical,
but the generated SQL and general tie guarantees differ. This comparison is
end-to-end operation cost, not isolated ORM overhead with identical SQL.

Allocation sampling covers JavaScript heap churn, not all native allocations.
CPU includes background V8 work and is distinct from wall time. System load
was not zero; alternating adjacent library workers and retaining all samples
limit interpretation errors, but do not eliminate scheduling variation.

The old Drizzle 0.43.1 run used a different VibORM build and was measured on a
different day. Do not subtract its numbers from these to claim a controlled
Drizzle version speedup. Against the latest RC measured here, filtered20 is
clearly no longer the only gap: full-row reads and temporary allocations show
larger differences. This run does not attribute those differences to a specific
internal cause, nor does it establish results on other databases or opt-in JIT.

Official API references: [v1 upgrade](https://orm.drizzle.team/docs/upgrade-v1),
[relations](https://orm.drizzle.team/docs/relations),
[relational queries](https://orm.drizzle.team/docs/rqb).
