# Drizzle gap implementation

Goal: implement positional transport, specialized decoding and omitted unused
read selector metadata in the isolated `bey/drizzle-gap` worktree. Use SQLite
for measurement and keep engine decoding and predicate changes provider-neutral.

Baseline: the parent checkout source and built JavaScript were copied and
verified before editing. Source SHA-256:
`ab303352a879b639ec85aae83a8c0c3966bed64fd83e75c4ab9dd20fcec228e9`.
Build SHA-256:
`3299ea848d57f061696acab2160e1932b21c4548ee4e347467be21670c3bf19f`.
Comparator: the same isolated `drizzle-orm@1.0.0-rc.5-5935859` install used by
the preceding report. No newer version claim is made by this campaign.

1. Reuse the driver's typed-statement lifecycle for an internal positional
   read capability. Keep public object rows, safe integers, lifecycle/error
   behavior and custom/parser fallback. Decode positional cells through the
   existing prepared projection visitor; keep nested carriers unchanged.
2. Bind scalar type, list, identifier and codec decisions before reading cells.
   Keep null, absent, malformed and unsafe-value errors and driver middleware.
   Keep readers scoped to the decoded batch; add no persistent reader cache.
3. Prepare dependency facts only when a selector consumer requests them. Keep
   all write/composition consumers on the complete existing meaning and keep
   unique-discriminator SQL semantics independent of metadata collection.

Done when all three changes are present, focused contract suites and complete
type checking pass, source-bound paired measurements compare current baseline,
candidate and Drizzle wall/CPU/allocation, and retained-memory probes show the
limits of the implementation. Preserve conflicting results and report them;
allocation alone does not establish wall improvement. Do not change indexes,
SQL ordering, required validation, precision or the client proxy cache.
