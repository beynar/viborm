## Outcome

Implemented all three candidates in the isolated `bey/drizzle-gap` worktree:
internal positional collection transport, scalar decoding decisions before the
row loop, and omission of unused read-selector dependency facts. The shared
engine changes remain provider-neutral; positional transport is currently
implemented only for the SQLite3 driver.

The clear gain is large scalar collections. For 1,000 rows, median wall time
fell **464.87 → 377.54 µs** (18.8%), CPU **468.64 → 383.15 µs** (18.2%),
and sampled allocation **798.11 → 376.78 KiB** (52.8%). The same-round
comparison improved in all five rounds. Drizzle takes **299.45 µs**, so the
wall-time gap narrowed from **55% to 26% slower than Drizzle**. Unique reads
fell **10.30 → 9.35 µs** and improved in all five rounds; their median paired
change is smaller, at −5.81%.

Filtered-20, relation-20, insert and 20 scalar rows show no consistent wall-time
gain. Filtered-20 allocation fell by about 7%, and 20-row allocation by about
14%; those reductions alone do not establish lower latency. VibORM remains
faster than this Drizzle configuration on unique and relation reads, while
Drizzle remains faster on the other four workloads.
Insert allocation rose about 1.5% in paired samples; this pass provides no
clear write improvement.

Wall time, **µs per complete operation**, five-round medians:

| Workload | VibORM before | VibORM now | Drizzle RC | Paired change | Lower in rounds |
| --- | ---: | ---: | ---: | ---: | ---: |
| Unique row | 10.30 | 9.35 | 12.59 | -5.81% | 5/5 |
| Filtered 20 | 88.99 | 87.74 | 83.90 | -0.54% | 3/5 |
| Relation 20 | 40.41 | 40.41 | 51.92 | +0.23% | 1/5 |
| Insert | 14.16 | 14.07 | 13.51 | +0.02% | 2/5 |
| 20 scalar rows | 26.94 | 26.61 | 21.89 | -0.99% | 3/5 |
| 1,000 scalar rows | 464.87 | 377.54 | 299.45 | -20.25% | 5/5 |

CPU, **µs per complete operation**, total user plus system process CPU:

| Workload | VibORM before | VibORM now | Drizzle RC | Paired change | Lower in rounds |
| --- | ---: | ---: | ---: | ---: | ---: |
| Unique row | 11.21 | 10.22 | 13.05 | -8.82% | 5/5 |
| Filtered 20 | 92.60 | 92.56 | 85.28 | +0.62% | 2/5 |
| Relation 20 | 44.63 | 44.58 | 54.75 | -0.52% | 4/5 |
| Insert | 16.51 | 16.19 | 14.38 | -1.12% | 4/5 |
| 20 scalar rows | 30.78 | 30.70 | 23.53 | -0.28% | 3/5 |
| 1,000 scalar rows | 468.64 | 383.15 | 308.58 | -19.09% | 5/5 |

Sampled temporary allocation, **KiB per complete operation**:

| Workload | VibORM before | VibORM now | Drizzle RC | Paired change | Lower in rounds |
| --- | ---: | ---: | ---: | ---: | ---: |
| Unique row | 23.75 | 23.21 | 9.96 | -1.74% | 5/5 |
| Filtered 20 | 36.19 | 33.47 | 15.22 | -6.99% | 5/5 |
| Relation 20 | 45.43 | 43.65 | 55.47 | -3.91% | 5/5 |
| Insert | 29.20 | 29.69 | 10.62 | +1.47% | 1/5 |
| 20 scalar rows | 41.52 | 35.73 | 18.55 | -13.60% | 5/5 |
| 1,000 scalar rows | 798.11 | 376.78 | 318.07 | -52.87% | 5/5 |

“Paired change” is the median percentage change against each same-round
baseline. It can differ from the change between independently computed medians.
“Lower in rounds” reports the direction of those five pairs. Raw values, ranges
and median absolute deviations are in [summary.json](summary.json). For the
1,000-row wall medians, MAD is 5.80 µs before, 7.00 µs now and 0.86 µs for
Drizzle. Five rounds describe this machine; they are not confidence intervals.

The isolated controls identify transport as the main contributor. These are
three-round wall medians in µs from the **initial implementation**, before the
collection-only correction:

| Workload | Before | Decoder only | Preparation only | Transport only | Initial combined |
| --- | ---: | ---: | ---: | ---: | ---: |
| Unique row | 10.93 | 10.12 | 9.93 | 11.76 | 11.86 |
| Filtered 20 | 90.15 | 90.56 | 90.43 | 90.94 | 90.34 |
| 1,000 scalar rows | 465.63 | 468.21 | 464.00 | 371.83 | 375.07 |

The transport control retains safe integers and the old decoder/preparation.
It reproduces the large-read gain. Decoder specialization alone has no clear
large-read gain; its possible fixed-cost benefit is concentrated in unique
reads. Preparation alone reduces selector allocations but contributes little
on these database-heavy collection workloads. Effects overlap; adding the
individual percentage changes is invalid.

The first combined campaign exposed a single-row penalty: **9.97 → 11.37 µs**.
Column discovery and array transport cost more than they save for one row.
The final implementation selects positional transport through the read's
existing **collection** value kind. Count, existence and single-row reads keep
the ordinary transport. The final campaign above measures that correction.
Both campaigns remain preserved in [pilot.json](pilot.json) and
[ablation.json](ablation.json).

The production changes are confined to five files, relative to the copied
performance baseline; [implementation.patch](implementation.patch) excludes
inherited changes. The existing projection visitor decodes both root formats.
Scalar codecs still validate each value, but choose the type/list/identifier
branch before iterating rows. SQL-only read selectors use the same predicate
interpreter without dependency summaries. Write/composition selectors retain
the complete facts.

The internal driver capability reuses typed statement transforms, observers,
parameter handling and error normalization. Eligibility is rechecked after
asynchronous work and before synchronous decoding. Changed/custom driver or
parser surfaces use keyed rows. Public driver results, raw calls, transactions
and prepared array batches keep their object format. Positional arrays are
borrowed and never mutated; each public collection and document is fresh.
Native integer precision remains enabled. Missing aliases must remain absent,
including when an inherited negative array property exists.

Held-result heap, **KiB per public result**, three-round medians:

| Held public result | Before | Now | Drizzle RC |
| --- | ---: | ---: | ---: |
| 1,000 rows | 203.73 | 204.21 | 203.54 |
| 10,000 rows | 2101.60 | 2101.61 | 2102.72 |

Result retention remains essentially unchanged because callers receive the
same public objects. The 1,000-row timing worker's median peak RSS was
**146.77 → 145.52 MiB**, versus **136.66 MiB** for Drizzle. Allocation savings
do not imply a proportional RSS reduction. These worker peaks include setup,
warmup and allocator high-water marks.

The mixed soak ran 200,000 operations after 20,000 warmup operations. Post-GC
heap stayed within **10.06–10.46 MiB**, ending 0.22 MiB above its warm checkpoint.
All **420** sampled completed handles/results were collected, as were all
**336** samples after 32-way bounded overlap. Holding 500 completed handles
raised heap **10.26 → 20.48 MiB**; releasing them returned it to **10.35 MiB**.
The first 100-client probe still rose during warmup, so the existing extended
probe ran 1,000 fresh clients after 50 warmup clients. All **5,000** sampled
clients/drivers/database wrappers/models were collected. Its last 500-client
window stayed within **10.765–10.831 MiB**. These probes found no accumulating
operation graph on the exercised paths.

## Validation

The worktree was seeded with the parent checkout's tracked changes so the
baseline includes the preceding performance work. It is not an untouched HEAD
comparison. The inherited patch and exact source/build snapshots are preserved
in [snapshots.tar.gz](snapshots.tar.gz); the final source/build snapshot and
benchmark scripts are also included. No dependency or lockfile change was
made for this campaign. The original checkout was not edited.

- Runtime: Node v24.21.0 / V8 13.6.233.17-node.53, macOS arm64, Apple M4 Pro.
- Comparator: **drizzle-orm@1.0.0-rc.5-5935859**, the same pinned RC as
  the preceding comparison, with its default mapper and JIT disabled. This is
  not a claim that it remains the newest published version.
- Native dependency: better-sqlite3 12.6.0 from this repository for all arms.
- Final comparison: 180 isolated workers, five rotating-order rounds,
  six workloads, independent time and allocation windows. Each arm builds fresh
  operations/statements; there is no prepared-statement reuse.
- Retained-result comparison: 18 isolated workers, three rotating-order rounds,
  1,000 and 10,000 rows. The soak and extended disposal probe run separately.
- Each worker checks full public values against an independent fixture both
  during SQL recording and after restoring the exact native `prepare` property
  descriptor. The previous recorder restored the function but left an own
  property, which would disable the new stock transport path. The same corrected
  harness is used for all arms in these campaigns.
- Baseline/candidate SQL **text** and result digests match for every measured
  workload. Bound parameters were not recorded by the benchmark. The selector
  equivalence test separately compares SQL and parameter values for its tested
  simple, compound, nested, negated and field-reference cases.
- Source, bundle, harness, package, lockfile and Drizzle-code hashes are checked
  before each round and after the campaigns. Final source:
  `8bd85d6f23ea64d2a191a93736cd25c3b84b2dc863a29088ec59390fd1f8bf5a`.
  Final JavaScript build: `983f91a35680cd6a9639e4d06c97b3c946036c37f453e1d7f4edc2216216470d`.
- **383 distinct focused tests passed** across decoder placements/lists,
  selector dependencies, read/filter/order behavior, SQLite execution/integer
  precision/consumable-result boundaries, extension lifecycle and 188 live
  SQLite scalar roundtrip cases. New tests cover alias reordering/absence,
  malformed scalar values, public keyed rows, middleware fallback, frozen
  transport rows and SQL-only selector equivalence. The inherited-negative-index
  regression failed before its fix and passed after it.
- Complete native TypeScript check passed (5.61 s); package build passed
  (2.30 s); Biome check passed on the five production files, benchmark harness
  and decoder tests. The selector-preparation file retains eight pre-existing
  top-level-regex lint findings outside the new test. `git diff --check` passed.
  Every bounded launcher verified teardown. No all-provider suite was run.

Raw evidence: [main.json](main.json), [retained.json](retained.json),
[retention.json](retention.json),
[lifecycle-retention.json](lifecycle-retention.json). The [manifest](manifest.json)
seals the evidence, scripts and snapshots. Re-run the measured campaign from
the worktree with the pinned Node executable:

```sh
node scripts/run-node-safe.mjs 768 360000 docs/architecture/performance-2026-09-29/drizzle-gap/run.mjs main
node scripts/run-node-safe.mjs 768 180000 docs/architecture/performance-2026-09-29/drizzle-gap/run.mjs retained
node scripts/run-node-safe.mjs 768 180000 benchmarks/engine-retention-soak.mjs --output /absolute/retention.json
node scripts/run-node-safe.mjs 768 180000 benchmarks/engine-retention-soak.mjs --lifecycle-only --output /absolute/lifecycle.json
```

The coordinator reads the preserved sibling `../performance` builds and the
isolated Drizzle installation recorded in its metadata. The snapshots archive
provides those exact inputs if the local temporary paths disappear. Re-running
into this directory replaces its campaign files; copy the coordinator/evidence
directory first if preserving this measured series.

## Risks

These measurements cover finite SQLite workloads and this exact Node/native
runtime. Shared decoder and selector changes affect other providers, but their
live-provider behavior was not benchmarked here. The focused strict-codec
contracts and typecheck passed; full provider evidence remains separate.

The filtered fixture still scans and sorts without a supporting index. VibORM
still adds its identity tie-breaker to the views ordering. The fixture's unique
views make both ORM answers equal, but the general ordering contracts differ.
No SQL/index rewrite was introduced, and the filtered wall-time gap remains.

Allocation sampling estimates JavaScript churn, including collected objects;
it excludes native C++ storage. Total process CPU includes background V8 work.
Held-result probes leave a non-zero released-window residual of roughly one
result, so those same-frame probes alone do not establish collectability.
The yielded soak provides the separate collection evidence. Bounded heap trends
and sampled WeakRefs do not prove that every workload or extension is leak-free.

The pre-existing client proxy cache still grows by **7.69 MiB per 10,000 distinct
unknown property names**. It is unchanged, as requested. Typed operations use
bounded valid names; the engine findings do not remove that separate cache risk.
