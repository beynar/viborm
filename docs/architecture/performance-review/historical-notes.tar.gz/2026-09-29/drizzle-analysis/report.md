# What Drizzle's latest RC does better — SQLite diagnosis

## Outcome

Two concrete differences explain much of the observed flat-read gap:
**Drizzle uses cheaper native transport rows, and its default mapper performs
less work for each value.** Its low allocation is not primarily evidence of
better function-allocation hygiene. On the large flat read, the native fetch
accounts for most of the difference in sampled JavaScript allocation.

The measured package is `drizzle-orm@1.0.0-rc.5-5935859`, copied byte-for-byte to
`/.reference/drizzle-orm-1.0.0-rc.5-5935859/` relative to the repository root.
These findings concern the default non-JIT implementation used by the
[full-operation comparison](../drizzle-rc/report.md).

### 1. Positional transport makes the native result cheaper

Drizzle's select preparation requests `arrays`
([async/select.js:13](../../../../.reference/drizzle-orm-1.0.0-rc.5-5935859/sqlite-core/async/select.js)).
Its stock SQLite session uses `stmt.raw().all(...params)`
([session.js:28](../../../../.reference/drizzle-orm-1.0.0-rc.5-5935859/better-sqlite3/session.js)).
The mapper reads `row[i]` and constructs a public object.

VibORM's stock SQLite driver fetches keyed objects and enables `safeIntegers`.
The engine then reads their own keys, converts/validates values and constructs
another keyed public object. Both systems allocate transport rows and public
rows; neither path measured here is zero-copy.

Controlled native execution of **VibORM's exact same SQL and parameters** gives:

| 1,000-row native fetch, reused statement | Wall µs/op | CPU µs/op | Sampled allocation KiB/op |
| --- | ---: | ---: | ---: |
| Keyed objects, safe integers | 287.53 | 290.96 | 672.10 |
| Keyed objects, ordinary numbers | 275.46 | 279.20 | 623.23 |
| Positional arrays, safe integers | 225.89 | 227.79 | 247.45 |
| Positional arrays, ordinary numbers | 214.30 | 216.69 | 204.71 |

Holding safe-integer behavior fixed, positional arrays reduce this native
control's wall time by about **21%** and allocation by about **63%**. Changing
integer transport alone saves roughly 12 µs here, much less than changing the
row representation. These are diagnostic controls, not a candidate production
speedup or an additive decomposition of the full operation.

The full allocation profile independently agrees: native `runStatement` is
attributed **83.90%** of VibORM's large-read sampled allocation. Drizzle's native
fetch is **63.74%** of its much smaller total. This attribution includes native
construction of JavaScript strings, containers and integer values; it does not
mean all that memory was allocated by JavaScript statements in the driver.

The source does not establish which particular V8 property representation
accounts for each byte, and this diagnosis makes no hidden-class/dictionary
claim. The four controlled formats establish the practical difference.

### 2. The mapper chooses conversions before visiting rows

Drizzle's [default mapper](../../../../.reference/drizzle-orm-1.0.0-rc.5-5935859/utils.js)
builds one decoder array before reading rows. It resolves the field category,
codec and custom decoder once. Base columns mark their identity encoder and
decoder with `isNoop` ([column.js](../../../../.reference/drizzle-orm-1.0.0-rc.5-5935859/column.js)).
An ordinary text/int field without a codec stores `undefined` as its decoder.
The inner loop then copies its value directly. For this six-column post
fixture, **five fields have no decoder call; only `published` invokes a
preselected boolean converter**.

The mapper still checks SQL null, walks output paths, and checks decoder
presence. It is an interpreted loop, not generated code. Conversion closures
are created only where needed during mapper preparation.

VibORM already compiles member readers once per decoded batch and reuses the
schema's default projection. However, each non-null physical value still
enters its driver/adapter parser chain and `decodeScalar`. The generic scalar
function tests list/identifier/type decisions while processing each value.
`fieldReader` also constructs an adapter continuation at a value crossing.
V8 may eliminate source-level closures, so their presence is not a count of
real heap allocations.

The isolated parsing controls, both reading frozen provider results, give:

| Parsing 1,000 full rows | Wall µs/op | CPU µs/op | Sampled allocation KiB/op |
| --- | ---: | ---: | ---: |
| VibORM prepared result parser | 157.44 | 163.75 | 112.82 |
| Drizzle default mapper | 81.14 | 83.21 | 102.24 |

This makes parsing a substantial **CPU** opportunity. Its allocation totals are
much closer than the native fetch totals: parser closures do not explain the
large allocation gap by themselves.

The controls are deliberately different boundaries. VibORM's prepared parser
also traverses its result middleware, row normalization and prepared-result
packaging; Drizzle's control calls only its prepared mapper. The VibORM prepared
boundary has an additional outer-row normalization pass compared with its live
read path. Therefore 157.44 versus 81.14 measures these exposed boundaries,
not exact live decoder cost or the amount a production change would save.

The fresh full-operation CPU profiles corroborate a decoding difference:
VibORM's `decodeProjection` is **29.19% inclusive** of non-GC samples, versus
**20.70% self/inclusive** for Drizzle's default row loop. These shares have
different full-operation denominators and cannot be subtracted as timings.
VibORM's `decodeScalar`, row-reader loop and own-key reader are visible costs.

### 3. Some cheaper work comes from different guarantees

Drizzle's ordinary mapper trusts native text/int values. It does not perform
VibORM's required-null, missing-field, strict scalar-domain or safe-integer
checks. Its stock boolean converter is simply `value === 1`.

A small runtime probe through the actual prepared parsers verified:

| Physical result | VibORM | Drizzle default mapper |
| --- | --- | --- |
| Boolean integer `2` | Refuses | Returns `false` |
| Required title is `null` | Refuses | Returns `null` |
| Int value `9007199254740993` | Refuses as outside the safe int domain | Ordinary-number transport has already rounded it to `9007199254740992`, then passes it through |

The native integer control separately confirms the original exact integer
survives `safeIntegers(true)` and rounds with ordinary-number transport.
These are result-boundary probes, not a claim about all Drizzle APIs. Other
Drizzle declarations can explicitly choose bigint/numeric codecs.

The transferable lesson is to resolve immutable decoding decisions once.
Removing strict checks or assuming a custom parser is a no-op changes behavior.
Borrowed provider rows, parser overrides, relations and custom drivers retain
their current trust boundary.

### 4. Simple operations carry a smaller runtime envelope in Drizzle

Drizzle's builder retains its operands directly in mutable config and converts
them into SQL parameters through columns/codecs. It does not run VibORM's
operation payload schema before these calls. VibORM admits and detaches inputs,
rejects unknown keys, applies defaults/transforms, and owns a lazy once-only
operation lifecycle. Those are material product guarantees, not automatically
redundant work.

Drizzle also skips an input encoder explicitly marked `isNoop` during SQL
lowering. That shares the same semantic idea as its output mapper: prove an
identity crossing at its owner rather than invoking it and discovering it
returned the same value.

There is a smaller concrete engine candidate: `newSelectorFacts` creates a
Set, two Maps and a reads array for every prepared selector. `prepareSelector`
may create a unique-values Map too. The ordinary read lowering consumes the
predicate; the located fact consumers are write selection/planning and selector
composition. Producing those dependency facts only for actual consumers could
reduce fixed allocation, provided nested predicates and write consumers still
get the same authoritative prepared meaning. **This is a source-backed
candidate, not a measured gain.**

Equality lowering also defines several helper closures, but there is no proof
that rewriting them would save enough wall time. The profiles give higher
priority to the demonstrated fetch and decode differences.

### What does not explain the benchmark

- **JIT:** it was disabled by default in the measured RC configuration.
- **Cross-call query caching:** every timed call creates a fresh Drizzle
  builder; it creates a fresh mapper and native prepared statement too. Its
  field/mapper cache belongs to that builder, which this benchmark does not reuse.
- **VibORM rebuilding default projection metadata:** the existing schema-owned
  projection cache already supplies those shapes and scalar leaves.
- **A universal SQL advantage:** the flat-read SQL has equivalent ordering and
  results; its select spelling differs. The filter still has the documented ID
  tie-breaker difference and an unindexed scan. This run does not isolate every
  SQL difference as an ORM effect.
- **Higher retained public-object cost:** complete retained result graphs remain
  nearly equal in the full comparison.

## Candidates within the shared engine scope

1. **Specialize the existing scalar reader further at compilation.** Bind
   type/list/identifier and provider-path decisions once, through the existing
   semantic codec owners, while keeping value checks and parser override behavior.
   This targets a measured large-row CPU cost. The exact gain remains unmeasured.
2. **Avoid unused selector dependency metadata on read-only consumers.** Keep
   one prepared-selector owner and preserve its write guarantees. This targets
   fixed allocation, rather than the large-row native cost.
3. **Resolve genuinely proven identity codec legs once.** Do so only where the
   authoritative adapter/driver contract can establish identity, not through
   dialect guesses or assumed function behavior. It may overlap candidate 1.

Positional transport is the largest measured allocation lesson, but implementing
it changes the driver/result contract and is outside this pass's shared-engine
scope. It would need a coherent provider-wide design, custom-parser compatibility
and its own evaluation; an SQLite-only fast path is not implied by these results.
Likewise, disabling safe integer transport would remove a demonstrated guarantee.

No production implementation or broad test suite was added for this diagnosis.

## Validation and evidence

- Same Node 24.21.0, V8 and better-sqlite3 12.6.0 as the completed RC benchmark.
- Same measured VibORM dist, fingerprint
  `3299ea848d57f061696acab2160e1932b21c4548ee4e347467be21670c3bf19f`.
- [profiles.json](profiles.json): 16 fresh workers, four workload shapes
  (`unique`, `filtered20`, `insert`, `rows1000`), separate CPU-profile and
  allocation modes. All independent complete-result checks passed.
- [profile-summary.json](profile-summary.json): CPU and allocation frames.
  Source maps resolve VibORM frames to TypeScript; Drizzle frames point to the
  copied package's readable JavaScript. Inclusive percentages overlap.
- [row-probe.mjs](row-probe.mjs): two workers, 20 and 1,000 rows; native
  object/array × safe/plain integer controls; frozen-input prepared parsing.
  Timing uses five rotating blocks, allocation one separate sampled interval
  per stage. The latter is a diagnostic estimate, not five allocation replicates.
- [row-stages.json](row-stages.json) retains all 60 timing and 12 allocation
  stage samples; [row-summary.json](row-summary.json) gives median/MAD.
- [contract-probe.mjs](contract-probe.mjs) and
  [contract-witnesses.json](contract-witnesses.json) pin the three result-contract
  differences and exact-versus-rounded native integer transport.
- All native format controls execute the same captured VibORM SQL and parameters.
  Complete logical fixture results match after normalization outside measurement.
  Drizzle's parsing control uses its own prepared mapper with the same selected
  column order; its prepared SQL/params are separately recorded.
- CPU/allocation profiles ran in 11.77s; row controls in 7.29s; contract controls
  in 0.31s. Runs were serial under the bounded launcher, with verified teardown.

Reproduce:

```sh
node scripts/run-node-safe.mjs 768 180000 \
  docs/architecture/performance-2026-09-29/drizzle-analysis/row-probe.mjs
node scripts/run-node-safe.mjs 768 60000 \
  docs/architecture/performance-2026-09-29/drizzle-analysis/contract-probe.mjs
```

These controls answer why the observed implementation paths cost differently.
They do not establish a production speedup, an additive timing budget, or
results for other databases. The retained profiles and immutable comparison
receipts remain the evidence for the diagnosed behavior.
