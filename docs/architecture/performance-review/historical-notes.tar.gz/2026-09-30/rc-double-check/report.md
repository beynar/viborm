# Copied Drizzle RC versus the current engine

The current implementation has adopted the largest row-layout lesson from the
RC: stock SQLite collection reads use positional transport, then construct fresh
public row objects and a fresh outer array. The remaining gap is work at the
scalar boundary and first-operation construction, plus different database work
for the filtered benchmark. The last Promise and parameter-map changes have no
established wall-time win. Their small allocation gains do not close these gaps.

## Verified comparison

The copied package is `drizzle-orm@1.0.0-rc.5-5935859` under
`/Users/arnaud/code/viborm/.reference/drizzle-orm-1.0.0-rc.5-5935859`.
Its 871 JavaScript files have the same filename/content hash as the peer used
by the comparator:
`037fcdd85158d28f84e0f9c2bc6e76d40ea3ee02503548d7d5152a420ae4651a`.
This verifies the copied benchmark peer, not the registry's latest version today.

The current source/build hashes still match the preceding campaign:
`3f3df4c18cc141b5db1001682663aa964f26a0a2cd9cf80e44a487f306cd3dd5` /
`38a85ef214fae2df49a72e09090d78c7660b0d454c85b6dcd1db6b268a650d84`.

The [comparator](../../../../benchmarks/better-drizzle-compare.mjs:411) uses
fresh flat select builders for rows20/rows1000. RC
`sqlite-core/async/select.js:12` constructs the mapper and native prepared query;
`better-sqlite3/session.js:29` calls `stmt.raw().all(...params)`;
`utils.js:143` supplies its default interpreted mapper. JIT is off in this
configuration. The mapper/statement belong to each newly constructed builder,
so its within-builder memoization does not explain these repeated-call numbers.

Drizzle still allocates per-query builders, selected-field records, a Set,
method closures, a mapper and native prepared query. It also allocates a public
object for each returned row. Our lazy SQL flattening already performs one
fragment-tree traversal. Neither broad closure elimination nor a replacement SQL
renderer follows from the comparison.

## What remains in the hot path

Drizzle's `utils.js:177` reads each cell by index, then copies it or calls its
preselected decoder. Its better-sqlite3 codecs have no decoder for this fixture's
plain string/int fields. Only the boolean column requires conversion among the
six post columns. It does not implement our strict missing-field, required-null,
scalar-domain or safe-integer refusal rules at this boundary.

Our [physical scalar wrapper](../../../../src/query-engine/raptor3/shared/query.ts:5314)
checks absence/null, calls the driver's parser and adapter continuation through
[fieldReader](../../../../src/query-engine/raptor3/shared/query.ts:797), then calls
the preselected strict scalar reader. The scalar type/list/identifier switch has
already moved out of the row loop. The generic provider chain still runs for each
non-null physical cell: all 6,000 cells of this fixture's 1,000-row result.
A closure appears inside that source chain per
cell; this is not proof of a heap allocation because V8 can inline or eliminate it.

The prior identity-hook bypass was tested and discarded for lack of a stable
wall-time gain. Reintroducing its function-identity registry would be the same
unqualified experiment. A simpler physical/carried wrapper choice could remove
the per-cell `provider === undefined` branch, but may compile to the same code.
Further scalar-pipeline compression needs an isolated parser diagnostic and a
full-operation win while preserving custom-hook ordering, lookup, receiver,
exception and continuation behavior. It is a direction, not a measured gain.

VibORM requests `safeIntegers(true)` before fetching. This preserves large
integer values so strict int decoding can refuse overflow rather than receive an
already-rounded number. Drizzle's ordinary native numbers and `value === 1`
boolean codec are cheaper, but adopting those rules would weaken our contract.

The [existing profiles](../wall-next/profile-summary.json) come from the preceding
source/build, which has the same current row decoder. On rows1000,
`decodeProjection` accounts for 28.41% inclusive of non-GC sampled main-thread
time, and `assertPositionalRows` 1.75% self. On filtered20, native `all` accounts
for 76.68% self and decoding 1.73% inclusive. These are overlapping sampled
frames, not an additive wall-time breakdown or a precise speedup ceiling.

## Bounded fresh-operation candidates

| Candidate | Concrete redundant work | Applies to measured workloads | Boundary to preserve |
| --- | --- | --- | --- |
| Defer folded text SQL until an insensitive operator consumes it | `lowerOperation` eagerly constructs `caseSensitiveText(asciiCaseFold(column))` for case-sensitive text comparisons, then discards it | Ordinary non-key text filters; not published:true or findUnique id | Every insensitive comparison and field reference; adapter expressions are construction functions |
| Avoid unused pagination term copies | `totalOrder` clones/freezes non-nullable terms to add null placement that `lowerOrder` ignores, then `completeOrder` copies the array again | Limited rowsN, filtered20, relation20 | ID tie-break, negative windows, cursor predicates, nullable keys and recursive sibling ordering |
| Avoid irrelevant unique-key lookup | `prepareWhere` scans addressable keys even for an admitted scalar in an ordinary non-unique filter | filtered20 and other ordinary filters | Unique selectors and compound-selector expansion; scalar/compound names cannot collide |
| Consume validated positional structure once | Driver scans all rows with `assertPositionalRows`; positional reader repeats `Array.isArray` | Collection reads, scales with rows | A lexical proof covering the exact rows until synchronous decode, including native surface changes; missing cells/domain checks remain |

Source owners:

- [folding](../../../../src/query-engine/raptor3/shared/query.ts:2323): every
  `folded` consumer is guarded by `insensitive`. SQLite creates discarded
  lower/collation fragments. MySQL's `asciiCaseFold` at
  `src/adapters/databases/mysql/mysql-adapter.ts:350` constructs 26 REPLACE
  layers and 52 literal fragments. That larger cost is a source observation,
  not a non-SQLite benchmark claim. Custom adapters can observe fewer calls;
  emitted SQL equality alone does not establish every custom-adapter behavior.
- [pagination](../../../../src/query-engine/raptor3/shared/query.ts:3112):
  `lowerOrder:2890` ignores null placement for non-nullable terms. Preserve the
  total-order semantics; do not remove our ID tie-break to match cheaper SQL.
- [key lookup](../../../../src/query-engine/raptor3/shared/query.ts:1762):
  `findAddressableKey` scans the catalog. The collision rule is owned by
  `src/schema/model/keys.ts:105`, rather than assumed by the optimizer.
- [row structure](../../../../src/drivers/positional-result.ts:50) and
  [positional reader](../../../../src/query-engine/raptor3/shared/query.ts:5238):
  do not replace revalidation with a flag whose guarantee expires during an
  asynchronous boundary or parser re-entry.

These are source-backed candidates, not demonstrated latency improvements.
The folding change is the clearest removable construction; the row-check change
has a small measured CPU footprint. None justifies a promise of a large win on
filtered20, whose scan/sort and extra deterministic tie-break still dominate.

## First-operation construction

Our admission is already lazy. `SchemaRegistry` builds a model's schema surface
when that model is first admitted, and resolves only the operation/core schemas
actually read. It does not eagerly construct every operation schema.

However, [getArgsSchemas](../../../../src/validation/model/args/index.ts:92)
still creates 14 builder functions, and
[getCoreSchemas](../../../../src/validation/model/core/index.ts:181) creates 21.
[lazyRecord](../../../../src/validation/lazy.ts:21) creates an additional getter
closure for every declared property, even ones that remain unresolved. The
existing `LazyScalarSchemas` uses shared accessors for an analogous fixed shape.
Compact schema-owned accessors could reduce fresh-client construction without
reusing a previous request's client/schema. First-operation allocation profiling
must establish whether that is material before a larger validation-owner change.

Drizzle's flat select retains operands and creates column parameters directly;
it has no equivalent operation-payload validation/detachment boundary. Removing
our validation is not a micro optimization. Avoid generating unused validation
machinery while retaining one authoritative admission boundary instead.

## Validation and limits

Read the copied RC, the current engine and provider code, the benchmark call
sites, existing profiles and the final micro-pass evidence. Verified copied peer
and source/build hashes. Two independent read-only source reviews were reconciled
against the code. No production edits or correctness-suite reruns were made. The
new diagnostic passes Node's syntax check, and `git diff --check` passes.

[fresh-peer.mjs](fresh-peer.mjs) prepares a narrow process-warmed, fresh-schema
and fresh-client comparison for rows20/rows1000 with paired alternating ORM
order, separate setup/connection/query timing, complete independent result checks
and separate SQL/parameter witnesses. This is a Node/SQLite diagnostic; it does
not measure actual Cloudflare isolates. Its bounded launcher refused to run
while other verification jobs held the shared workspace lock. After the first
Vitest owners exited, `coverage-all` (PID 70184) took that lock and remained
active. No benchmark was executed, no lock was removed and no competing process
was interrupted. There are no new timing numbers from this review.
