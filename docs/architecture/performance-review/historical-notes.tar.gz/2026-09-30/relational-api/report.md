# Drizzle relational API comparison — 2026-09-30

The API correction materially changes the comparison. With Drizzle's relational
API, VibORM is faster on four of five measured read workloads after client setup,
including filtered20. Drizzle remains faster on the 1,000-row result and on first
use with a fresh schema/client. Production source was not changed in this pass.
The results do not establish Cloudflare Worker performance.

## What changed in the comparison

Previous flat reads used Drizzle's select builder. Every read now uses its
relational `db.query.*.findMany` or `findFirst` API. The pinned package remains
**1.0.0-rc.5-5935859**, with `jit: false`. All limited reads have matching
ordering and complete logical output. Unique lookup uses `findFirst` with a
primary-key predicate; Drizzle has no separate `findUnique` operation. The nested
relation case was already relational. Inserts retain the write builder because
Drizzle's relational API does not provide an insert operation.

In particular, filtered20 now uses:

```ts
// VibORM
client.post.findMany({
  where: { published: true },
  select: { id: true, title: true, views: true },
  orderBy: { views: "desc" }, // engine completes this with id ASC
  take: 20,
});

// Drizzle relational API
client.query.posts.findMany({
  where: { published: true },
  columns: { id: true, title: true, views: true },
  orderBy: { views: "desc", id: "asc" },
  limit: 20,
});
```

The recorded SQL below differs only in casing and statement-local alias:

```sql
-- VibORM; parameters [1, 20]
SELECT "q0"."id" AS "id", "q0"."title" AS "title", "q0"."views" AS "views"
FROM "posts" AS "q0"
WHERE "q0"."published" = ?
ORDER BY "q0"."views" DESC, "q0"."id" ASC LIMIT ?;

-- Drizzle relational API; parameters [1, 20]
select "d0"."id" as "id", "d0"."title" as "title", "d0"."views" as "views"
from "posts" as "d0"
where "d0"."published" = ?
order by "d0"."views" desc, "d0"."id" asc limit ?;
```

This is a new measurement series. Switching API and matching ordering changes
the benchmark, not either ORM's implementation. Historical select-builder
results remain valid for that API and cannot establish the relational-API gap.
In particular, the earlier explanation that Drizzle receives prebuilt filter
expressions does not describe the RC's object-based relational API.

## Complete operations after client setup

Five fresh-process rounds per library/workload/measurement, alternating library
order. Every call constructs a new operation and statement; clients and schema
metadata are warm. Time and allocation are measured in separate workers. Timing
windows use `--time-scale 10` (100,000 unique lookups, 30,000 filtered/relation/20-row
reads, 50,000 inserts, or 4,000 large reads per worker), after proportional warmup.

Values are medians of five worker measurements. The paired change is the median
of VibORM/Drizzle minus one in matched rounds; it need not equal the ratio of the
separate medians. Negative means VibORM costs less. MAD is dispersion in percentage
points, not a confidence interval. No sample was discarded.

| Operation | VibORM wall µs | Drizzle wall µs | Paired wall Δ | MAD | Lower in rounds | VibORM CPU µs | Drizzle CPU µs |
|---|---:|---:|---:|---:|---:|---:|---:|
| Unique row | 9.81 | 24.91 | -60.79% | 0.39 pp | 5/5 | 10.70 | 25.50 |
| Filtered 20 | 90.87 | 96.90 | -6.33% | 1.02 pp | 4/5 | 95.45 | 98.87 |
| Relation 20 | 40.66 | 54.23 | -23.96% | 0.29 pp | 5/5 | 44.95 | 56.69 |
| Insert (write builder) | 14.86 | 14.05 | +2.93% | 2.55 pp | 0/5 | 16.91 | 14.93 |
| 20 scalar rows | 26.63 | 35.15 | -24.19% | 0.68 pp | 5/5 | 30.40 | 37.08 |
| 1,000 scalar rows | 376.52 | 307.43 | +19.05% | 0.81 pp | 0/5 | 382.71 | 311.82 |

Filtered20 is lower in four of five paired rounds; the roughly 6% difference
exceeds twice the observed MAD. The unique, nested and 20-row read advantage is
consistent across all five rounds. The small insert wall difference is less than
twice its MAD and is not presented as a strong timing finding. The large-read
advantage for Drizzle is consistent across all five rounds.

### Temporary JavaScript allocation

V8 sampling uses a 4,096-byte interval and includes collected objects. These
are estimates of allocation churn, excluding native allocation. They are not
retained heap or RSS. No new retained-memory claim is made.

| Operation | VibORM KiB/op | Drizzle KiB/op | Paired allocation Δ | MAD |
|---|---:|---:|---:|---:|
| Unique row | 22.30 | 27.05 | -17.48% | 0.12 pp |
| Filtered 20 | 32.38 | 33.68 | -3.63% | 0.23 pp |
| Relation 20 | 41.53 | 55.68 | -25.47% | 0.37 pp |
| Insert (write builder) | 28.27 | 10.57 | +166.49% | 2.48 pp |
| 20 scalar rows | 33.52 | 34.84 | -4.18% | 0.26 pp |
| 1,000 scalar rows | 375.32 | 334.48 | +12.69% | 0.09 pp |

Raw timing/CPU/allocation samples: [warm.json](warm.json).
Paired statistics: [warm-summary.json](warm-summary.json).

## First query with fresh declarations and client

This is the relevant separate boundary when client/schema reuse is excluded.
Each sample constructs fresh declarations, driver, client and an owned native
connection, then awaits the full first result. There is no query/client reuse
between samples. The fixture is preseeded outside timing. Five paired process
rounds, 200 measured fresh clients and 100 disposable warmups per worker.
Loaded code is warm in this mode; it is not a cold Worker isolate.

| Operation | VibORM setup µs | Drizzle setup µs | VibORM first query µs | Drizzle first query µs | VibORM setup + query µs | Drizzle setup + query µs | Paired total Δ |
|---|---:|---:|---:|---:|---:|---:|---:|
| 20 scalar rows | 59.23 | 12.95 | 103.37 | 64.37 | 162.60 | 76.68 | +121.20% |
| Filtered 20 | 68.46 | 13.89 | 215.69 | 131.92 | 276.89 | 144.96 | +91.01% |

Each phase is an independent median and the columns are not additive. Setup plus
query excludes native connection opening and timing bookkeeping. The adjacent
continuous timer includes both. Raw CPU and continuous values are included in
[first-use.json](first-use.json).

The corrected API comparison therefore does **not** remove VibORM's first-use
penalty: paired setup-plus-query costs are about 2.21× for rows20 and 1.91× for
filtered20. The warm-client wins above do not establish wins without reuse.

### Fresh Node process, no ORM warmup

Five pairs, one first query per new process. Import-inclusive values sum measured
module imports and continuous setup/connection/query; they exclude OS process
launch. Both packages use their existing split artifacts.

| Operation | VibORM setup + query ms | Drizzle setup + query ms | VibORM import + continuous ms | Drizzle import + continuous ms |
|---|---:|---:|---:|---:|
| 20 scalar rows | 5.02 | 2.11 | 26.37 | 23.62 |
| Filtered 20 | 6.08 | 2.28 | 27.74 | 24.08 |

These local Node timings do not establish Workers module-loading, isolate,
network or hosted D1 costs. They also do not isolate individual sources of the
remaining first-use difference.

## Verification and provenance

- Pinned Node 24.21.0, V8 13.6.233.17-node.53, Apple M4 Pro, macOS arm64,
  better-sqlite3 12.6.0. Both arms use the repository's exact native installation.
- The unchanged frozen VibORM build is `cold-construction-final/dist`, module
  hash `8000e0ff0d5d569b1252d00259d8eaf452badafca1013f791b9d99b04c5a7beb`.
  Source hash is `0aa39025ce457303a084cf4cafd7f973ce1754fdd9ac9f178cbb6f848262123c`.
- Initial six-workload correctness run passed. Full comparison completed all
  120 timing/allocation workers; first-use completed all 40 workers. Bounded
  launchers ran sequentially, with verified teardown. No production test suite
  or typecheck was needed for this benchmark-only correction.
- Full logical results were checked against independent fixture values before
  timing. First-use checks every measured result. Untimed SQL/parameter witnesses
  restore the exact native `prepare` descriptor and verify the stock path.
- Complete result digests match across libraries and rounds. SQL and parameters
  are stable within each library/workload across the full campaign. Filtered20,
  rows20 and rows1000 SQL match across libraries after normalizing SQL casing and
  the statement-local alias. The first-use filtered20 witnesses match the full
  operation campaign exactly. See [sql-witnesses.json](sql-witnesses.json).
- All matched fixtures have 100 users and 1,000 posts; filtered20 has no supporting
  filter/order index. Unique views avoid ties in the data, while both SQL queries
  explicitly use the same tie-breaker. Nested relation SQL strategies may differ;
  their public output and root ordering match.
- Harness and lockfile identities are sealed in the reports and checked again at
  completion. Old harness bytes and the correction patches are retained beside
  this report. Historical reports and raw results have not been overwritten.

## Reproduce

Run sequentially through the pinned Node executable and bounded launcher:

```sh
node scripts/run-node-safe.mjs --rss-limit-mb=1024 768 180000 \
  benchmarks/better-drizzle-compare.mjs \
  --libraries viborm,drizzle --drizzle-dir /absolute/pinned-rc-installation \
  --build-dir /absolute/current/dist \
  --workloads unique,filtered20,relation20,insert,rows20,rows1000 \
  --modes time,alloc --time-scale 10 --rounds 5 --output /absolute/new-warm.json

node scripts/run-node-safe.mjs --rss-limit-mb=1024 768 60000 \
  benchmarks/council-first-use.mjs \
  --base-build-dir /absolute/current/dist \
  --drizzle-dir /absolute/pinned-rc-installation \
  --variants small --workloads rows20,filtered20 \
  --modes fresh-process,fresh-client --rounds 5 --samples 200 --warmup 100 \
  --output /absolute/new-first-use.json
```

The first-use tool now accepts one VibORM arm plus Drizzle; a candidate build
remains optional for future implementation experiments. The main competitor
comparator defaults to relational reads for Drizzle, including its older supported
API shape. This run validates the pinned RC, not every older package version.
