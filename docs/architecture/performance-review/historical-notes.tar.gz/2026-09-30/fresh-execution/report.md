## Outcome

Tested all three candidates. Kept Promise forwarding and one-pass SQLite
parameter conversion. Removed the parser identity shortcut because its isolated
wall-time gains were near zero and inconsistent. It required an extra function
identity table, which the measurements did not justify.

The local implementation delta contains seven files. Dispatch forwards the existing
Promise and converts synchronous failures into rejected Promises. A write with
no outcome callbacks uses direct forwarding; configured callbacks retain their
awaited publication order. SQLite3, LibSQL and Bun SQLite convert scalar and
binary parameters in one map through the existing shared conversion owner.
D1 already has one pass. Required parameter snapshots remain intact.

These changes save work within one operation. They add no client, statement,
reader or query cache. SQL, indexes, ordering, validation, precision and public
result ownership remain unchanged. The inherited positional collection and
compiled scalar decoding optimizations remain in place.

The reliable measured gain is modest allocation reduction: about 1–3.4% on
small operations. Large-read allocation is essentially unchanged. This pass
**does not establish a broad wall-time improvement**, either on warmed clients
or on a fresh schema and client. Host load changed during the run. The unchanged
baseline and Drizzle slowed as well, so absolute medians cannot be compared to
the prior campaign as evidence of improvement or regression.

Wall time, microseconds per complete operation, five-round medians:

| Workload | Before | Kept changes | Drizzle RC | Paired change | Lower rounds |
| --- | ---: | ---: | ---: | ---: | ---: |
| unique | 14.86 | 14.64 | 19.29 | -7.20% | 4/5 |
| filtered20 | 117.99 | 111.09 | 99.51 | +0.56% | 2/5 |
| relation20 | 46.13 | 44.30 | 61.50 | -1.88% | 3/5 |
| insert | 16.31 | 16.81 | 14.96 | +2.26% | 2/5 |
| rows20 | 32.53 | 30.67 | 25.32 | -4.37% | 3/5 |
| rows1000 | 421.91 | 412.32 | 377.21 | -0.20% | 3/5 |

CPU, microseconds per complete operation, total user plus system CPU:

| Workload | Before | Kept changes | Drizzle RC | Paired change |
| --- | ---: | ---: | ---: | ---: |
| unique | 14.82 | 14.45 | 17.82 | -4.46% |
| filtered20 | 114.91 | 114.29 | 96.28 | +0.59% |
| relation20 | 50.97 | 49.02 | 63.05 | -1.67% |
| insert | 18.75 | 18.88 | 15.86 | -0.16% |
| rows20 | 34.59 | 34.75 | 26.24 | -1.44% |
| rows1000 | 416.48 | 409.25 | 364.83 | -0.19% |

Sampled temporary allocation, KiB per complete operation, three-round medians:

| Workload | Before | Kept changes | Drizzle RC | Paired change |
| --- | ---: | ---: | ---: | ---: |
| unique | 23.21 | 22.76 | 10.00 | -1.86% |
| filtered20 | 33.62 | 33.15 | 15.33 | -1.44% |
| relation20 | 43.75 | 43.16 | 55.26 | -1.52% |
| insert | 29.59 | 28.56 | 10.66 | -3.40% |
| rows20 | 35.93 | 35.36 | 18.74 | -1.97% |
| rows1000 | 378.44 | 378.73 | 318.53 | -0.48% |

Paired change compares each candidate to its same-round baseline. It can differ
from the change between independent medians. Ranges, MAD and every sample are
in [summary.json](summary.json). These descriptive rounds are not confidence
intervals. Wall-time signs vary across rounds on every workload; even the
unique-read result must be interpreted within this host's changing load.

## Validation

The new [first-operation benchmark](../../../../benchmarks/first-operation.mjs)
creates a new schema, client, stock driver and database for each measured query.
It separates schema/client setup, connection initialization and first-query
wall/CPU. Native fixture seeding, result verification and disconnect are outside
the timers. No public operation precedes the timed query.

The final paired run measures 1,000 fresh clients per workload and build across
five rounds, plus five fresh-process samples per workload and build. The
process-warmed fresh-client results below are medians of round means, in
microseconds; they include first-operation admission and preparation, without
sharing schema or client metadata across samples.

| Workload | Before first query | Kept first query | Paired change | Lower rounds |
| --- | ---: | ---: | ---: | ---: |
| unique | 266.04 | 276.29 | +5.36% | 1/5 |
| filtered20 | 469.14 | 495.31 | +5.58% | 1/5 |
| relation20 | 401.59 | 413.46 | +1.43% | 2/5 |
| insert | 207.89 | 191.61 | -10.48% | 4/5 |
| rows20 | 319.87 | 250.80 | +1.99% | 2/5 |
| rows1000 | 656.34 | 743.76 | +10.07% | 0/5 |

Fresh-process samples keep package import, schema/client setup, connection and
first query separate. First queries have millisecond costs in this mode.
Five cold samples per case are limited evidence. Both modes show mixed directions. The fresh operation cost
is much higher than steady query timing, so steady timing alone is insufficient
for the requested lifetime. The complete setup/connection/CPU data are in
[first-operation.json](first-operation.json).

Each timed result is checked in full against an independent fixture. A separate
untimed client records SQL and bound parameters; they match across builds and
rounds. That recorder uses keyed rows while active, restores the exact native
prepare descriptor and checks the restored stock result. Timed clients use the
stock path. Initial build hashes, harness hashes and the lockfile must match at
completion. The steady benchmark checks full results and unchanged VibORM SQL
text; it does not capture bound parameters.

Focused validation passed: 101 distinct tests in ten files, the whole-program
TypeScript check and the changed-file Biome check. The tests cover strict scalar
results, custom parser getters/replacements and receivers, transaction
envelopes, prepared operations, write notification order, raw snapshots and
binary/scalar conversion. The new custom-hook witness also refuses accidental
inspection of a callable parser's own `call` property. Real local SQLite3 and
LibSQL tests passed; Bun conversion uses a controlled provider fixture.

The retention soak ran 200,000 mixed operations after 20,000 warmup operations.
Post-GC heap stayed within 10.06–10.46 MiB. All 420 sampled completed handles and
results were collected, as were all 336 samples after bounded overlap. Holding
500 completed handles raised heap from about 10.25 to 20.48 MiB; releasing them
returned it to about 10.35 MiB. A separate 1,000-client probe after 50 warmup
clients collected all 5,000 sampled clients, drivers, database wrappers and
models. Its last 500-client window stayed within 10.765–10.827 MiB. See
[retention.json](retention.json) and [lifecycle.json](lifecycle.json).

The isolated controls are preserved in [pilot-ablation.json](pilot-ablation.json)
and the `first-parser`, `first-promises` and `first-parameters` reports. The
initial stock-parser ablation preceded a custom-hook invocation repair; the
repaired three-candidate artifact is preserved separately. Both were discarded
in favor of the two simpler changes. Reports prefixed `pilot`, `all-three` or
`kept-*` are diagnostics, not the final source comparison.

Final source SHA-256:
`3f3df4c18cc141b5db1001682663aa964f26a0a2cd9cf80e44a487f306cd3dd5`.
Final built JavaScript SHA-256:
`38a85ef214fae2df49a72e09090d78c7660b0d454c85b6dcd1db6b268a650d84`.
The baseline is the prior campaign's verified final source/build. The frozen
source/build variants, harness snapshots and manifests preserve provenance.
[implementation.patch](implementation.patch) contains only this pass's
production delta and excludes inherited work.

## Risks

The latest fresh-client 1,000-row run was slower in all five pairs, with a
median paired increase of 10.07%. Earlier runs of the same kept build showed
the opposite direction. These conflicting cohorts do not rule out a real
read regression. The two changes remain local candidates for review and are
**not qualified as a latency improvement**. No merge, release or publication
was performed. Allocation sampling estimates
JavaScript churn; it excludes native SQLite allocation and is not retained heap
or RSS. Retention probes cover the exercised paths and lifetimes, not every
possible application.

This is Node 24.21.0 / V8 13.6 on macOS arm64 with better-sqlite3 12.6.0.
It is a local SQLite proxy for first-operation engine cost, **not Cloudflare
Workers isolate or hosted-provider evidence**. Drizzle is the same pinned
`1.0.0-rc.5-5935859` configuration, with JIT disabled and fresh query builders;
it is not a newly verified latest release.

The pre-existing client proxy still retains about 7.69 MiB per 10,000 distinct
unknown property names. It remains outside the engine pass, as requested.
