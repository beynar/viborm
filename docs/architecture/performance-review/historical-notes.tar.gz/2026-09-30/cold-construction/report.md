# First-use construction experiment — 2026-09-30

The retained changes reduce fresh-client rows20 setup plus its first query by
about one quarter. **The requested 50% reduction was not achieved.** The gain is
smaller in a completely fresh Node process. This is SQLite/Node evidence, not
Cloudflare Workers cold-start evidence, and it does not establish a hard ceiling.

## Primary result

Each sample declares fresh models, scalars and relations, creates a new stock
driver/client and database, then awaits its first public operation. No schema,
client, connection, prepared query or result is shared between samples.
`fresh-client` reuses loaded code/JIT state only: 40 disposable warmup clients,
100 measured clients per worker, five independent process pairs with alternating
build order. Complete results, SQL and bound parameters agree.

The phase table uses arithmetic means across the five worker means, so the
phases add up. The paired reduction below uses the median of the five paired
percentage changes; it need not equal the ratio of aggregate means.

| rows20 phase | Baseline wall µs | Retained wall µs |
|---|---:|---:|
| Declare schema, construct driver/client | 99.59 | 75.10 |
| First public query, including preparation and result | 165.45 | 118.46 |
| **Setup plus first query** | **265.04** | **193.56** |

Paired rows20 reduction: **24.34% wall** (MAD 6.90 percentage points), **22.9%
process CPU**. These samples reproduce roughly 265 µs of total first use, not
300 µs of schema/client construction alone. Connection initialization, imports,
native fixture seeding and disconnect are separate from this table.

Other first operations, measured with the same protocol:

| Operation | Baseline setup + query µs | Retained setup + query µs | Paired wall change | Paired CPU change |
|---|---:|---:|---:|---:|
| rows20 | 266.7 | 194.0 | −24.3% | −22.9% |
| filtered20 | 378.8 | 308.9 | −18.7% | −22.4% |
| unique | 233.7 | 211.5 | −9.5% | −6.1% |
| relation20 | 338.3 | 304.9 | −9.9% | −13.4% |
| insert | 239.2 | 195.9 | −22.5% | −19.4% |

This operation table uses medians of worker means. CPU includes process and V8
background work in each timed interval; it is not a single-thread instruction
count. Raw results: [v2-first-operation.json](v2-first-operation.json), with
derived paired statistics in [final-summary.json](final-summary.json).

## Completely fresh process

Five fresh process pairs, one first operation each, no ORM warmup:

| rows20 boundary | Baseline ms | Retained ms | Paired wall change |
|---|---:|---:|---:|
| Schema/client plus first query | 5.280 | 4.605 | −11.4% |
| Also include package imports | 24.693 | 23.850 | −3.4% |
| Also include native connection initialization | 26.645 | 25.523 | −4.5% |

Imports matter: hoisting class definitions moves their evaluation to module
initialization, so construction-only timing cannot establish the entire cold
startup gain. The complete import-inclusive result remains far from half.
Node process startup and native fixture creation are excluded. Workers module
loading, isolates and D1 transport have not been measured here.

## Retained changes and ownership

- **Compose validation entries once.** Internal entry projections reuse the
  existing `fromObject`/`fromKeys` owners. `where` and `orderBy` stop constructing
  object validators solely to take their entries and discard them. Merge order,
  eager invalid-path refusal, recursive types and public builders are preserved.
- **Defer unused to-one ordering.** Existing `lazyRef` wraps only default-free
  relation ordering branches, including recursive hops. Validation or JSON
  schema inspection still resolves the branch. Generic object-thunk/default
  handling is unchanged.
- **Share operation class code.** Prepared and routed operation classes are
  defined once per module. Every handle retains its own engine/driver binding,
  admission, prepared read and codec state. This costs four extra references per
  prepared+routed handle; it adds no cross-client query cache.
- **Publish successful identifier derivation.** The topology gate's successful
  answer populates the existing WeakMap keyed by that exact resolved index.
  First-query schema construction no longer repeats the graph derivation.
  Direct diagnostic derivations still run and preserve contextual errors.
- **Skip domain propagation when there are no declarations.** A complete scan
  of registered scalar declarations proves there can be no inherited identifier
  domain or domain/storage conflict. Only then does the owner return the empty
  result, before reference-graph/Tarjan construction. A declared domain anywhere
  retains the original full derivation and refusal behavior.
- **Use ordinary writes into owned null-prototype maps.** The three model
  classification maps are private until returned and already have no prototype.
  Assignment preserves even `__proto__` and produces the same data descriptors.
  General-purpose `put()` and classification/read order remain unchanged.

Engine/adapter separation and eager schema-definition errors remain intact.
The unknown-property client proxy cache was explicitly excluded and is untouched.

## Causal experiments and rejected variant

The no-database diagnostic creates a fresh graph/driver/client for every sample
and prepares exactly its first operation. Ten balanced blocks, 80 samples per
arm/block, plus four separate allocation cohorts. This is process-warmed
attribution, not provider execution or cold-isolate evidence.

| Isolated change | rows20 first-preparation wall change | First-preparation JS allocation change |
|---|---:|---:|
| Class definitions only | −14.0% | −3.0% |
| Entry composition, lazy ordering, successful-domain publication | −19.9% | −29.9% |
| All retained changes | −30.4% | −35.8% |

All retained changes reduce setup allocation by about 17% and combined setup +
preparation allocation by **25.2%** for rows20. Text lookup combined allocation
falls 22.8%. These are sampled V8 allocations, including collected objects, not
RSS or retained memory; the causal cohorts are one process per experiment.
See [v2-causal.json](v2-causal.json), [classes-causal.json](classes-causal.json)
and [schemas-causal.json](schemas-causal.json).

**Rejected:** lazily materializing `lazyRecord` accessors through a Proxy. It
passed its focused descriptor, mutation, retry, freeze and isolation tests but
added five traps and a pending-factory Map. Compared with the retained variant,
rows20 preparation became 6.6% slower, text lookup preparation 10.7% slower,
and preparation allocation rose about 3%. Complete fresh-client rows20 first
use regressed 6.9%. Its source and tests were restored; only the isolated patch,
snapshot and measurements remain as experiment evidence. See
[proxy-first-operation.json](proxy-first-operation.json).

## Warm queries and retention

Two separate balanced comparisons included the pinned Drizzle
`1.0.0-rc.5-5935859` control. New public queries/builders were created each time;
both VibORM arms used the same native SQLite module and unchanged SQL/results.

| Operation | Retained vs baseline wall change, run 1 | Run 2 |
|---|---:|---:|
| filtered20 | +0.66% | −0.30% |
| rows20 | −0.82% | −0.05% |
| rows1000 | −0.03% | +0.31% |
| textId | −0.28% | +0.78% |

These movements are around measurement variation; this pass establishes a
first-use improvement, not a material warm-throughput improvement.
Evidence: [v2-warm.json](v2-warm.json),
[final-warm-confirm.json](final-warm-confirm.json).

The disposal test constructed and disposed 1,000 clients after a 50-client
warmup, with six operations per client. **All 5,000 sampled client, driver,
database and model references were collected.** Post-GC heap in the last 500
clients stayed between 10.678 and 10.745 MiB. This is bounded lifetime evidence,
not a proof about every workload or external extension. See
[final-lifecycle.json](final-lifecycle.json).

## Verification and reproducibility

- 263 distinct focused tests across 11 files passed for the retained behavior:
  ordering/defaults/JSON conversion, recursive ordering depth, ordinary filters,
  identifier inheritance/conflicts/cycles/native types, hostile keys, interleaved
  clients, prepared reads/batches and write-outcome composition.
- Whole-estate native TypeScript check passed. The rejected Proxy experiment
  separately passed 20 tests and a typecheck; those are not counted as retained
  regression coverage.
- Final formatting changed only whitespace in production code. A fresh final
  build has **byte-identical `.mjs` artifacts** to measured V2, proven in
  [final-identity.json](final-identity.json), so V2 timing/behavior evidence
  applies to the final build. Final lifecycle/warm confirmation use that build.
- Node v24.21.0, V8 13.6.233.17-node.53, Apple M4 Pro, macOS arm64; bounded
  sequential launchers, exact shared native dependency and source/build hashes.
  Two attempts were refused while another task owned the test lock; those are
  not measurement runs. No competing run was interrupted.
- [final.patch](final.patch) is the production diff against this turn's frozen
  baseline, excluding earlier performance work. No commit or release was made.

The target remains unmet. Keeping these measured, bounded improvements is
justified; claiming a twofold cold-start speedup, or extrapolating the warmed
Node result to Workers, is not.
