# Three shared-engine construction changes — 2026-09-30

All three requested changes are implemented in the local comparison worktree.
The [later rerun](rerun-report.md) repeats the same sealed inputs after shared
coverage finishes and reports the paired gap with Drizzle. It still establishes
no wall-time win; the text allocation reduction appears again, while the
20-row allocation reduction below does not reproduce.

This run does **not establish a wall-time improvement**. Sampled JavaScript
allocation was lower in all four rounds for the 20-row read and the ordinary
text lookup. CPU and wall results were inconsistent. The changes remain local;
they are not a qualified latency improvement or a release decision.

## Implementation

The production delta is confined to `src/query-engine/raptor3/shared/query.ts`;
[implementation.patch](implementation.patch) records it against the frozen
immediately preceding build.

- Pagination completes the requested order once, then fills necessary null
  placement in that owned array. Ordinary non-nullable terms are not cloned.
  Nullable terms retain their default placement, cursor terms retain their
  complete descriptors, and identity completion still belongs to `completeOrder`.
- Predicate preparation skips the addressable-key scan for known scalar fields
  in ordinary filters. Unique selectors and possible named compound selectors
  retain the existing lookup and expansion.
- Predicate lowering constructs the folded column only for insensitive text
  comparisons. Case-sensitive comparisons retain their existing adapter SQL.

No cache or cross-operation state was added. These removals apply within one
operation. SQLite is the only provider measured here; the implementation is in
the shared engine. There is no measured PostgreSQL or MySQL speedup claim.

## Wall time and CPU

Twenty adjacent, balanced baseline/candidate/Drizzle blocks per workload.
Every call constructs a fresh public operation or Drizzle query builder.
The table shows independent arm medians in microseconds per operation.

| Workload | Before wall | After wall | Drizzle wall | Before CPU | After CPU | Drizzle CPU |
|---|---:|---:|---:|---:|---:|---:|
| filtered20 | 101.98 | 104.31 | 95.13 | 108.82 | 111.13 | 110.68 |
| rows20 | 32.19 | 32.21 | 26.52 | 36.96 | 36.61 | 36.38 |
| rows1000 | 415.08 | 412.51 | 349.68 | 436.85 | 436.07 | 417.33 |
| textId | 20.87 | 22.00 | 15.90 | 25.41 | 25.50 | 22.63 |

Pair each candidate block with its adjacent baseline block before calculating
the percentage. Negative means lower cost. These paired medians can differ from
the percentage between independent arm medians above.

| Workload | Paired wall change | Wall MAD | Lower wall blocks | Paired CPU change | CPU MAD | Lower CPU blocks |
|---|---:|---:|---:|---:|---:|---:|
| filtered20 | +0.82% | 2.12 pp | 7/20 | +1.14% | 2.39 pp | 8/20 |
| rows20 | -0.03% | 3.12 pp | 10/20 | -0.35% | 2.09 pp | 10/20 |
| rows1000 | -0.08% | 2.24 pp | 11/20 | +0.36% | 1.97 pp | 9/20 |
| textId | +0.10% | 2.58 pp | 9/20 | -0.84% | 1.94 pp | 11/20 |

MAD is median absolute deviation, not a confidence interval or an equivalence
test. These observations establish neither a consistent latency gain nor a
causal regression. In particular, filtered20 did not become faster.

`filtered20` is the boolean filter with a descending views order and a 20-row
projection. It cannot exercise the discarded text folding. `textId` therefore
uses `findFirst({ where: { id: "u42" } })`, an ordinary case-sensitive text
filter; a unique discriminator uses different comparison semantics.

## Allocation and retained heap

Four separate allocation rounds, sampled at 4,096 bytes with collected objects
included. KiB per operation below measures estimated JavaScript churn; it
excludes native allocations and is not retained memory.

| Workload | Before KiB/op | After KiB/op | Drizzle KiB/op | Paired change | Lower rounds |
|---|---:|---:|---:|---:|---:|
| filtered20 | 31.465 | 31.493 | 14.712 | +0.65% | 1/4 |
| rows20 | 33.568 | 33.400 | 17.472 | -0.46% | 4/4 |
| rows1000 | 379.058 | 377.749 | 316.508 | +0.14% | 2/4 |
| textId | 24.701 | 24.222 | 10.152 | -1.90% | 4/4 |

The allocation reduction on the small reads is modest. Lower construction
allocation did not translate into a demonstrated wall-time gain. No individual
change was timed separately, so the combined result cannot apportion savings
among the three edits.

The separate [retention run](retention.json) used the exact candidate build:
20,000 warmup operations followed by 200,000 mixed operations. Post-GC heap
remained between **10.12 and 10.49 MiB**. All 420 sampled steady-workload
references and all 336 overlap references were collected at their checkpoints.
Holding 500 handles raised heap to 20.51 MiB; releasing them returned it to
10.41 MiB.

The 100-client lifecycle diagnostic grew from 10.51 to 11.30 MiB, with two
uncollected sampled references at two intermediate checkpoints and zero at the
final checkpoint. That limited diagnostic is not a lifetime leak-free guarantee.
The excluded pre-existing client proxy issue remains: 10,000 distinct unknown
property names retained approximately 7.69 MiB. It was not changed in this
engine-only pass.

## Fresh-client first operations

Five rounds of 20 fresh clients per build and workload: new schema graph,
driver, database, and client, with no preceding ORM operation on that client.
Fixture writes occur outside timing. Code remains warm in the same Node
process; this does not measure a fresh Cloudflare Workers isolate.

| Workload | Before first-query wall, µs | After first-query wall, µs | Paired wall change | Lower rounds | Paired CPU change |
|---|---:|---:|---:|---:|---:|
| rows20 | 361.94 | 343.99 | -3.12% | 3/5 | -6.89% |
| textId | 340.58 | 345.48 | +1.44% | 2/5 | +1.23% |

These are medians of round means. Wall MAD was 4.22 and 4.61 percentage points,
respectively. A first-operation wall gain is not established. Schema/client
construction and connection timing are recorded separately in the raw data;
their code is unchanged between builds, so their observed differences are not
attributed to the three query edits.

## Method and limits

[paired.mjs](paired.mjs) and [measurement.json](measurement.json) contain the
protocol, samples, ordered result witnesses, SQL, native parameters, and sealed
input identities. Baseline/candidate SQL, execution method, parameters, and
complete ordered results matched for all four workloads. Every comparator was
also checked against the independently derived expected rows. Native `prepare`
was restored exactly after untimed statement recording, with stock results
checked before and after restoration. Timed execution used the stock surface.

Both builds and pinned Drizzle **1.0.0-rc.5-5935859** use the same
`better-sqlite3@12.6.0` module. Drizzle uses its fresh core select builders with
JIT disabled, not retained prepared queries. Its SQL still differs from VibORM:
VibORM retains deterministic identity completion and exact text collation;
Drizzle uses `get` for the single text row. Equal fixture results do not imply
equal public contracts or identical database work across the two ORMs.

Node 24.21.0 / V8 13.6.233.17-node.53, macOS arm64, Apple M4 Pro (14 reported
CPUs). Host one-minute load increased from **9.01 to 19.10**. Workloads rotate
between blocks; baseline and candidate stay adjacent with balanced order.
Explicit GC runs before each timed triad, not between its arms. Natural GC is
included in timing; process CPU also includes background compilation and GC.
Same-process blocks are correlated and the host was changing. This is a bounded
diagnostic, not an independent-process performance qualification.

The three earlier diagnostic launches failed during untimed result verification
and produced no measurement JSON. The fixture spread several module exports,
allowing the SQLite convenience `createClient` to overwrite the main factory
and query a different database from the seeded one. Explicit imports repaired
the fixture; [run.log](run.log) is the successful final run. The failure logs
remain beside it and are not benchmark evidence.

## Validation and input identity

- 37 focused runtime tests passed in five files: read filters, pagination,
  order/cursor, nested reversal, and selector preparation.
- Added a regression for case-sensitive and insensitive text field-reference
  operands, including nested relation scope; the test manifest count is updated.
- Package build, whole-repository native TypeScript check, and scoped formatter
  checks passed. The benchmark launcher verified teardown.
- The final source and build match the frozen measured candidate. Input hashes
  were identical at the beginning and end of the timing run.

| Input | SHA-256 |
|---|---|
| Baseline source | `3f3df4c18cc141b5db1001682663aa964f26a0a2cd9cf80e44a487f306cd3dd5` |
| Candidate source | `115b5b5107ce1688cd68db9b2bfd8897f3021c94faf7d0258e3587654f679e82` |
| Baseline built modules | `38a85ef214fae2df49a72e09090d78c7660b0d454c85b6dcd1db6b268a650d84` |
| Candidate built modules | `df9ad6e486f10a37f41932ae780b02e14ce41cc38be9796831e7643af8738ee8` |
| Drizzle JS modules | `037fcdd85158d28f84e0f9c2bc6e76d40ea3ee02503548d7d5152a420ae4651a` |
| Paired harness | `442d0d3cf4f26d89dd40f1e397278deb1a433ad0c58db74b5d613543806d50ed` |

Tree hashes concatenate sorted relative filenames and contents. Source covers
435 `.ts` files; each build covers 79 `.mjs` files. No production source changed
after the candidate build and measurement.
