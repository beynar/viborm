# Three construction changes: rerun after coverage — 2026-09-30

The rerun completed against the same frozen baseline, candidate, harness,
lockfile, native SQLite module, and pinned Drizzle RC. Coverage and its follow-up
verification were allowed to release the workspace before the benchmark ran.
No production edits, builds, runtime tests, or retention reruns were added.

The result still does **not establish a wall-time improvement**. The paired
gap change with Drizzle is positive on three of the four workloads. Text-lookup
allocation is lower in three of four rounds; the previous 20-row allocation
reduction did not reproduce. Retain the original results beside this repeat
rather than selecting whichever cohort has the more favorable number.

## Change in the gap with Drizzle

For each block, calculate `gap = 100 × (VibORM / Drizzle − 1)`, then subtract
the baseline gap from the candidate gap. Negative means the gap narrowed.
A change is in percentage points (pp), not a percentage reduction in query time.

| Workload | Original wall-gap change | Rerun wall-gap change | Rerun wall MAD | Narrower blocks | Rerun CPU-gap change |
|---|---:|---:|---:|---:|---:|
| filtered20 | +0.86 pp | +0.95 pp | 1.26 pp | 7/20 | +0.74 pp |
| rows20 | -0.05 pp | +1.37 pp | 3.33 pp | 8/20 | +0.61 pp |
| rows1000 | -0.10 pp | -0.08 pp | 1.58 pp | 10/20 | +0.15 pp |
| textId | +0.12 pp | +1.15 pp | 2.59 pp | 7/20 | +0.04 pp |

The same Drizzle observation is the denominator of both gaps within a block.
It helps normalize common host speed changes, but it cannot remove differences
between the serial execution windows. The multiplicative change
`(candidate / Drizzle) / (baseline / Drizzle)` is exactly `candidate / baseline`.

MAD describes observed spread, not a confidence interval. In the rerun, wall-gap
changes still vary with arm order and workload position. For example, the 20-row
gap-change median was +3.07 pp for baseline → candidate → Drizzle and −5.06 pp
for candidate → baseline → Drizzle. The harness rotates workload position and
arm order on the same four-block cycle, so those two factors are coupled; these
strata are diagnostics, not proof of which factor causes the variation.
This repeat is not an independent-process qualification or a Workers-isolate test.

## Absolute timing in the rerun

Independent arm medians, microseconds per operation.

| Workload | Before wall | After wall | Drizzle wall | Before CPU | After CPU | Drizzle CPU |
|---|---:|---:|---:|---:|---:|---:|
| filtered20 | 93.53 | 94.01 | 86.43 | 100.92 | 100.67 | 102.31 |
| rows20 | 29.27 | 29.21 | 23.60 | 33.57 | 33.76 | 32.89 |
| rows1000 | 372.92 | 371.73 | 305.70 | 396.22 | 396.40 | 371.26 |
| textId | 18.74 | 18.99 | 14.60 | 22.93 | 23.04 | 20.77 |

Do not subtract medians of ratios to reconstruct a median paired change.
The table below reports the per-block slowdown ratios separately.

| Workload | Before wall slowdown vs Drizzle | After wall slowdown vs Drizzle |
|---|---:|---:|
| filtered20 | +7.96% | +8.09% |
| rows20 | +24.16% | +23.57% |
| rows1000 | +21.63% | +21.01% |
| textId | +28.19% | +28.56% |

## Sampled allocation

KiB per operation; four separate rounds. Sampled JavaScript allocation includes
collected objects and excludes native allocation. It is not retained heap.

| Workload | Before KiB/op | After KiB/op | Drizzle KiB/op | Paired candidate change | Lower rounds |
|---|---:|---:|---:|---:|---:|
| filtered20 | 31.483 | 31.416 | 14.675 | +0.27% | 1/4 |
| rows20 | 33.412 | 33.499 | 17.662 | +0.32% | 1/4 |
| rows1000 | 378.562 | 378.677 | 317.554 | -0.08% | 2/4 |
| textId | 24.524 | 24.366 | 10.173 | -1.04% | 3/4 |

The text-lookup paired allocation change was −1.90% in the first run and −1.04%
here, with lower allocation in 7/8 rounds across the two runs. Its allocation-gap
change versus Drizzle was −4.63 pp initially and −2.51 pp here. The 20-row
paired allocation change moved from −0.46% to +0.32%, so the initial gain must
not be presented as reproduced.

## Fresh-client first queries

Five rounds of 20 newly constructed clients per build and workload. Code is
already warm; no ORM operation has run on that measured client before its timer.
Seeding, schema/client construction, and connection timing are separate.

| Workload | Before first query, µs | After first query, µs | Paired wall change | Lower rounds | Paired CPU change |
|---|---:|---:|---:|---:|---:|
| rows20 | 246.06 | 250.74 | -1.77% | 3/5 | +0.84% |
| textId | 250.86 | 244.89 | -0.83% | 3/5 | -2.70% |

These are medians of round means. Both workloads had lower wall means in 3/5
rounds. No consistent first-query speedup is established, and these samples do
not measure a fresh Cloudflare isolate.

## Execution and evidence

- Run: 2026-09-30T12:01:34.513Z through 2026-09-30T12:02:12.581Z.
- Host load: 7.40 → 8.23 (one minute), compared with 9.01 → 19.10 initially.
- Successful bounded execution: 38.57 seconds, 296.6 MiB sampled peak process-group RSS; teardown verified.
- Same 20 timing blocks, four allocation rounds, and 100 fresh clients per build/workload; Drizzle JIT disabled.
- All four baseline/candidate SQL, native parameter, execution-method, and full ordered-result witnesses matched. Comparator results also matched independent expected rows.
- Native `prepare` was restored exactly before stock-result rechecks and timing.
- The benchmark sealed its inputs before and after measurement. The seal equals the original run’s seal.

[rerun.json](rerun.json) preserves all new samples; [rerun-execution.log](rerun-execution.log)
is the successful launcher log. [relative-gaps.json](relative-gaps.json) preserves
the normalized original and rerun calculations, including execution-order strata.
[report.md](report.md) preserves the implementation, validation, retention results,
protocol, hashes, and first measurement. Refused-launch and wait logs contain no
benchmark samples and are not used as performance evidence.
