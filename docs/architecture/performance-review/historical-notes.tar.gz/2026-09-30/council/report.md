# Council experiments: first-use CPU, wall time and allocation

**Comparator correction:** the Drizzle flat reads in this historical campaign
used its select builder. Use the subsequent [relational API comparison](../relational-api/report.md)
for an equivalent public API comparison. The VibORM candidate-versus-baseline
experiments below are unchanged; the broad inference about a Drizzle read gap
does not carry over to the relational API.

2026-09-30. All twelve candidate areas from the three-agent council were
investigated with isolated implementations. Eighteen source revisions were built,
including corrected prototypes and a combined candidate. No additional production
source change was retained. The earlier retained optimizations remain intact.

The experiments do not establish a hard performance ceiling. They establish that
these particular implementations do not justify another general first-use
speedup claim. None demonstrated the requested 50% reduction. The strongest
repeatable result concerns importing a bundled application in Node, which is a
different boundary from schema/client construction in a Worker.

## Decision and candidate coverage

Percentages below are candidate minus baseline: negative costs less. Full-use
numbers are paired medians of per-process mean setup plus complete first-query
time, excluding connection. A MAD is a descriptive measure of dispersion in
percentage points, not a confidence interval or significance test. We kept all
rounds, including outliers; small medians with comparable dispersion are not
established wins.

| Candidate | What was actually changed | Evidence and decision |
|---|---|---|
| Relation family wrappers | Construct actual relation schemas on demand through the existing lazy record instead of wrapping every family in a lazy Proxy | With eight unused relations, filtered20 became **7.28% slower**, MAD 1.28. Reject. |
| Deferred scalar/logical filters | First tried lazy references; corrected revision preserves actual public entry schemas using deferred getters and object-validation lookup | Original text lookup preparation fell 9.38%, but public entry introspection changed. Corrected version still reduced text preparation, without a consistent full-query gain across four fixtures. Reject for the wall-time goal. |
| Deferred scalar/polymorphic families | Delay whole unused schema families; retain ordinary relation construction at its existing validation boundary | Corrected public key order. Wide rows20 fell 7.61%, MAD 1.86, but relation-heavy rows20 rose 2.46%, MAD 0.39. Mixed. |
| Args/core catalogue | Replace eagerly created slot closures with on-demand schema factories, one contextual core object and shared prototype getters; public facades materialize when observed | Full version avoids **21 core and 14 args slots**. Small rows20 fell 4.54%, but wide rows20 rose 3.85%. Public frozen-object behavior also differs. Reject. |
| Model metadata | Allocate names, name registry and internal maps only when metadata is requested, preserving stable per-model ownership | Preparation timing essentially flat; combined sampled allocation fell 1.65–2.87%. No consistent full-use win. |
| Validation context reuse | Reuse the current resolution context rather than construct it again | Flat preparation timing. Bypasses public `resolve()` overrides, so this implementation is inadmissible. Reject. |
| Compound key fast path | Skip collision structures when neither compound declaration exists | Preparation changes about −1.53% to +1.26%; full-operation results mixed. No independent adoption. |
| Required-edge cycle scan | Allocate adjacency only for actual required-edge sources and return early for an empty graph | One relation-heavy filtered cell improved 5.11%, MAD 0.74; other phases/cases did not establish a broad win. Included in combined confirmation. |
| Shared adapter functions | Share stateless implementations for 18 SQL factory groups while keeping group objects fresh | Combined sampled allocation fell 3.01–5.24%; small rows20 became 8.19% slower and filtered20 5.45% slower. Reject. |
| Lazy batch references | Construct constant batch SQL/method groups on first access in all three adapters, preserving construction-time capability capture | Allocation fell 1.59–3.25%; wall results mixed. Included in combined confirmation. |
| Object validator allocation | Avoid copying keys with no omit; allocate missing/default tracking and validator scratch state only when needed | Wide rows20 −0.58%, filtered20 −1.22%, both smaller than dispersion. Included in combined confirmation. |
| Application bundle | Bundle the existing public schema/client/SQLite entries into one shared module with external dependencies | Fresh Node import-inclusive wall time fell **25–27%**; ordinary full-query results mixed. Preserve as packaging evidence, not an engine or Workers gain. |

The source diffs and exact identities for all revisions are preserved in
[experiment-identities.json](experiment-identities.json) and adjacent `.patch`
files. Rejected prototypes were never installed into the active source tree.

## Combined small changes: longer confirmation

The combined prototype contains model metadata, compound-key and cycle fast paths,
lazy batch references, and the object-validator changes. It excludes the known
override incompatibility, slower shared adapter factories, relation wrapper
change, and schema catalogue/filter experiments.

Five paired process rounds, **1,000 measured fresh clients per worker**, 100
disposable warmup clients, three fixtures and two operations: 60 workers and
60,000 measured clients. No schema/client/connection/query is reused between
samples. See [micros-confirm.json](micros-confirm.json).

| Fixture / operation | Setup + query wall Δ | MAD | Continuous wall Δ | CPU Δ | CPU MAD |
|---|---:|---:|---:|---:|---:|
| Small / rows20 | −8.53% | 14.10 pp | −9.47% | −0.75% | 5.59 pp |
| Small / filtered20 | −4.83% | 5.37 pp | −5.80% | −8.78% | 4.35 pp |
| Wide / rows20 | −0.33% | 8.58 pp | −0.88% | +5.03% | 4.02 pp |
| Wide / filtered20 | +6.99% | 4.71 pp | +7.33% | +0.92% | 1.84 pp |
| Eight unused relations / rows20 | −3.86% | 3.38 pp | −3.96% | +2.12% | 3.96 pp |
| Eight unused relations / filtered20 | −0.97% | 4.55 pp | −1.22% | −4.30% | 1.28 pp |

CPU here covers setup plus query and includes background process CPU during the
measurement interval. It is not interchangeable with elapsed wall time. The
longer confirmation did not reproduce a consistent benefit across operations.

Separate V8 allocation sampling did establish less temporary JavaScript
allocation for fresh setup plus private first preparation:

| Workload | Baseline sampled bytes | Candidate sampled bytes | Paired change | MAD |
|---|---:|---:|---:|---:|
| rows20 | 165,016 | 154,546 | −6.19% | 0.71 pp |
| textId | 172,497 | 164,624 | −4.01% | 0.82 pp |

These are medians of four independent allocation cohorts, 80 fresh clients each,
with 4,096-byte sampling. Schema/client allocation itself fell about 8–10%; the
first preparation remained approximately flat. Sampled bytes are estimated
churn, not live retained heap, native allocation, RSS or full-query allocation.
See [micros-causal.json](micros-causal.json). The memory result is real evidence
for a narrower allocation goal, but does not establish the requested wall gain.

## Full schema catalogue

The final catalogue revision was measured in five paired process rounds, 200
fresh clients and 100 warmups per worker. Four fixtures, two operations and
three arms including Drizzle produced 120 workers and 24,000 measured clients.

| Fixture | rows20 wall Δ | MAD | filtered20 wall Δ | MAD |
|---|---:|---:|---:|---:|
| Small | −4.54% | 1.79 pp | −5.27% | 6.82 pp |
| Wide | +3.85% | 1.60 pp | −4.78% | 13.15 pp |
| Eight unused relations | −10.37% | 11.62 pp | −5.41% | 5.74 pp |
| UUID domains, physical TEXT | +2.50% | 5.08 pp | +3.30% | 11.50 pp |

The corrected variant reduced combined sampled allocation by 7.76% for rows20
and 6.04% for textId. Its private preparation wall time changed −0.42% and
−8.52%, respectively. That does not translate into a general full-operation win.
See [catalogue-full-v2-causal.json](catalogue-full-v2-causal.json) and
[catalogue-full-v2-continuous.json](catalogue-full-v2-continuous.json).

A separate executable differential proves an observable incompatibility. After
freezing a public model-schema object, `Reflect.set(schemas, "args", schemas.args)`
returns `false` in the baseline but throws `TypeError` in the candidate. The
candidate's setter tries to emulate a frozen data property and changes reflection
semantics. Its accessor descriptors also differ from the original data
descriptors. This is not inferred from types:
[frozen-schema-differential.log](frozen-schema-differential.log) records both
answers. We rejected this prototype rather than relax the existing behavior.

## Bundling: a different boundary

The application bundle contains the same public implementation, one shared
544,651-byte module and three entry shims. Bare package dependencies remain
external; no package configuration or production source changed. Five balanced
process rounds measured both no-warmup process starts and fresh clients in warmed
processes, alongside the pinned Drizzle RC.

| Fresh-process operation | Baseline import + continuous | Bundled import + continuous | Paired wall Δ | MAD | Paired CPU Δ |
|---|---:|---:|---:|---:|---:|
| rows20 | 27.24 ms | 20.50 ms | −25.59% | 2.86 pp | −36.32% |
| filtered20 | 28.47 ms | 21.26 ms | −26.57% | 1.71 pp | −35.87% |

For rows20, median import alone fell from 19.86 to 13.04 ms. Excluding imports,
the paired continuous change was +0.78%, MAD 5.09. This is principally an import
cost reduction. With warmed code and fresh clients, setup plus query changed
−5.76% for rows20 and +4.61% for filtered20. There is no general runtime win.

Absolute columns are independent medians, whereas changes are medians of matched
round ratios; they need not produce the same percentage. Neither total includes
OS process launch. Import time and continuous time are measured separately and
summed; expected fixture construction lies outside both.

This is Node module-loading evidence, not a Cloudflare isolate measurement.
It does not establish incremental value for a Worker deployment that already
bundles its application. Drizzle was not bundled in this experiment, so comparing
bundled VibORM against split Drizzle would not establish a fair packaging win.
See [bundle-v2-continuous.json](bundle-v2-continuous.json) and
[bundle-v2-receipt.json](bundle-v2-receipt.json).

## Current first-use comparison with Drizzle

The final bundling campaign also supplies a matched, unchanged split-package
VibORM baseline against split-package **Drizzle 1.0.0-rc.5-5935859**, explicitly
`jit: false`, using the exact same native SQLite installation. These are warm-code
**fresh-declaration/client** timings, not reused-client throughput.

| Operation | VibORM schema/client | Drizzle schema/client | VibORM first query | Drizzle first query | VibORM setup + query | Drizzle setup + query | Paired total ratio |
|---|---:|---:|---:|---:|---:|---:|---:|
| rows20 | 61.75 µs | 14.89 µs | 109.52 µs | 50.38 µs | 171.90 µs | 64.97 µs | 2.65× |
| filtered20 | 54.43 µs | 13.80 µs | 218.09 µs | 119.21 µs | 272.84 µs | 133.94 µs | 2.06× |

Each absolute column is the median of five worker means and is not additive
with the other medians. Ratios use the matched rounds. The schema work differs:
VibORM retains eager declaration validation, graph resolution and domain rules;
Drizzle uses its public query builder. Both produce the complete same logical
results, but their SQL need not be identical. This table does not revise the
existing six-operation steady-state comparison.

The earlier retained first-use result, 265.04 → 193.56 µs in the prior seeded
protocol, remains historical evidence from that protocol. Do not splice those
absolute numbers into this new preseeded-file series or declare the historical
132.52 µs half-target achieved because a different cohort has a lower number.

## Measurement, correctness and limits

- Node 24.21.0, V8 13.6.233.17-node.53, Apple M4 Pro, macOS arm64,
  better-sqlite3 12.6.0. Exact source, artifact, harness, lockfile and native
  package identities are recorded in the raw reports. Node jobs ran sequentially
  through the bounded workspace launcher; competing verification was allowed to
  finish. All final campaign process groups reported verified teardown.
- The new continuous harness creates disposable SQLite files before timing. Each
  sample creates fresh scalar/model/relation declarations, driver/client and
  owned native connection, then awaits the full first result. It has no fixture
  seeding interval between phases. Code and OS/file caches can still be warm.
- Small means two models, 100 users and 1,000 posts. Wide adds 32 required text
  fields. Relations adds eight unused to-one targets with their inverse slots.
  Domains uses UUID declarations and inherited foreign-key validation with
  explicit SQLite TEXT storage. Drizzle has the same physical values, without
  equivalent runtime domain validation.
- `continuous` includes setup, connection, query and timing bookkeeping.
  `setupAndQuery` sums the setup and complete query clocks, excluding native open
  and bookkeeping. Drizzle requires an open native handle before its client
  factory, so that factory is separately timed and charged to setup.
- Every measured result is checked in full against independently computed fixture
  values. A separate untimed client captures SQL and parameters, restores the exact
  original native `prepare` descriptor and verifies the restored stock query.
  VibORM SQL/parameters match between candidate and baseline; fixture files remain
  unchanged. The corrected protocol smoke passed all 24 arm/fixture/operation
  combinations.
- [validation-differential.mjs](validation-differential.mjs) exercised 12 operation
  cases plus defaults, recursive inputs, actual entry `type/options/extend`, JSON
  schema, key order/identity and accessor reads. It passed for relation, object,
  corrected filters/families, catalogue v2/v3 and both full catalogue revisions.
  The separate frozen-schema witness found a behavior this differential did not
  cover. Agent-added snapshot test cases were not run and are not counted as
  validation. Rejected prototypes received no complete type or provider suite.
- Allocation diagnostics separately sampled setup and private first preparation;
  they exclude provider execution and decoding. Full-query CPU/wall results are
  separate from these diagnostic profiles. Worker peak RSS includes witness and
  artifact hashing, so it is not presented as retained ORM memory. No new retention
  soak was needed for the unchanged production implementation; these prototypes
  make no retention guarantee.
- The host was noisy. Balanced order and within-round ratios reduce drift but do
  not remove scheduling or GC variation. The longer combined run was used to
  challenge the short-run result, not to discard inconvenient samples. Fourteen
  completed continuous campaigns and 62 candidate/fixture/operation/mode cells
  are indexed in [continuous-summary.json](continuous-summary.json).

## Failures preserved, not counted as successful evidence

The first protocol smoke lacked inverse slots for the unused relations; the
fixture was repaired. UUIDs explicitly use TEXT in the corrected fixture.
Initial family/catalogue prototypes changed public key order; corrected versions
were rebuilt and rechecked. The original lazy filter changed introspection and
was replaced by a compatibility-preserving experiment.

The first bundle helper put a dependency symlink inside the measured artifact,
causing recursive hashing to traverse thousands of dependency modules. Our own
campaign was stopped with verified teardown. The original helper and incomplete
`bundle-continuous.json` remain as failed-attempt evidence and are excluded from
all summary figures. The corrected helper puts dependencies beside `dist` and
asserts that exactly four JavaScript modules are measured. Final campaign 4
completed successfully. Logs of temporary workspace-lock refusals remain too.

## Integrated result

Production `src` remains byte-identical to the frozen retained baseline:
`0aa39025ce457303a084cf4cafd7f973ce1754fdd9ac9f178cbb6f848262123c`
(435 TypeScript files, sorted relative names plus contents). Before the README
update, the entire tracked diff matched the saved pre-existing diff exactly.
This pass adds two reproducible benchmark tools, this report and experiment
evidence. It does not change dependencies, release configuration or public API.

The next evidence needed for a claim about deployed Workers is a bundled Worker
measurement that separates module evaluation, fresh schema/client construction,
and its first request. These Node experiments neither prove that target's
latency nor justify replacing its contracts for a small speculative gain.
