# First rows20 query goal

Goal: save at least 30 microseconds from fresh schema and client construction
plus the awaited first rows20 query. The established metric excludes native
connection opening; also record the continuous interval including connection.
Fresh schemas, clients and connections are required for every sample.

Production source has not been changed by this goal campaign. Candidate source
snapshots live beside this worktree under `../performance/`.

## Completion after scope clarification (2026-10-01)

Arnaud clarified that the goal counts the retained fresh schema/client
construction plus first-query improvement already delivered, rather than
requiring another 30 microseconds after that improvement. The earlier
"additional gain" interpretation was too restrictive. Under this clarified
scope, the existing measured and retained implementation satisfies the goal.

Completion was revalidated against authoritative state: active source exactly
matches cold-construction-final (source 0aa39025ce457303a084cf4cafd7f973ce1754fdd9ac9f178cbb6f848262123c);
both saved baseline and retained source/build trees match final-identity.json.
The retained build is byte-identical to the measured V2 artifact. Existing
focused behavior, full native typecheck, build and client-disposal evidence
apply to those exact bytes; no new production edit followed them.

Recomputed from every raw sample in cold-construction/v2-first-operation.json,
all five fresh-client rows20 pairs saved more than 30 microseconds in schema
construction plus awaited first query: 64.924, 40.799, 112.993, 55.101 and
83.560 microseconds. Median paired saving is 64.924 microseconds. Each worker
used 40 disposable warmups and 100 fresh measured schemas/clients/connections;
all SQL/parameter/result witnesses match. The median arm means are 266.699
and 193.955 microseconds; their 72.744-microsecond difference is a separate
statistic from the median paired saving. Paired wall reduction is 24.343%.

This is warmed-code/fresh-client SQLite Node evidence. Connection opening is
excluded; no first-Worker-isolate or 50% reduction claim is made. Later
experiments remain isolated and unadopted. The extra model-construction review
was interrupted before any edit or runtime job; no benchmark was left running.

The sections below preserve the historical experiment record, including the
then-active additional-gain search; they do not override this completion.

## Historical current state

The previous coverage/resource-lock owners finished. All experiments subsequently
ran serially through the bounded launcher; none bypassed the verification lock.
No candidate has been adopted into production source.

Rechecked active source against the frozen baseline: both sorted `.ts` tree
hashes are `0aa39025ce457303a084cf4cafd7f973ce1754fdd9ac9f178cbb6f848262123c`.
The active worktree's older `dist` has a different hash; these experiments do
not use it. They explicitly use the frozen rebuilt baseline whose `.mjs` tree
hash is `8000e0ff0d5d569b1252d00259d8eaf452badafca1013f791b9d99b04c5a7beb`.
Do not infer active `dist` equality from source equality.

`paired.mjs` revision 3 uses one build per independent worker, alternating arm
order and fresh schemas, clients, connections and queries for every sample.
It checks complete fixture results, SQL and parameters, exact runtime/build
identities, and restores the native witness interceptor before a stock query.
The earlier same-process controls and harness revisions remain as counterevidence.

Short runs used 4096 preliminary clients and 1536 measured clients per worker.
They suggested 14–18 microsecond gains; a stacked run even suggested 33, but
with very large variability. These are NOT settled improvement claims.
Longer runs used 8192 preliminary clients and 16384 measured clients per worker,
six alternating pairs. All numbers below are paired median candidate-minus-base
wall time, in microseconds, for the established setup-plus-query boundary.

| Experiment | Median delta | MAD | Pair range | Receipt |
| --- | ---: | ---: | ---: | --- |
| Identical rebuilt source | +2.19 | 2.25 | -2.32 to +6.41 | `aa-long.json` |
| Demand-built operation schemas | -4.26 | 1.12 | -6.14 to -1.46 | `demand-long.json` |
| Model construction alone | -5.14 | 0.95 | -7.90 to -3.36 | `construction-long.json` |
| Model construction + demand schemas | -6.67 | 0.77 | -9.15 to -3.91 | `combined-long.json` |
| Demand schemas + deferred argument wrappers | -4.57 | 0.80 | -7.11 to -3.09 | `demand-entries-long.json` |
| Demand schemas + static bound argument recipes | -4.35 | 0.23 | -6.28 to -4.10 | `bound-entries-long.json` |
| Direct default projection | +0.30 | 1.21 | -2.93 to +1.96 | `default-projection-long.json` |
| Demand-built schemas + lean lazy wrappers | -6.66 | 0.61 | -7.74 to -4.65 | `demand-lean-long.json` |
| Above + construction and assorted micro changes | -5.18 | 0.54 | -6.06 to -3.79 | `stacked-long.json` |

These remain warmed-runtime/fresh-client observations, not cold-isolate timing.
Some within-worker drift remains. The lean-wrapper experiment also changes
prototype/own-property reflection; its extra savings do not establish that this
compatibility tradeoff is worthwhile. Scalar descriptor sharing, adapter function
sharing and descriptor-preserving lazy-wrapper sharing showed no useful
incremental wall-time gain in the short experiments.

Twenty truly fresh-process pairs of demand-built schemas found no convincing
improvement: paired setup-plus-query median +0.95%, MAD 3.47 percentage points,
range -13.94% to +9.07% (`cold-demand.json`). This separate series must not be
substituted for the established metric to claim the 30-microsecond goal.

## Compatibility evidence

The candidate-specific facade/construction witnesses and the public validation
differential completed. `native-differential.mjs` additionally exercises direct
native operation admission BEFORE public introspection: 25 cases, all 14
operation families, 22 successes and three refused inputs. It compares recursive
relations, nested writes, defaults, refusals and subsequent public schema identity.
These bounded witnesses are not a full type, behavior or retention adoption gate.

## Current direction

Avoiding unused validation catalogue construction is the best small target so
far. The long-run savings do not support a 30-microsecond claim, and stacking
more allocation changes did not improve them.

`council-goal-cold-read` is a separate isolated experiment: it moves existing
count/existence, aggregate and groupBy bodies verbatim into private methods of
the same `Queries` owner, shortening the common read method. It tests first-call
compilation cost without changing the ordinary find path or SQL semantics.
It built successfully. Twenty fresh-process pairs found no convincing gain:
paired setup-plus-query median +0.64%, MAD 4.30 percentage points
(`cold-read.json`). Complete rows20 results and the untimed SQL witness matched;
the extracted aggregate branches have not received focused runtime checks,
because this candidate has no demonstrated benefit warranting adoption.
No production change is justified merely by shorter source.

The demand-entry hypothesis has now been tested:
`getFindManyArgs` still creates deferred wrappers for all optional clauses even
when the query only supplies `orderBy` and `take`. Current laziness already
avoids resolving absent clauses, so any experiment must remove wrapper/setup
work rather than claiming that unused core schemas are all eagerly resolved.
`council-goal-demand-entries` keeps one object-validator owner, defers known
no-default argument entries, and materializes ordinary entry values through a
Proxy when introspection observes them. Its differential witness verifies
seven wrappers at baseline versus one during rows20 admission, plus defaults,
refusals, mutation before/after compilation, getter side effects, freezing and
JSON conversion. The 25-case native operation differential also passes.

Despite this allocation reduction, the long-run saving is only 4.57 microseconds,
essentially the same as demand schemas alone. Twenty cold pairs show no clear
gain either (+0.79% paired median, MAD 4.47 percentage points,
`cold-demand-entries.json`). The added coordination does not currently justify
adoption. A smaller context-bound static-recipe version was subsequently tested
as described below.

`council-goal-leaf-cold` moved only field-specific scalar reader cases behind
one helper (seven added lines, no changed case bodies). Twenty cold pairs found
no clear gain (+1.13% paired median, MAD 4.18 percentage points,
`cold-leaf.json`). It remains an isolated rejected timing experiment, without
an adoption claim about the extracted branches.

`council-goal-object-cold` has built and passed its 18-case differential oracle,
covering defaults, constraints, getter/Proxy order, dense output, recursion,
failures, wrappers, descriptors and JSON. Its common validator body shrank
226 to 112 lines without adding per-schema closures. Twenty cold pairs found
no clear gain (-0.33% paired median, MAD 4.31 percentage points,
`cold-object.json`), so no adoption or full test campaign follows this result.

`council-goal-default-projection` built and passed its 16-case public SQLite
SQL/parameter/result differential (default, explicit, nested, counts, omit,
empty/sentinel, point and distance refusals). It removes the default selection
record while retaining the existing projection owner. Long runs are neutral
(+0.31 microseconds, MAD 1.21). The first 20 cold pairs suggested -2.01%, but
30 confirmation pairs returned -0.17%, MAD 3.12 percentage points. An adjacent
30-pair identical-build control returned +1.83%, MAD 5.87 percentage points.
The apparent cold gain did not survive confirmation. Receipts:
`cold-default-projection.json`, `cold-default-projection-confirmation.json`,
`cold-aa-confirmation.json`. No adoption.

`council-goal-bound-entries` replaces the demand-entry prototype's nine
per-schema factory closures and nine Proxy/exposure closures with immutable
module-level recipes and shared handlers. Each schema retains its own bound
context and materialization state; a private target-keyed WeakMap does not
share validation results across clients. The enhanced entry differential passes,
including interleaved distinct model/client contexts. The native 25-case
operation differential passes, as does the complete native TypeScript check
against the copied current test estate (6.62 seconds, 6156.3 MiB sampled peak,
within the existing 8192 MiB whole-estate typecheck allowance).

The snapshot initially lacked the internal benchmark build entry and later two
benchmark modules imported by tests. Those unchanged inputs were copied in;
the failed and successful logs are preserved separately. An initial generic
1024 MiB typecheck was terminated by its RSS guard, with verified teardown.
The subsequent complete check used the existing whole-estate launcher and its
established allowance, not a raised generic limit.

The six long alternating timing pairs return -4.35 microseconds (MAD 0.23,
range -6.28 to -4.10); baseline and candidate medians are 89.71 and 84.98
microseconds respectively. These separate-arm medians are not the paired delta.
This is essentially the same observed saving as the simpler demand-schema
candidate, not evidence for useful incremental benefit from the additional
entry machinery. No cold run or adoption follows this result. Build, type,
differential and timing receipts use the `bound-entries` filename prefix.

## Target after this bounded pass

Prioritize first-operation validation materialization and model/client
construction: those are the only tested directions with repeatable modest
savings. The simplest combined candidate saved about 6.7 microseconds under
this long warmed-runtime/fresh-client protocol; allocation-only variants have
not extended that gain. More substantial savings require identifying whole
pieces of first-operation work to remove while preserving their contracts.
No measured candidate currently establishes a 30-microsecond route. Before
claiming relevance to Workers cold starts, measure the actual target runtime;
the separate local cold-process trials have not established a candidate win.

## Whole-subsystem cost diagnostics

Three isolated snapshots were built after the bound-entry result. They are
explicit diagnostics, not adoption candidates:

- `council-goal-ablate-admission` omits findMany argument validation. This
  intentionally breaks required input behavior; only the known rows20 fixture
  is meaningful. Six serial long pairs were inconclusive (-0.89 microseconds,
  MAD 15.65, range -17.82 to +28.61). An encoder and several unrelated Node
  processes were simultaneously consuming many CPU cores. Do not interpret
  this run as validation having zero cost. Receipt: `ablate-admission-long.json`.
- `council-goal-ablate-sql-preparation` substitutes the fixture's exact emitted
  SQL for select/page/lowerProjection/adapter assembly while retaining normal
  argument validation, projection/leaf preparation, execution and decoding.
  It is intentionally fixture-specific and must never be adopted. Six serial
  long pairs gave -3.55 microseconds (MAD 2.60, range -8.32 to +1.67), with
  matching SQL, bound parameters and complete result witness. This does not
  establish useful 30-microsecond headroom in SQL fragment composition.
  Receipt: `ablate-sql-preparation-long.json`.
- `council-goal-no-positional` forces the existing generic keyed-row publication
  path, retaining safe integers and strict result decoding. It has built but
  its completed interleaved result below establishes no improvement.

A closer-paired diagnostic harness has completed: each build stays in its
own process; measured blocks alternate between the resident processes, with
only one actively sampling at a time. This keeps the original operation timing
boundary and fresh schemas/clients/connections. `sample()` and `witness()` are
byte-identical to `paired.mjs`; block CPU is separately labelled and includes
assertions, close and V8 work outside the goal wall boundary. Six rounds retain
8192 warmup and 16384 measured fresh clients per arm per round. The schedule,
counts, artifact identities, complete fixture output and process teardown were
checked after completion. The new harness hash is
`12bc9daa0d1574d2eb4f04772a5b1dcfc2b7807ee327de7ab1ce40d726337ac7`.

| Interleaved diagnostic | Paired total delta, microseconds | MAD | Range |
| --- | ---: | ---: | --- |
| Identical frozen artifact | +1.70 | 4.25 | -8.26 to +11.47 |
| Omit required argument validation | -12.44 | 1.71 | -15.05 to -7.52 |
| Force ordinary keyed result path | +3.69 | 3.62 | -6.31 to +22.44 |

The identical-artifact control still shows material noise and an order effect;
this protocol has NOT established reliable resolution for small improvements.
The validation diagnostic is lower in all six rounds, with a first-query-only
delta of -13.50 microseconds (MAD 0.97), but its magnitude remains an observation
under artificial removal, not a mathematical upper bound or a safe optimization.
It provides no evidence that validation alone can save 30 microseconds.
The keyed path establishes no improvement; its positive median is too variable
to claim a precise regression. No production change follows either diagnostic.

Receipts: `interleaved-aa.json`, `interleaved-ablate-admission.json`, and
`interleaved-no-positional.json`. The sums of each pair's sampled worker peaks
plus coordinator lifetime peak stayed at about 701, 681 and 718 MiB respectively.
Despite the harness field's `UpperBound` name, these are conservative sums of
OBSERVED sampled maxima, not guaranteed bounds on unsampled total RSS. Each
worker retained its own existing 1024 MiB process-group guard and verified
teardown; the resource policy was not raised.

An intentional worker-import failure (`interleaved-failure.json` and `.log`)
returned nonzero, recorded the original injected error in worker stderr,
terminated both resident workers and verified whole-group teardown. No success
summary was emitted. The failure specimen is explicitly labelled under
`council-goal-interleaved-failure` and is not an ORM build.

The source review found no repeated admission or selector pass on rows20.
Mutation maps/sets/attempt storage are already lazy. Eliminating known parser
continuations and simple Promise forwarding were already tested in the earlier
`fresh-execution` campaign; these are not new untested opportunities. The
proposed adapter projection-list batching is only a subset of the small SQL
composition diagnostic, so it is not prioritized as a route to 30 microseconds.
The active production source was rehashed after this pass and still matches
the frozen baseline exactly. The goal remains unmet.

Keep all isolated snapshots and receipts. Before adopting any winner, verify its
compatibility tradeoffs, required type gate, affected behavior and retention.
The 30-microsecond target remains unproven. Local Node measurements do not
establish Cloudflare Workers isolate timing.

## Direct first-query phase diagnostics

The following continuation classified the preceding answer-only turn as no
progress, revalidated current source against the frozen baseline, and executed
two new instrumented-source diagnostics. `phase-cost.mjs` runs 8192 fresh
warmup clients followed by 16384 measured fresh clients in 32 blocks. Every
result is compared in full with the independent rows20 fixture, and every
sample asserts that the stock positional path and root decoder each executed
exactly once. No provider hook is replaced. Both runs completed with verified
process teardown (3.52 and 3.72 seconds, sampled peak RSS 288.0 and 286.2 MiB).

The first snapshot measures native preparation, native column metadata, row
fetching, complete positional transport, reader compilation and row decoding.
The second additionally times client construction, hydration, schema validation,
engine construction, root view, argument-schema construction, argument parsing
and read-plan construction. The argument parser can construct deferred schemas;
its interval is not exclusively value checking. Patch and source identities
are saved in `phase-cost-identities.json`; both snapshots retain their patches.

Means in microseconds from `phase-cost-detail.json`, grouped into disjoint
intervals (rounded values may not sum exactly):

| Interval | Mean microseconds |
| --- | ---: |
| Declarations, driver construction, fixture wrapper and remaining setup | 11.78 |
| Client construction, including hydration and schema validation | 12.59 |
| First operation's argument-schema construction | 10.78 |
| Argument parsing, including demanded deferred schemas | 4.77 |
| Read-plan construction | 3.75 |
| Native SQLite statement preparation | 17.80 |
| Native column metadata | 1.97 |
| Native row fetching | 14.63 |
| Remaining positional transport | 3.04 |
| Reader compilation and row decoding | 3.37 |
| Remaining operation lifecycle | 3.17 |
| Complete established setup-plus-query interval | 87.64 |

Client construction's nested intervals include hydration 3.68 and definition
validation 7.10 microseconds. Do not add these again to the table. The less
instrumented first snapshot measured 84.85 total, native prepare plus fetch
32.16, decoder 3.19, and remaining positional transport 2.73 microseconds.
These are instrumented wall observations, not lower bounds or safe removable
cost. Clocks and changed compilation can perturb the program; these cohorts
also use a direct full-result assertion outside timing rather than the paired
harness's canonicalizing assertion. Neither diagnostic is an adoption result.

This evidence deprioritizes decoder call unrolling and another driver-handoff
rewrite as routes to 30 microseconds. It identifies argument-schema construction
as a larger remaining cost than the entire decoder. The earlier plain-getter
catalogue plus model-construction candidate had only short confirmation, so it
received the established six-pair long run: `combined-simple-long.json` records
-10.57 microseconds, MAD 4.88, range -27.93 to +4.08. This is too variable to
establish a reliable new best gain. A nearby identical-artifact control and
interleaved candidate comparison subsequently completed:

| Six-pair interleaved series | Paired delta, microseconds | MAD | Range |
| --- | ---: | ---: | --- |
| Identical frozen baseline (`interleaved-aa-simple-control.json`) | -1.15 | 1.53 | -3.74 to +4.87 |
| Plain getters + construction (`interleaved-combined-simple.json`) | -0.96 | 5.04 | -6.54 to +6.93 |

The larger saving did not reproduce. Do not promote the serial -10.57 result
to a new best optimization. Both interleaved series completed all 12 workers
and 192 measured block pairs, checked identical SQL/parameters/full results,
retained exact build identities and ran worker commands serially. All resource
records reported clean exits and verified teardown. The candidate remains an
isolated experiment, with no production adoption. No large correctness suite
was repeated for a candidate without a confirmed performance benefit.

After the phase and confirmation runs, active production source still matches
the frozen baseline's source hash exactly. The requested 30-microsecond saving
remains unmet. These experiments add first-query cost evidence and reject one
remaining promising short-run result; they do not establish a performance
ceiling or a Workers cold-start result.

## Descriptor batching and local Workers clock evidence

The isolated `council-goal-batched-record` snapshot replaces per-key descriptor
installation in `lazyRecord` with one `Object.defineProperties` call. It keeps
plain own-accessor records, the same per-key builders and memoization, and all
runtime validation. Its dedicated helper witness passed descriptor/reflection,
freeze, deletion, retry, factory receiver, special-key and cloning checks. The
native differential passed 25 cases across all 14 operation families (22
successful, three refused). Receipts use the `batched-record` prefix.

Six interleaved pairs did not establish an improvement: candidate minus baseline
was +1.94 microseconds, MAD 5.27, range -4.07 to +13.57. The candidate remains
isolated; no production adoption or further type/full-suite run follows this
rejection. The completed receipt was independently audited: 12 workers, 192
block pairs, 8192 warmup and 16384 measured fresh clients per worker, sequential
sampling commands, matching SQL/parameters/result witnesses, and exact runtime,
fixture and build identities. All workers exited successfully and the resource
log records verified teardown. Active source still matches the frozen baseline:
`0aa39025ce457303a084cf4cafd7f973ce1754fdd9ac9f178cbb6f848262123c`.

`workerd-clock-probe.mjs` also ran successfully through the bounded launcher
using the installed Wrangler 4.44.0 dependency chain: Miniflare 4.20251011.0,
workerd 1.20251011.0, compatibility date 2025-10-11. No packages were installed,
no service was deployed, and the local worker had no permitted outbound network.
Ten sequential requests checked the clock during CPU work. Observed positive
clock steps were 1 millisecond; the dependent CPU loop measured 5 milliseconds
on the first request, 2 on the second and 1 on the remaining requests. The
runtime disposed successfully (0.94 seconds, 110.4 MiB sampled peak RSS).

This is a timer probe, not an ORM benchmark or a production Workers result.
Its installed clock cannot directly resolve an individual 30-microsecond
change. Aggregated fresh-client measurements or separately labelled external
timing would be necessary; neither should be presented as proof of cold-isolate
latency. Receipts: `workerd-clock-probe.json` and `.log`.

The next code target remains first-operation validation materialization, followed
by fresh model/client construction. The phase diagnostic places roughly 16 and
24 microseconds respectively in those areas, but those are observed costs, not
promised savings. Existing demand-construction experiments already show that
making more wrappers lazy is insufficient to establish the requested 30
microseconds. Any further proposal needs to identify actual construction work
that can be removed while retaining the public validation and reflection
contracts. The goal remains unmet.

## Named object lookup and executed local workerd phases

The next continuation classified the preceding receipt audit/documentation turn
as progress, then tested a different object-validator representation.
`council-goal-named-validators` changes only the key-to-index Map into a
null-prototype record. It preserves the indexed validator array, capture timing,
required/default behavior and validation bodies. An unbuilt draft also removed
the validator array; source review found that this changes the receiver of a
custom validation method. That draft was superseded before any timing and is
retained as `superseded-draft.patch` only.

The final candidate passed 20 object compatibility cases, including captured
method receiver/identity and special property names, plus the existing 25-case
native admission differential. Six interleaved pairs established no gain:
-0.82 microseconds, MAD 2.35, range -5.91 to +1.56. All 12 workers and 192 block
pairs completed; identities, sample counts, sequential commands, SQL, parameters
and full-result witnesses were independently audited. Teardown was verified
(48.70 seconds, coordinator sampled peak 100.1 MiB). No adoption or broader
suite/typecheck follows this rejected candidate. Receipts:
`named-validators-*.log`, `interleaved-named-validators.json` and `.log`.

A local workerd/D1 phase diagnostic has now executed. Its isolated source,
`council-goal-workerd-phases`, derives from `phase-cost-detail`, adding clocks
around the stock D1 typed statement entry. An initial patch-generator match
failed before editing D1; its resulting build has no timing evidence. The
corrected final build and both logs remain. `workerd-phases.mjs` bundles that
artifact into one Worker, seeds a temporary local D1 database with the frozen
100-user/1000-post fixture, then disposes the runtime and removes that owned
database. No deployment, installation or external database is involved;
outbound networking is refused. Timed samples receive the stock D1 binding.

After a small smoke check, the final series ran 8192 fresh-client warmup samples
and 8192 measured samples, sequentially in blocks of 512. Every sample declares
new models, driver and client, executes the first rows20 operation, checks every
field/type/order in all 20 returned rows, and disconnects. Only the database
binding/fixture persists. Every sample asserts one D1 statement, one root
decoder and zero native positional executions. An untimed binding-wrapper
witness records SQL, parameters and actual returned rows. The final receipt's
SQL and parameters match the frozen Node witness. The smoke harness checked
actual rows internally but serialized the expected fixture in that witness
field; this was corrected to serialize actual returned rows before the final
series. Neither receipt has been rewritten.

Approximate instrumented mean wall costs, from aggregate totals using the
installed clock's observed 1-millisecond steps:

| Local workerd interval | Mean microseconds |
| --- | ---: |
| Model declarations, driver and remaining setup | 11.11 |
| Client construction, including hydration and definition validation | 15.50 |
| First operation's argument-schema construction | 8.54 |
| Argument parsing, including demanded deferred schemas | 3.30 |
| Read-plan construction | 3.30 |
| D1 typed statement execution, including local transport | 225.83 |
| Reader compilation and decoding | 3.54 |
| Remaining first-operation work | 5.25 |
| Setup-plus-query interval in this D1 diagnostic | 276.37 |

Client construction includes hydration 3.42 and definition validation 9.77;
these nested intervals must not be added again. Block variation and clock
quantization preclude precise small-delta claims. This is a warmed local
workerd isolate with fresh clients, not cold isolates, hosted D1 latency, a
Drizzle comparison, or a replacement for the original Node goal metric.
Instrumentation can perturb execution. Observed costs are not safely removable
time.

Runtime chain: Wrangler 4.44.0, Miniflare 4.20251011.0, workerd 1.20251011.0,
compatibility date 2025-10-11 with nodejs_compat. The receipt's `v8` field names
the Node coordinator version, not workerd; no independent workerd V8 version
was measured. The final run completed in 6.12 seconds with 720.4 MiB sampled
group peak, successful disposal and verified teardown. Build/bundle identities,
32 ordered blocks, statement/decoder counts and all 163840 measured result rows
were audited. The exact coordinator and Worker body are retained beside the
final bundle under `workerd-phases-long.json.assets`. Receipts:
`workerd-phases-long.json`, `.log`, and
`named-validators-and-workerd-audit.json`.

This target-runtime evidence supports prioritizing construction and
first-operation validation over another decoder micro-optimization. It does
not turn rejected construction variants into winners. Active production source
still matches the frozen baseline exactly. The requested 30-microsecond saving
remains unproven and the goal stays active.

## Ordinary relation target slot and validation review

The preceding answer-only turn was classified as no progress. Current source
and the recorded runtime/build identities were revalidated before this pass.
The new isolated `council-goal-target-slot` snapshot changes only
`src/schema/relation/terminal.ts`: its declaration-lifetime target settlement
uses one local outcome for the default key and creates a Map only for other
keys. The existing settlement/normalization helper is unchanged. This removes
three eager Maps from this fixture's three relation terminals, including the
intermediate to-one terminal discarded by the modifier chain. It introduces
neither cross-client reuse nor a public object-shape change.

`target-slot-witness.mjs` passes 14 focused checks on baseline and candidate.
Eleven exercise the exact source helper/normalizer after built-in TypeScript
stripping; three independently exercise the built public relation factories.
They cover undefined/empty/null key aliasing with the original first argument,
successful undefined outcomes, independent keyed targets, cached missing-target
and normalized errors, retryable getter-read failures, reentrant outer
completion/error replacing an inner value, JavaScript Map-key identity,
independent modified terminals and shared-terminal lifetime. The source helper
checks are not claimed as tests through the public package. The separate native
operation differential also passed all 25 cases (22 success, three refusal).

Six interleaved pairs did NOT establish a wall-time improvement:

| Interval | Paired median delta, microseconds | MAD | Range |
| --- | ---: | ---: | --- |
| Schema/client construction | -0.93 | 0.93 | -2.21 to +2.13 |
| First query | -1.17 | 1.72 | -3.53 to +4.06 |
| Established setup-plus-query metric | -0.78 | 3.64 | -5.05 to +5.67 |
| Continuous interval including connection | -0.35 | 4.32 | -7.32 to +5.11 |

Medians for separate phases must not be added to reconstruct the total median.
The candidate is rejected for adoption; no full-suite/type/retention gate was
run for it. The run completed in 49.14 seconds. All 12 workers and 192 block
pairs completed, with 8192 warmups and 16384 measured fresh clients per worker.
An audit checked sequential worker commands, sample counts, matching SQL,
parameters and full-result witnesses, exact artifact/runtime identities and
successful resource outcomes. Teardown was verified. The sum of observed
sampled worker/coordinator maxima was 696.9 MiB, not a guaranteed RSS bound.
The short correctness jobs finished before the resource sampler recorded a
positive peak; their logged zero must not be read as zero memory consumption.

Receipts: `target-slot-build.log`, `target-slot-witness.log`,
`target-slot-native.log`, `interleaved-target-slot.json` and `.log`, and
`target-slot-audit.json`. Snapshot source hash:
`7d7308a4fb8580852c9a819d974814d21b6a9c46b156acbed19043fd59dbeafe`;
its built `.mjs` hash:
`cfec3ae6af9f1ea14491bed7ef175172c038f880dc8ca84e1a2d9b2f2119031f`.

A bounded independent read-only review found no new whole validation stage to
remove. The preliminary unknown-key walk protects error/getter ordering: an
unknown key currently wins before a known field's throwing getter is invoked.
First object use captures every entry's validator/default metadata, preserving
which validator and receiver later reads use even after public schema mutation.
Deferring that capture and materializing relation families only on demand were
already experimented with. The omit/select/include wrappers inspect the
projection clauses but do not repeat object validation. Their envelopes remain
an allocation experiment, not a newly discovered duplicate validation pass.

Another construction idea, lazy model name-registry allocation, was found in
the older `council/model.patch` and `council/report.md` Model metadata experiment.
Although `construction-v2` kept those Maps eager, removing them from discarded
intermediate models is not a new untested mechanism; the earlier broader
experiment showed no consistent full-use gain. A narrower version would still
change reflection over the TypeScript-private registry field.

This pass rejects another measured allocation change and narrows the source
review; it does not establish a performance ceiling. Active production source
still has hash
`0aa39025ce457303a084cf4cafd7f973ce1754fdd9ac9f178cbb6f848262123c`.
The requested 30-microsecond improvement remains unmet. Further work must
identify an actual construction algorithm change or another source of elapsed
time; the same catalogue/wrapper/Map substitutions are not new experiments.

## Endpoint-owned pairing decisions

The preceding target-slot pass was progress: a new experiment and compatibility
review changed the next action. This continuation rechecked the current tree
and tested a different graph-resolution representation in
`council-goal-endpoint-decisions`. Only
`src/schema/validation/relation-resolution.ts` differs from the frozen baseline.

The resolver now stores each pairing decision on its private endpoint instead
of maintaining separate endpoint-to-candidates and endpoint-to-verdict Maps.
One compatibility predicate still owns structural candidacy. The decision pass
counts structural and exact-name matches without creating lists for successful
pairs; ambiguous/name-mismatch decisions alone retain the candidate arrays
needed by diagnostics. This removes two Maps and four temporary arrays from
this fixture's successful two-endpoint pair. It adds one private verdict slot
per endpoint. All endpoint state remains local to one resolution; public
declarations, resolved-slot/edge shapes, ordering and topology rules are
unchanged. This is a representation experiment, not skipped validation.

Focused verification used unchanged copies of four existing test files and
three fixtures, with aliases pointing at the candidate source. The first run
passed 33 tests in the pairing and variant suites but failed to load the other
two suites because the isolated snapshot lacked their `@tests` fixtures. After
copying those unchanged fixtures and adding the alias, only those two suites
were rerun: 78 more tests passed. Thus 111 tests across all four selected files
actually ran successfully; the original failed log remains retained.

`endpoint-decisions-differential.mjs` separately compares the built baseline and
candidate through public `validateSchema`, including the complete messages and
ordered candidate lists. All 396 cases matched (54 accepted, 342 refused):
ordinary name partitions/ambiguities, reversed model order, self relations,
and both variant-carrier/inverse cardinalities. This generated differential's
refusals cover R009/R010; the existing topology matrix supplies broader refusal
and resolved-edge identity coverage. The built native operation differential
also passed its 25 cases across 14 operation families.

Six interleaved pairs again established no performance benefit:

| Interval | Paired median delta, microseconds | MAD | Range |
| --- | ---: | ---: | --- |
| Schema/client construction | -0.28 | 1.13 | -2.34 to +2.61 |
| First query | -0.39 | 1.34 | -2.64 to +1.46 |
| Established setup-plus-query metric | -0.84 | 2.90 | -3.96 to +2.40 |
| Continuous interval including connection | -1.43 | 1.74 | -6.34 to +3.02 |

The run completed in 46.23 seconds. The receipt audit checked 12 workers,
192 paired blocks, 8192 warmups and 16384 measured fresh clients per worker,
sequential sampling commands, matching SQL/parameters/full-result witnesses,
and exact runtime/harness/fixture/build identities. All worker exits and bounded
teardown succeeded. Observed sampled peak sums were 705.0 MiB; as before, this
is not a guaranteed RSS bound. No further type/full-suite/retention gate follows
a candidate with no confirmed performance benefit.

Receipts use the `endpoint-decisions` prefix: build, topology (including the
initial missing-fixture failure), topology-retry, differential, native and audit.
Timing is in `interleaved-endpoint-decisions.json` and `.log`. Candidate source
hash: `300145e2c9c45fb54bb9622e2de605c5d8aa85fe8e906aec4640c69a78175a37`;
built `.mjs` hash:
`9a332bd6eefa4fc794c626a3ae6c56becbfedf734b0f4ee9a9cda55b9cd735ef`.
Its full patch and isolated test configuration are saved with the snapshot.

No production adoption. Active source still matches
`0aa39025ce457303a084cf4cafd7f973ce1754fdd9ac9f178cbb6f848262123c`.
The 30-microsecond goal remains unmet; removing this graph bookkeeping does not
provide evidence of a route to it.

## First request in fresh local Worker isolates

The preceding recommendation-only turn was no progress. This continuation
revalidated the active source and frozen build hashes, then reviewed the
proposed compact validation representation. That review produced no new
implementation: the current object validator's first-use capture protects
subsequent validator/default behavior, while the existing demand-schema
candidate already defers the unused public catalogues. A direct rule
interpreter remains a structural hypothesis, not a tested optimization.

Instead of crediting warmed Node results as Workers cold-start evidence, this
pass executed a previously missing target-runtime comparison. New diagnostic
`workerd-cold.mjs` bundles the uninstrumented frozen baseline and the existing
`council-goal-demand-read` candidate. Each sample creates a new Miniflare
runtime, seeds an owned local D1 fixture, sends exactly the FIRST application
request, and disposes the runtime before another sample starts. An application
request counter must be one in every measured response. Each request constructs
fresh models, driver and client and awaits rows20. Module initialization is
outside the Worker timer; there is no application/ORM warmup. This measures
local cold first use, not hosted Workers cold-start latency or a replacement
for the original warmed-Node/fresh-client goal boundary.

The measured request uses the stock D1 binding. Complete results are checked
outside its timer. A second, untimed request on each runtime captures and
checks the exact SQL/parameters and full results; the measured request has
already completed before that interception. The fixture, query, SQL and row
values match the earlier D1 and native rows20 diagnostics. No dependency
installation, deployment or external database access occurred. Outbound
network access in the Worker is disabled, and every temporary D1 directory
created by the harness was removed after disposal.

Two smoke pairs were followed by 20 identical-build pairs and 20
baseline/candidate pairs, alternating arm order. Both complete series have
40 fresh runtimes. The local Worker clock produced millisecond steps. A
separate high-resolution Node host clock measures dispatch through response
consumption, including transport/serialization overhead; it is a different
boundary and does not remove the uncertainty from the Worker clock.

| Comparison | Worker setup-plus-query median delta | Worker MAD | Host dispatch median delta | Host MAD |
| --- | ---: | ---: | ---: | ---: |
| Identical baseline build | 0 microseconds | 0 microseconds | +65.17 microseconds | 339.50 microseconds |
| Demand-built operation schemas | 0 microseconds | 1000 microseconds | +3.33 microseconds | 292.85 microseconds |

The identical-build zero MAD is a quantization artifact, not zero variation:
its paired Worker deltas range from -1000 to +1000 microseconds. Candidate
Worker deltas range from -2000 to +1000. Baseline and candidate setup-plus-query
medians are both 5000 microseconds in the candidate comparison. Their means
are 5450 and 5100; the apparent -350 microseconds mean difference is NOT a
confirmed gain given the coarse clock, control and dispatch evidence.

The identical-build run completed in 36.10 seconds with 697.4 MiB sampled
process-group peak. The candidate run completed in 36.39 seconds with 700.8
MiB sampled peak. Both stayed under the voluntary 1024 MiB guard, and the
bounded launcher verified teardown. The smoke run used 684.2 MiB / 4.14 seconds.
No broad test suite was repeated for this measurement-only change.

`workerd-cold-audit.json` independently checks all 84 first-request and 84
untimed witness receipts, alternating schedules, computed deltas, result hashes,
resource completions and exact source/build/harness/bundle identities. The
coordinator, Worker body and bundles are retained with each JSON receipt under
its `.assets` directory. The demand candidate build hash is
`50ed669eacc280a4a3cb915b8e55b4d7cc2d90da20e40b6660ec1156c448e74e`.

This establishes the missing fresh-isolate comparison and finds no demonstrated
benefit from the demand-schema candidate there. It does not prove a performance
ceiling. A more compact rule interpreter still needs a distinct implementation
and preserved public behavior before it can be assessed; repeating the same
demand wrappers would not test that hypothesis. Production source remains
unchanged at `0aa39025ce457303a084cf4cafd7f973ce1754fdd9ac9f178cbb6f848262123c`.
The original 30-microsecond goal remains active and unmet.

## Schema-local object validation plan

The preceding fresh-Worker comparison was progress: it supplied a missing
runtime experiment and did not support adopting the demand-schema candidate.
This continuation tested a new representation inside the existing object
validator owner. `council-goal-object-plan` changes only
`src/validation/primitives/object.ts`. It moves captured compilation metadata
into a private schema-local `ObjectValidationPlan`, shares its compilation and
validation methods, and retains one receiver-independent public callback. It
removes the per-schema resolver closure but adds a state object and a method
call; it does not remove a validation rule, schema envelope or catalogue.
It is therefore a test of validation-state representation, not the previously
proposed direct interpreter over model rules.

The compiler still publishes its arrays before invoking entry thunks, marks
compilation started before any thunk, and captures validators/default metadata
at the same boundary. The public object factory, entries/options identity,
wrappers, JSON Schema getter and extend behavior are unchanged. No global
model/client/query cache is introduced. The prototype was never applied to
production source.

Verification completed against this isolated snapshot:

- The unchanged existing `object.core.test.ts` passed all 74 tests. Its isolated
  configuration points every source alias at the candidate, and the printed
  root confirms that snapshot. These runtime tests are not a TypeScript check.
- `object-plan-differential.mjs` passed 23 baseline/candidate checks. It extends
  the earlier 18-case object oracle with captured custom-validator array
  receivers after public mutation, undefined `refuse` receiver, option-value
  capture versus deferred required-key-array observation, reentrant entry
  compilation, and detached validation of frozen schemas.
- The native operation differential passed 25 cases across all 14 operation
  families: 22 accepted, three refused, with native admission before public
  introspection and stable subsequent schema identity.

Six interleaved pairs found no confirmed wall-time benefit:

| Interval | Paired median delta, microseconds | MAD | Range |
| --- | ---: | ---: | --- |
| Schema/client construction | +0.00 | 0.78 | -0.81 to +0.99 |
| First query | -0.66 | 1.49 | -3.27 to +1.69 |
| Established setup-plus-query metric | -0.33 | 1.45 | -3.69 to +2.68 |
| Continuous interval including connection | -1.19 | 1.61 | -3.76 to +4.73 |

The comparison completed in 46.22 seconds. Each of 12 workers ran 8192 fresh
warmups and 16384 measured fresh clients, making 192 adjacent block pairs.
The observed sampled worker/coordinator peak sum was 691.1 MiB, under the
1024 MiB diagnostic rejection threshold; this sum is not a guaranteed RSS
bound. Every resource result and launcher teardown succeeded. The small
differential jobs completed before the RSS sampler recorded a positive peak;
their zero readings do not mean zero memory use.

`object-plan-audit.json` checks counts, the serial command schedule, matching
SQL/parameters/full-result witnesses, paired arithmetic, worker exits and exact
source/build/harness identities. It also verifies the changed source bytes
embedded in the built source map and the unchanged test copy. The first audit
attempt misread an already-aggregated numeric phase as a statistics object;
the corrected audit reads the recorded numeric phase directly. No benchmark
rerun was necessary for that audit-reader correction.

Candidate source hash:
`76dc1722f9aef1347f4011b35aee44ac46a893f326f600bdf09f06db3572d895`;
built `.mjs` hash:
`eb6c16c555171888101f8fbf572399875fb6b0b0b77e6c936a5bfd0d003d79a3`.
Receipts use the `object-plan` prefix, with timing in
`interleaved-object-plan.json` and `.log`. The snapshot retains its complete
patch and isolated test configuration.

Rejected for adoption. No broad type/full-suite/retention campaign follows a
candidate with no established wall benefit. This result does not test away the
cost of constructing whole schema graphs; it rejects replacing their object
validator closures with this private state representation as a useful route.
Production source still matches the frozen baseline exactly. The requested
30-microsecond improvement remains unmet and the goal remains active.

## Shared lazy Proxy handlers

`council-goal-lazy-proxy` changes only `validation/primitives/lazy.ts`.
It keeps the ordinary private target and existing observable trap behavior,
but moves each factory/value cell to a private WeakMap and shares the five
handlers and resolver. It does not change `lazyRef`, reuse schemas across
clients, or implement a direct interpreter over model rules.

The isolated snapshot passed the five existing lazy-schema tests, 11 focused
baseline/candidate Proxy and factory-lifetime checks, and the 25-case native
operation differential. The initial Proxy witness failed on the baseline
because its circular fixture eagerly resolved its own schema; deferring the
array entry corrected the witness. Both logs are retained. No production
failure or candidate fix was involved.

Six interleaved pairs found no confirmed improvement. Paired candidate-minus-
baseline setup-plus-query time was +0.36 microseconds, MAD 2.29, range -2.75
to +4.83. Construction was +0.76, MAD 0.99; first query +0.56, MAD 1.34.
The complete comparison took 46.79 seconds. Twelve workers each ran 8192
fresh warmups and 16384 measured fresh clients, producing 192 adjacent block
pairs. Their observed sampled peak sum with the coordinator was 706.3 MiB;
this is not a guaranteed RSS bound. All workers and launcher teardown passed.

`lazy-proxy-audit.json` checks counts, schedule, complete result/SQL witnesses,
paired arithmetic, source-map contents and exact source/build identities.
Candidate source hash:
`bebf66949491453de4be8882b521eaa383cea9b87c3d7358af857bf71887b893`;
dist hash:
`2d821a617e8c1a81ad0248e53a76e688a95cd7caefce4014862c0f22d9c7a8e0`.
Receipts use the `lazy-proxy` prefix and `interleaved-lazy-proxy.json`/`.log`.
The prototype is rejected; no full-suite, type or retention adoption gate was
run for a candidate without a demonstrated wall-time gain.

A separate read-only transport review also rejects using native numbers for
selected SQLite integer projections as a route to this goal. Although the
stock int/boolean codecs preserve their accepted values, the positional
executor can fall back to a borrowed parser after fetching. That parser must
still receive the exact original BigInt carrier. A changed parser or statement
completion observer can expose this difference; the conclusion here is source
analysis, not a newly executed runtime falsifier. Earlier native rows20 controls
found only about 0.35 microseconds of transport headroom from numeric integers.

Production source remains at the frozen baseline hash. Removing construction
of validation graphs remains an untested structural hypothesis; sharing their
closures or Proxy handlers has not established a useful gain. The requested
30-microsecond improvement remains unmet.

## Fused find-schema construction

The preceding recommendation turn added the already-completed lazy-Proxy
receipt to this ledger but generated no new performance evidence. This
continuation revalidated source/build identities and tested a distinct
construction reduction in `council-goal-fused-find`.

`findMany` and `findFirst` ordinarily construct an object schema, copy it in
the select/include guard, and copy it again in omit projection. The candidate
composes the existing validators before constructing the final public
envelope. It removes two intermediate schema records and two Standard Schema
records from this path. The hidden original envelope is materialized only if
JSON/types introspection requests it, using the already-created validator and
captured entries/options. Detached `.extend()` remains an ordinary unguarded
object schema. Both public projection wrappers consume the same extracted
compositors and preserve dynamic method lookup on their captured Standard
object, including its receiver.

This is a reduction in intermediate schema representation, not the complete
direct interpreter over model rules. Object admission, orderBy, unions, arrays,
and model catalogues still use the existing construction paths. No model,
client, query, statement or result is reused across measured samples.

Verification against the isolated candidate completed:

- Whole-estate native TypeScript passed, 5.31 seconds and 5732.1 MiB sampled
  peak under its existing dedicated 8192 MiB ceiling. The initial narrow
  typecheck found the compositor's Standard Schema result-type mismatch and
  stopped at its 1024 MiB resource guard (1714.5 MiB sampled overshoot).
  After correcting the type, the first whole-estate check found two missing
  copied root test configuration files; copying those produced the passing
  run. Every launcher verified teardown. No ordinary ceiling was raised.
- 162 focused runtime tests passed: 74 existing object tests, 66 find-args,
  19 omit tests, and three new public-wrapper capture/receiver checks.
  The first isolated invocation discovered the copied root workspace config;
  the next hit Vite's file-serving allowlist after moving the config. The
  final configuration lives in `verification/vitest.config.mjs` and explicitly
  allows this snapshot and the existing dependency directory. It ran exactly
  the four declared files, with all source aliases pointing into the snapshot.
- `fused-find-differential.mjs` passed 18 built baseline/candidate cases:
  exact public shape, projection refusals, input getter order, frozen first
  introspection, original JSON references, no delayed option re-observation,
  detached extend, validator capture and detached parse. Its first run refused
  an incorrect assertion on the BASELINE: this converter does not expose the
  object option's description. The corrected witness checks the converter's
  actual strictness option, including a later mutation of the original object.
- The unchanged native differential passed 25 cases across all 14 families,
  22 successes and three refusals, with full subsequent public schema identity.

All timing uses the established warmed-runtime/fresh-client setup-plus-first-
query metric. Negative deltas mean the candidate label was faster.

| Six-pair series | Paired median delta, microseconds | MAD | Pair range |
| --- | ---: | ---: | --- |
| Initial fused find candidate | -1.80 | 0.84 | -2.92 to +5.04 |
| Identical frozen builds | -1.84 | 1.19 | -7.14 to +2.49 |
| Fused find confirmation | +0.63 | 0.56 | -6.99 to +1.54 |

The initial result narrowly passed the 2×MAD rule but was no larger than the
contemporaneous identical-build variation and did not repeat. Separate arm
medians and paired means must not be substituted for the paired median to
claim a gain. This candidate has no established wall-time benefit and is
rejected for adoption. It supplies no part of the requested 30-microsecond
improvement.

Each series ran 12 workers, 192 adjacent block pairs, 8192 fresh warmups and
16384 measured fresh clients per worker. Runs took 46.48, 46.92 and 46.97
seconds; observed sampled worker/coordinator peak sums were 697.6, 716.1 and
690.0 MiB. Those sums are observations, not guaranteed RSS bounds. All worker
exits and launcher teardowns passed. No runtime suite or retention campaign
follows this rejected candidate.

`fused-find-audit.py` independently verifies receipt arithmetic, serial
scheduling, sample counts, exact runtime/build/harness identities, complete
SQL/parameter/result witnesses, unchanged existing test copies, changed source
contents inside the built maps, resource completions and active source identity.
Its output is `fused-find-audit.json`. Logs use the `fused-find` prefix; timing
receipts are `interleaved-fused-find{,-aa,-confirm}.json` and corresponding logs.
The snapshot retains the complete patch and test configuration.

Candidate source hash:
`0711b70a33b1491ef58497d23d7b71204ebff5d182424faa560f3a278d3c4105`;
built `.mjs` hash:
`5c5e3cae7b2b1fd6c6e9b6ebe92d2acb71e8d4cba3268ea2360d930a22800a59`.
Production source is still byte-identical to the frozen baseline.

A bounded independent source review also checked declaration-time scalar base
schemas, separately from the earlier operation-catalogue experiment. The ten
initial factories use existing module-level bases; the two `.id()` and two
model `.map()` calls construct none. Only three nullable modifiers build fresh
base schemas. Deferring those would replace public data properties with lazy
machinery and must preserve custom-validator capture at modifier time. This is
a small residual allocation, not a previously missed construction graph; no
new timing or prototype was claimed for it. The 30-microsecond goal remains
active and unmet.


## Deferred validation representations

`council-goal-construction-plan` starts from `council-goal-demand-read` and
adds a private `ValidationConstruction` cell. Object, union, array and deferred
reference construction can capture existing validators without constructing
ordinary public schema/Standard Schema records. Public introspection materializes
ordinary records from the same state. Both findMany and findFirst cover all nine
argument clauses, including native orderBy construction. This removes public
representation work; it still builds the existing validators and their compiled
lookup structures. It is not a direct interpreter that removes that compilation.
No schema, client, query, statement or result is shared across timed samples.

Validation completed on the isolated snapshot:

- Whole-estate TypeScript passed in 7.01 seconds, 6758.2 MiB sampled peak under
  the existing dedicated 8192 MiB limit. The first two attempts found real generic
  type errors; the final correction used typed factory overloads and retained the
  existing validation result protocol. All attempts and teardown evidence remain.
- 197 existing tests passed across object, array, union, lazy, find-args and omit
  validation. The isolated configuration names exactly those six files and points
  every source alias into the snapshot. No broad runtime suite was run.
- 36 baseline/candidate native cases passed: 28 accepted, eight refused, across
  all 14 operation families. The witness explicitly enters getOperationInput
  before introspection and verifies that both find operations actually use the
  internal construction. It then compares public parsing and repeated public
  schema identity. It covers every find clause and recursive relations.
- The prior 18 public find-schema differential cases also passed unchanged,
  including own descriptors, frozen introspection, JSON, defaults, omission,
  refusal precedence, getter/Proxy observation and validator capture.

Six interleaved pairs per comparison, same established setup-plus-query boundary:

| Baseline | Candidate-minus-baseline median, µs | MAD | Range |
| --- | ---: | ---: | --- |
| Frozen production source | -5.21 | 3.45 | -9.33 to +2.42 |
| Simpler demand-read prototype | -2.70 | 1.61 | -10.21 to +3.45 |

Neither comparison clears the existing 2×MAD screening rule. The direct comparison
prevents attributing the earlier demand-read work to the new representation.
These are inconclusive savings, not an established gain or proof of equivalence.
No contemporaneous A/A or confirmation run was needed to reject adoption: no
positive performance claim is made. The more complex prototype is not adopted.
This does not establish a 30-microsecond route.

Each series ran 12 workers, 192 adjacent block pairs, 8192 fresh warmups and
16384 measured fresh clients per worker. SQL, parameters and complete result
witnesses matched. Sampled worker/coordinator peak sums were 694.0 and 730.6 MiB;
these are observed sums, not guaranteed bounds or retained-heap measurements.
All worker exits and launcher teardowns passed. No retention campaign follows
this unadopted prototype.

`construction-plan-audit.py` independently checks exact builds, harness/fixture,
source maps, unchanged tests, schedules, sample counts and paired arithmetic.
Its initial version expected type-only files in JavaScript source maps; the
corrected audit explicitly accounts for those two erased files while including
both in the source hash and full typecheck. The snapshot retains candidate.patch.

Candidate source hash: `b75ae23ea7b70eec23a75422baa647f2e266517b60d74090b1430a5af2e6cfab`.
Built `.mjs` hash: `4ba662dda0fa588eaa462814b151ad5f5e8d60673f7f39aa00aba7b8b214301c`.
Production source still equals the frozen baseline; the 30-microsecond goal
remains active and unmet. The most defensible small target remains avoiding unused
validation catalogues. Any larger follow-up needs to remove actual validation or
initialization preparation while preserving its rules, rather than exchanging
public schema objects for similarly costly bookkeeping objects. The warmed Node
results do not establish a fresh Workers-isolate improvement.


## Fixed find argument compilation (2026-10-01)

The previous turn was progress: it implemented and checked the larger
construction-cell prototype and measured it against both the frozen baseline
and its demand-read parent. Neither comparison established an adoption gain.
The next turn tested a distinct reduction in actual compilation work.

`council-goal-fixed-find` starts from demand-read. One module-private definition
owns the nine findMany/findFirst clause names and factories. It supplies both
ordinary public schema entries and native admission. The fixed key index is
constructed once from that definition; model-specific clause schemas remain
operation-owned and are never reused across clients. This shares immutable
language structure, not a learned query/client cache. Module evaluation is
outside the established metric, so the comparison supplies no fresh-isolate
claim about that fixed initialization cost.

The native path no longer constructs seven deferred argument schema wrappers
or compiles an argument key/validator/default/scratch catalogue per client.
Only supplied deferred clauses resolve. The existing orderBy and all other
clause schemas still own their validation. `object.ts` owns one shared strict
unknown-key check and one partial-object traversal, consumed by both generic
objects and the fixed shape. Generic constraints, defaults and dense-output
rules stay with the existing compiler. The generic path reuses the walker's
success object, avoiding an added wrapper allocation.

Public introspection before compilation creates ordinary schemas and keeps
their compiler authoritative. Introspection after native compilation exposes
ordinary envelopes around the same captured validator state. In particular,
undefined/non-record/select+include refusals do not mark compilation started;
a record reaching the strict unknown-key check does. If an omit/select/include
input getter triggers introspection during a native precheck, the existing
generic BASE validator runs beneath the already-running projection guards.
That preserves property observations without running the guards twice.

The independent read agent owned only `object.ts` in this snapshot and then
reviewed the exposure boundary. Root implemented the find state and registry
wiring, inspected the integrated code, and ran all verification serially.

- 197 existing runtime tests passed across six explicit files, with source
  aliases pointing into the isolated snapshot. 1.65 seconds, 279.3 MiB sampled
  process-group peak; teardown verified.
- 36 native differential cases passed (28 accepted/eight refused), exercising
  the internal first-admission representation and all 14 operation families.
- 18 unchanged public schema differential cases passed.
- `fixed-find-exposure.mjs` passed 16 additional baseline/candidate cases:
  capture timing after successful/failed first calls, entry replacement before
  and after capture, introspection from precheck/field getters, and frozen
  native-first JSON/public validation.
- Full TypeScript passed. An initial 6.13-second successful run was followed
  by a final frozen-source check after the last success-result allocation
  correction: 6.08 seconds, 6255.8 MiB sampled peak under the existing dedicated
  8192 MiB allowance. Both teardowns passed. No generic ceiling was raised.

Six interleaved pairs found a setup-plus-query paired median of -3.53 µs,
MAD 4.87 µs, range -9.54 to +2.95. This fails the existing 2×MAD screen;
it does not establish a gain, equivalence, or an additional benefit over the
simpler demand-read candidate. The candidate is rejected for adoption.
No repeated timing, cold-isolate, full-runtime or retention campaign follows
this inconclusive candidate. The requested 30 µs saving is not achieved.

The comparison used 12 independent workers, 192 adjacent block pairs, 8192
fresh warmups and 16384 fresh measured clients per worker. Every sample uses
fresh schema, client and native connection. SQL, parameters and full results
matched. The observed sampled worker/coordinator peak sum was 700.4 MiB,
not a retained-heap measurement or guaranteed RSS bound. All worker exits
and coordinator/launcher teardown checks passed.

`fixed-find-audit.py` checks the exact builds, mapped runtime source, erased
type-only changes, copied tests, sample counts, serial schedules, witnesses,
paired arithmetic and resource completions. Output: `fixed-find-audit.json`.
The snapshot retains candidate.patch. Source hash: `f75d93bf0637da7185142d21aa23db56e0c0a3f464bf7caae28d82cba605d1dd`.
Build hash: `8e93d970d552747060cec5b7f0e9f140b3def22484f8ad1fee82e6a397139fd6`.

A subsequent source check found that Model.map already reuses the shape's
classified scalar/relation/unique maps. Combining initial shape extraction and
changing Model metadata representation were already included in construction-v2;
lazy registry allocation was also previously explored. No new construction
experiment or saving is claimed for that read-only check. Production source
remains byte-identical to the frozen baseline and the full goal remains active.


The phase split deserves separate diagnosis before another allocation rewrite.
For this same fixed-find receipt, paired first-query median is -7.28 µs
(MAD 2.32), but schema/client construction is +3.35 µs (MAD 2.88).
Construction-plan previously showed the same direction: first query -7.18 µs
and construction +2.31 µs. These medians do not algebraically sum to the total
paired median. Most new find machinery executes only in the first-query phase,
so these observations warrant distinguishing direct initialization work from
GC/JIT effects or worker drift. They do not prove a specific cause or justify
crediting the query-only improvement toward the inclusive goal. At that point no
GC attribution experiment had run; the subsequent diagnostic follows below.

## GC attribution, ordinary confirmation and allocation evidence (2026-10-01)

The intervening recommendation-only turn added no new evidence. This continuation
revalidated the exact active source and both built snapshots before executing the
next comparison. Production source remains the frozen baseline.

The separate `interleaved-gc.mjs` diagnostic retains the ordinary phase boundaries
but records reported GC interval overlap. A synthetic boundary/overlap test and
a live forced-GC positive control passed; forced collection occurs before warmup,
never in measured samples. The identical-build and fixed-find series each used
six pairs and the ordinary sample counts. No late GC entries were detected.
`gc-analysis.py` audits the recorded aggregates and arithmetic. Raw per-sample
timeline/GC intervals are not retained, so that audit does not independently
recompute the original intersections.

| GC-instrumented fixed-find interval | Raw paired delta, µs | Reported GC overlap delta, µs | GC-subtracted diagnostic, µs |
| --- | ---: | ---: | ---: |
| Schema/client construction | +1.37 | +1.90 | -0.53 |
| First query | -8.88 | +0.13 | -8.86 |
| Setup + first query | -7.47 | +2.18 | -9.38 |

These are separate medians and are not algebraically additive. The identical-
build inclusive control was -0.88 µs, MAD 1.03. The diagnostic supports GC overlap
as an explanation for the observed constructor regression in that run. It does
not prove which allocations caused a collection, and instrumented or GC-
subtracted values cannot count as an adoption gain.

An ordinary, unmodified-harness control and confirmation then executed serially:

| Ordinary series | Paired setup + query median, µs | MAD | Range |
| --- | ---: | ---: | --- |
| Identical frozen builds | +2.24 | 2.08 | +0.01 to +5.34 |
| Fixed-find confirmation | -4.77 | 2.90 | -11.86 to +5.07 |

The confirmation again fails the existing 2×MAD screen. It does not establish a
repeatable saving. Receipts are `interleaved-fixed-find-aa.json` and
`interleaved-fixed-find-confirm.json`, with corresponding logs. Both contain 12
successful workers, 192 adjacent block pairs, 8192 fresh warmups and 16384 fresh
measured clients per worker. Exact SQL/parameters/full-result witnesses match,
all 432 commands are serial, and all 13 teardowns per run passed. Sampled peak
sums were 704.0 and 698.4 MiB; these are observations, not retained heap or a
guaranteed bound. `fixed-find-audit.py` now verifies all three ordinary series.

A distinct allocation investigation used `first-use-allocation.mjs`: four serial
fresh-process profiles in baseline/candidate/candidate/baseline order, each with
8192 fresh warmups and 2048 fresh operations. V8 samples at 4096 bytes with both
minor- and major-GC-collected allocations included. Connection, full result
assertion and close are included in this allocation diagnostic; its boundary is
explicitly wider than the goal wall-time interval. SQL witnesses are taken
outside sampling, exact descriptors restored, and complete returned rows checked
for every sample. No profiler timing is reported as performance evidence.

| Sampled allocated bytes per operation | Baseline mean of two | Fixed-find mean of two |
| --- | ---: | ---: |
| Entire diagnostic workload | 178,645 | 150,425 |
| Argument admission (inclusive mapped stack) | 46,646 | 18,180 |

The two runs per build agree closely on total bytes. The measured reduction is
about 28.2 KB, or 15.8%; admission accounts for approximately 28.5 KB of it.
Sampling noise in other frames explains why these differences are not identical.
This is evidence of lower allocation volume, not lower retained memory or a
proven wall-time gain. Higher GC overlap in the earlier instrumented interval
therefore cannot be interpreted as proof that this candidate allocates more.

`allocation-fixed-audit.py` verifies build/harness/fixture identities, profiler
options and raw profile hashes, sums raw node sizes, checks source-mapped totals,
equal SQL/result witnesses and teardown logs. Its first assertion required every
frame to have a source map; it was corrected to allow exactly the two directly
executed JavaScript fixture/harness files, while still requiring maps for bundled
ORM source. All four profiles and the source-mapped summary are retained.

An independent read review identified an untested structural follow-up: ordinary
scalar ordering still builds a model-width orderBy entry/compiled catalogue.
The isolated `council-goal-direct-orderby` experiment is being prepared to remove
that construction using the same primitive object traversal and one field-schema
selector, preserving public exposure semantics. No result is claimed for it yet.
Fixed-find remains unadopted; the full 30-microsecond objective is active and unmet.

## Direct ordering admission experiment

`council-goal-direct-orderby` now contains the completed isolated experiment,
derived from fixed-find. Five runtime files change: object primitive, ordering
factory, core resolver, find arguments and model schema state. The ordinary
object primitive retains strict-key refusal, sparse traversal, undefined
omission, error prefixing and its generic validator-array receiver. Its key
lookup now admits either numeric handles or model field names.

Before public exposure, native ordering checks membership against the existing
model/family records. A single scalar selector serves both native admission and
public entries. Relation validators resolve only when used. Exposing public
schema containers materializes ordinary entries and completes the remaining
capture, so replacement of public entries does not retroactively change an
already compiled validator. Find argument union options and array items expose
the originally captured ordinary schema, even after the public core schema is
replaced. No query/client/model cache crosses fresh samples. There are no new
explicit casts or `any`; existing public factory assertions remain.

This removes actual ordering catalogue compilation. It adds private ordering
state and exposure coordination; it is not a source-complexity reduction.

Root inspected the integrated source and ran all jobs serially after the agent
froze its five files:

- 244 existing tests passed in nine explicitly selected files, 2.15 seconds,
  296.3 MiB sampled process-group peak. All aliases point into the snapshot.
- 78 new ordering differential cases passed against the frozen baseline. These
  cover scalar/vector/point/decimal-list ordering, arrays, strict errors,
  inherited keys, relations, first-use/public-repeat behavior, entry replacement,
  getters, extension, JSON and public union capture.
- The existing 36 native-operation, 18 public-find and 16 exposure cases passed:
  148 total differential cases with this candidate.
- Full native TypeScript passed in 6.73 seconds, 6153.1 MiB sampled peak under
  the existing dedicated 8192 MiB allowance. No ordinary ceiling was raised.

The initial new witness attempted an invalid numeric model field, which the
baseline correctly refused before query admission. The fixture was corrected;
a numeric query key remains an explicit unknown-key refusal. A second baseline
control exposed its existing first-JSON-access-after-freeze exception. The final
witness pins that failure separately and verifies normal JSON generation before
freezing. Neither baseline behavior was silently changed. The 76-case baseline
self/parent controls passed before two additional union identity cases brought
the final candidate witness to 78.

| Ordinary comparison | Paired setup + first query median, µs | MAD | Range |
| --- | ---: | ---: | --- |
| Direct ordering versus fixed-find parent | -5.90 | 2.81 | -12.40 to +11.10 |
| Combined prototype versus frozen baseline | -8.52 | 3.32 | -16.71 to +6.04 |
| Combined prototype confirmation | -1.99 | 5.69 | -24.57 to +8.27 |

The first two series narrowly clear the 2×MAD screen; confirmation does not.
The baseline's median rose from 86.68 to 114.47 µs during confirmation. That
documents changing timing conditions but does not establish their cause or
permit discarding the unfavorable series. No repeatable inclusive saving is
claimed. Query-only savings remain inadmissible as a substitute for the goal.
No additional timing series is launched merely to seek a favorable result.

Each series still completed all 12 workers, 192 adjacent block pairs, 432 serial
commands and 13 verified teardowns, with identical complete rows/SQL/parameters.
Observed sampled peak sums were 661.5, 680.2 and 665.0 MiB. Runtime durations were
45.09, 46.59 and 66.70 seconds. These are not retained-heap measurements.

Two independent allocation profiles, with the unchanged allocation harness and
its original sample counts/settings, measured 141,607 and 141,528 bytes per
operation. Their mean is 141,567 bytes, 20.76% below the frozen baseline and
8,858 bytes below fixed-find. The argument-admission stack now averages 9,216
bytes, versus 18,180 in the parent and 46,646 in the baseline. This supports the
predicted construction reduction on the small fixture; it does not establish
the unmeasured model-width slope or retained-memory improvement.

`direct-orderby-audit.py` verifies source/build identities, all five changed
runtime sources in source maps, copied tests and isolated aliases, completed
differentials/typecheck, profile hashes/options/byte sums, exact benchmark
schedules and paired arithmetic. An invocation while the confirmation receipt
was still partial correctly refused its incomplete worker count; the final
audit after the live command exited passed. The snapshot retains candidate.patch.

Source hash: `d55ab2a122c79448fbbb0963d2528746e9e9a3e1d0a3970e3533ccfa741709ae`.
Build hash: `8c8ac1e02964d9e64943285dddf71d8b7184a0de0e257644b8450d9edd839904`.
Production source remains frozen. The experiment stays isolated and unadopted;
there is no retention/adoption claim, no first-Worker-isolate claim, and no
demonstrated 30-microsecond saving. The full objective remains active.

## Unused schema scaling diagnostic (2026-10-01)

The preceding recommendation-only turn was no progress. This continuation
revalidated active source and both built snapshots by hash, then executed the
proposed size diagnostic against pinned Drizzle 1.0.0-rc.5-5935859 relational
findMany, jit:false. Source remains the frozen baseline. No optimization was
implemented or adopted in this diagnostic.

`schema-scale-fixture.mjs` changes unused user fields, unrelated models, or
user-to-target relations while retaining the exact six-column post model,
rows20 arguments and all 20 returned rows. All variants use one identical
physical schema containing every extra table/column, so SQLite catalog work
does not change between variants. This larger physical database makes absolute
times incomparable to the original goal fixture; these are scaling diagnostics.

The copied `schema-scale-interleaved.mjs` retains independent resident workers,
serial adjacent alternating blocks and bounded teardown. Drizzle client binding
is inside the first-query interval, hence included in setup-plus-query. Six
pairs per variant, 8192 warmups and 2048 measured fresh clients per worker.
All seven smoke checks and 84 measured workers completed. Exact complete rows,
SQL (after only alias/casing normalization) and bound parameters agree. Source,
runtime, shared native dependency, fixture and build hashes agree throughout.
All 91 measured-run teardown receipts passed. No allocation profile ran.

| Unused schema content | VibORM construction µs | Drizzle construction µs | VibORM setup + query µs | Drizzle setup + query µs |
| --- | ---: | ---: | ---: | ---: |
| None | 27.79 | 5.35 | 195.57 | 160.02 |
| 32 scalar fields | 51.13 | 16.76 | 233.13 | 182.17 |
| 128 scalar fields | 105.60 | 49.94 | 288.99 | 214.34 |
| 8 unrelated models | 57.19 | 10.81 | 232.78 | 168.90 |
| 32 unrelated models | 158.79 | 33.37 | 353.43 | 200.90 |
| 8 relations and target models | 77.00 | 19.87 | 255.43 | 187.53 |
| 32 relations and target models | 260.46 | 137.74 | 450.81 | 307.14 |

Each cell is a separate median of six worker means. These are not additive.
Variants were separate campaigns, so their scaling differences are not adjacent
paired estimates and may include machine drift. Relation variants also add
target models and foreign-key scalars; their increase cannot all be assigned
to topology resolution. Block CPU includes connection, result assertions and
cleanup, and does not isolate first-query CPU. Sampled process-group peaks are
resource receipts, not retained memory.

`schema-scale-summary.json` records the seven rows, CPU, paired library deltas,
receipt hashes, counts and resource observations. A Python audit re-derived
phase and paired statistics, checked all 1008 serial command intervals, all
84 workers and their identities, unchanged SQL/results across every variant,
and teardown counts. An independent read-only agent audit found no blocking
fixture mismatch and identified the interpretation limits above.

The evidence shifts attention toward model-count-dependent schema construction;
it does not demonstrate a removable cost or a 30-microsecond improvement on the
original small rows20 case. Prepared but unexecuted allocation and within-library
size harness copies were removed. No verification process remains from this run.
The user's intervening question asks for cumulative gains across the entire
effort, including retained improvements before this goal. Those historical
results must not be confused with an additional gain under this still-active
30-microsecond objective.
