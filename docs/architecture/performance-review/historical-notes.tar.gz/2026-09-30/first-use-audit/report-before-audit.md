# First-use experiments — 2026-09-30

**Outcome: no production change retained.** None of these experiments delivered a safe, repeatable improvement across the targeted small read workloads. The demand-only diagnostic improved the wider fixture by about 4%, with observable compatibility differences. This does not establish a performance ceiling, and does not meet the earlier goal of halving first-use overhead.

## Protocol

- SQLite only; shared model/schema/validation code changed in isolated snapshots.
- Exact runtime: Node 24.21.0 / V8 13.6.233.17-node.53, Apple M4 Pro. Sequential bounded workers; no concurrent benchmarks.
- Five alternating fresh-process pairs per comparison. Fresh-client samples construct new declarations, client and native connection every time; code is warmed, clients and schemas are never reused.
- Initial trials: 400 measured clients after 100 warmups per worker. Confirmation: 800 after 200 warmups; confirmation also includes Drizzle relational `findMany`, pinned 1.0.0-rc.5-5935859, mapper `jit:false`.
- Primary metric: schema/client construction plus first query, excluding the separately measured native connection open. Raw reports also contain continuous wall time, CPU, imports and individual samples.
- Separate fresh-process checks use one client/query and zero warmups. These are local Node/SQLite measurements, not Cloudflare Workers startup measurements.
- Deltas below are the median of paired percentage changes. Negative means faster. MAD is in percentage points. A change must exceed twice MAD to count as a signal; a signal on one workload is not a broad win. Independent medians do not necessarily produce the paired percentage.

## Fresh-client results

| Experiment | Schema | Query | Baseline µs | Candidate µs | Paired wall Δ | MAD | Paired CPU Δ |
|---|---|---|---:|---:|---:|---:|---:|
| One-pass model classification | small | rows20 | 138.09 | 136.03 | -3.99% | 0.56 | -9.05% |
| One-pass model classification | small | filtered20 | 248.83 | 236.20 | -5.08% | 7.28 | +1.12% |
| One-pass model classification | wide | rows20 | 282.16 | 267.32 | -2.43% | 4.53 | -3.54% |
| One-pass model classification | wide | filtered20 | 369.36 | 377.98 | +3.56% | 3.87 | +4.26% |
| Shared construction context (scoped) | small | rows20 | 125.79 | 126.21 | +1.58% | 2.84 | -1.17% |
| Shared construction context (scoped) | small | filtered20 | 229.70 | 232.21 | +4.12% | 3.49 | -1.35% |
| Shared construction context (scoped) | wide | rows20 | 274.24 | 260.64 | -2.15% | 2.05 | -7.49% |
| Shared construction context (scoped) | wide | filtered20 | 360.22 | 364.65 | -1.22% | 3.22 | +1.70% |
| Direct validator lookup | small | rows20 | 140.84 | 140.72 | +0.60% | 0.64 | +1.81% |
| Direct validator lookup | small | filtered20 | 245.27 | 248.64 | -1.21% | 2.87 | -1.09% |
| Direct validator lookup | wide | rows20 | 283.29 | 293.53 | +5.13% | 1.40 | +4.86% |
| Direct validator lookup | wide | filtered20 | 397.56 | 412.41 | +3.74% | 5.79 | +4.31% |
| Demand-only where compilation (diagnostic) | small | rows20 | 118.51 | 123.49 | +6.06% | 7.50 | +10.54% |
| Demand-only where compilation (diagnostic) | small | filtered20 | 236.81 | 234.76 | +7.58% | 10.59 | +5.23% |
| Demand-only where compilation (diagnostic) | wide | rows20 | 273.64 | 259.57 | -4.18% | 1.53 | -2.62% |
| Demand-only where compilation (diagnostic) | wide | filtered20 | 354.61 | 341.42 | -4.31% | 1.17 | -10.09% |

The wide fixture adds 32 unused string fields. Its purpose is to expose schema-width costs, rather than reinterpret it as the common small-model workload.

## What each experiment established

1. **One-pass classification:** computes scalar, relation and unique maps together. Small rows20 showed a roughly 4% first-use gain, but the filtered/wider results did not establish a gain. The explicit getter witness changes model-shape reads from three to one. Ordinary classifications, extension identity and eager refusals passed; that does not erase the observable getter difference. Rejected.
2. **Shared construction context:** removes the second construction of model/table lookup maps during validation and relation resolution. The first prototype retained a context across validation calls; review identified that custom rules receive mutable maps, so the confirmation revision shares it only while invoking the existing overridable resolution boundary, with finally-based restoration. Its longer confirmation does not establish a gain in any of the four workloads. Rejected.
3. **Direct validator lookup:** stores partial-object validators directly in the key map instead of retaining a second positional array. Defaults and public entries still compile normally. Wide rows20 regressed 5.13% (MAD 1.40). Rejected.
4. **Actual demand-only compilation:** goes beyond rearranging metadata. Internal where validation builds validators only for supplied, non-undefined members, skipping the schema-width metadata pass. Wide rows20 and filtered20 improved 4.18% and 4.31%; small results were noisy and did not improve reliably. This optimistic diagnostic changes entry descriptors and ignores a default installed in a public where entry before first validation. The witness records baseline `{name:"defaulted"}` versus candidate `{}`. It is not a safe production change. Rejected.

## Fresh-process cross-check

Setup plus first query, one client per new process, five pairs, no warmup. Imports remain separately recorded.

| Experiment | Query | Baseline µs | Candidate µs | Paired Δ | MAD |
|---|---|---:|---:|---:|---:|
| One-pass model classification | rows20 | 4885.25 | 4636.25 | -6.09% | 2.66 |
| One-pass model classification | filtered20 | 5608.04 | 5656.33 | +1.01% | 3.27 |
| Shared construction context (scoped) | rows20 | 4839.83 | 4605.29 | -2.07% | 4.02 |
| Shared construction context (scoped) | filtered20 | 6018.96 | 6074.83 | +0.42% | 2.23 |
| Direct validator lookup | rows20 | 5007.08 | 4889.58 | +6.03% | 8.37 |
| Direct validator lookup | filtered20 | 6025.46 | 6245.83 | +3.96% | 12.05 |
| Demand-only where compilation (diagnostic) | rows20 | 5070.67 | 4833.54 | -4.99% | 3.65 |
| Demand-only where compilation (diagnostic) | filtered20 | 5889.67 | 5756.92 | -0.33% | 2.80 |

These checks also fail to establish a general cold first-use improvement. Classification improves cold rows20 only; the shape-getter compatibility difference still applies.

## Drizzle relational control

The confirmation runs included the same pinned relational API and matched SQL ordering. These figures are small-schema fresh-client setup plus first query; they are not the earlier warm-operation comparison.

| Confirmation | Query | Baseline VibORM µs | Candidate µs | Drizzle RQB µs |
|---|---|---:|---:|---:|
| Shared construction context (scoped) | rows20 | 125.79 | 126.21 | 67.50 |
| Shared construction context (scoped) | filtered20 | 229.70 | 232.21 | 134.21 |
| Demand-only where compilation (diagnostic) | rows20 | 118.51 | 123.49 | 68.63 |
| Demand-only where compilation (diagnostic) | filtered20 | 236.81 | 234.76 | 133.65 |

## Verification and limits

- All five snapshots built successfully (including the superseded context prototype). Each passed the 12-case existing differential probe covering operation values/refusals, defaults, recursion, public schema type/options/extend, JSON schema, identity and input getter reads.
- Four final candidates passed the construction witness for ordinary/frozen shapes, extension identity, incomplete relations, duplicate tables/model identity, atomic identifier preflight and eager decimal provider refusal. The classification getter mismatch is separately recorded, not counted as compatible.
- Every benchmark sample verifies complete query results. Untimed witnesses capture SQL and parameters, restore the exact native property descriptor and verify stock-path results.
- SQL/parameter witnesses and result digests are identical between baseline and candidate for each tested fixture/workload; this was independently checked across all completed reports.
- No full suite, whole-estate typecheck, allocation profile or retention soak was run for these rejected prototypes. No CPU/memory/Workers benefit is claimed from source simplification alone.
- Active production source was not edited. Existing worktree changes were preserved. Patches and bounded-run logs remain alongside the raw results.

## Evidence

- `classification.patch`, `scans.patch`, `scans-v2.patch`, `validator.patch`, `demand.patch`: complete isolated source changes.
- `*-timing.json`, `*-confirmation.json`, `*-cold.json`: raw samples, runtime/artifact hashes, SQL/result witnesses and paired summaries.
- `construction-witness.log`, `demand-compatibility.log`, `*-differential.log`: executed compatibility evidence.
- `summary.json`: compact fresh-client numbers.
- `build-plan.json`, `timing-plan.json`, `confirmation-plan.json`, `cold-plan.json`: exact sequential campaigns. Run using the pinned Node through `scripts/run-node-safe.mjs` and `council/campaign.mjs`; no installations required.
- `source-seal.json`: source identity and integrated verification.
