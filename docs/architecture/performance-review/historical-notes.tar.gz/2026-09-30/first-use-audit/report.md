# Audit of first-use experiment conclusions

**Correction: the experiments executed the intended code, but the earlier small-effect conclusions are not reliable. The tested ideas remain inconclusive. No production change was retained.**

## Confirmed controls

The recorded artifacts have exact build hashes, matching native SQLite package identities, fresh schema/client/connection construction, sequential worker execution and independently checked complete results. Candidate SQL and parameters match baseline. The relational Drizzle comparison is the intended API. This audit found no evidence of wrong-build execution or accidental client reuse.

## Warmup did not establish a stable timing distribution

The harness performs a fixed number of preliminary clients; it never checks whether timing has stabilized. In the prior scoped-context confirmation, small filtered20 baseline round 0, the four measured 200-client quarter means are: 241.2 µs, 214.2 µs, 193.5 µs, 179.6 µs. The code continued to warm during the measured interval. A warmed client is not reused, but JIT/runtime state still evolves.

These runs measure fresh clients after a specified history of preceding clients. They do not establish a stationary warmed-code distribution, or predict the first request of a new Workers isolate. The separate fresh-process measurements cover a different local Node scenario and had only five pairs.

## Identical-build negative control

Both labels point to the same frozen dist directory and the same artifact hash. There is no implementation difference to explain a persistent delta. The control preserves the old three-arm ordering, Drizzle relational comparator, 800 measured fresh clients, 200 preliminary clients, native module and timing boundaries.

| Control | Schema | Query | Apparent paired change | MAD | Range | Old 2×MAD heuristic passes? |
|---|---|---|---:|---:|---|---|
| six completed rounds before memory guard | small | rows20 | +11.65% | 9.80 pp | -29.50% to +52.05% | no |
| six completed rounds before memory guard | small | filtered20 | +7.91% | 2.23 pp | -6.72% to +10.30% | yes |
| six completed rounds before memory guard | wide | rows20 | +0.25% | 9.99 pp | -19.75% to +37.10% | no |
| six completed rounds before memory guard | wide | filtered20 | +7.09% | 2.57 pp | -7.00% to +30.32% | yes |
| completed focused control | small | filtered20 | -2.28% | 6.81 pp | -23.08% to +10.55% | no |

The broad eight-round control stopped after 73 completed arms when the outer process-group guard sampled 1087.2 MiB against its 1024 MiB limit. The first six rounds contain all 72 expected arms. The table includes all six complete rounds and excludes the incomplete seventh round by completeness, not by timing. The run is not represented as successful. Its log and unfinished raw report are preserved.

A narrower small filtered20 control then completed all eight rounds successfully, with the same guard and protocol. Splitting the report kept sampled process-group memory to 228.5 MiB; no limit was raised.

An apparent +7.91% small filtered20 difference between identical artifacts passed the old heuristic in the first control. The completed focused control yielded -2.28% with 6.81 pp MAD and individual pairs from -23.08% to +10.55%. This is evidence that the protocol/conditions and five-pair heuristic cannot support confident attribution of the earlier 4–5% differences. It does not prove the candidate has exactly zero effect.

## Scope and compatibility corrections

- The construction experiment shared one duplicate SchemaValidator context construction. It did not implement comprehensive consolidation of hydration, decimal-provider and adapter-capability scans. Claiming the entire second direction was tested was too broad.
- Classification’s getter witness proves an observable change from three reads to one. It does not show that an ordinary supported declaration or query fails. Treating the exact read count as an immutable public contract was an assumption, not an established requirement.
- Demand-only validation changed introspection descriptors and omitted a default manually installed by replacing a public where entry before first validation. That is a real differential, but it is not an observed ordinary-query default regression. Supported mutation/reflection contracts need to be established before using this as a categorical rejection.
- Scoped context reuse was faster in all five wide rows20 pairs. The previous chosen threshold did not establish a gain; that is different from establishing that no gain exists. Demand-only compilation likewise had encouraging wide-fixture results that this noisy protocol cannot settle.

## Corrected disposition

Keeping unproven patches out of production was reasonable. Calling all three directions fully tested and rejecting their potential was not justified. The numeric results remain preserved as observations, with their original protocol and limitations. No type safety, allocation, retention or Workers performance conclusion follows from this audit.

Future adoption evidence needs a calibrated A/A control, an explicit target for cold versus steady runtime state, stable measurements for any warm-state claim, workload-bounded report collection, full paired distributions and enough independent repetitions for the expected effect. Passing 2×MAD alone is a necessary local heuristic at most, not statistical confidence. Candidate compatibility must be assessed against supported contracts.

## Evidence

- `identical-build.json` and `.log`: incomplete broad control, including the memory guard failure.
- `identical-build-focused.json` and `.log`: successful narrower eight-round control.
- `control-summary.json`: all complete paired values used above; no pair discarded by speed.
- `report-before-audit.md`: preserved original interpretation.
- `../first-use-three/report.md`: original measurements with the corrected conclusion.
