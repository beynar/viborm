# Remaining Drizzle RC gap: measured causes and next experiments

The remaining gap has three components: fixed operation construction, work per
returned cell, and first-use schema/client construction. The last three branch
and copy reductions barely touch the dominant costs. There is no evidence that
another comparable micro pass will remove a 20–30% warm-read gap.

This analysis uses the copied `drizzle-orm@1.0.0-rc.5-5935859`, with JIT disabled,
and the unchanged candidate from the preceding rerun. Both libraries create
fresh query handles, mappers and native statements on each measured operation.
Drizzle's advantage here does not depend on prepared-query reuse.

**The warm baseline remains the preceding unprofiled rerun.**

| Operation | VibORM wall µs | Drizzle wall µs | Extra wall µs | VibORM slower | Extra allocated KiB/op |
| --- | ---: | ---: | ---: | ---: | ---: |
| Filtered 20 | 94.01 | 86.43 | 7.58 | 8.8% | 16.74 |
| 20 rows | 29.21 | 23.60 | 5.61 | 23.8% | 15.84 |
| 1,000 rows | 371.73 | 305.70 | 66.04 | 21.6% | 61.12 |
| Text-ID findFirst | 18.99 | 14.60 | 4.39 | 30.1% | 14.19 |

These are medians from [rerun.json](../construction-three/rerun.json), not new
unprofiled ORM timings. Text-ID is an ordinary `findFirst`, not `findUnique`.
Allocated bytes describe transient allocation, not retained memory.

The two six-column row workloads differ only in limit. A descriptive two-point
fit gives about 4.38 µs fixed excess plus 61.7 ns per returned row; their allocation
gap similarly fits about 14.91 KiB fixed plus 47.3 bytes per row. This guides
experiments; two points do not establish a causal model.

**1. Temporary INTEGER carriers explain a substantial allocation cost.**

The stock SQLite3 driver calls `safeIntegers(true)` before fetching. The native
binding consequently constructs a V8 BigInt for every INTEGER cell. This fixture
has two such columns, `published` and `views`: 2,000 temporary BigInts on a
1,000-row read. Our decoder turns those into booleans and numbers. Drizzle starts
with native numbers.

The new [native control](native-controls.mjs) holds SQL, bound values, raw array
layout, fresh preparation and the awaited loop constant; only integer transport
changes. Every arm's complete normalized result is checked independently.

| Native fetch | BigInt wall µs | Number wall µs | Paired wall reduction | Lower blocks | Extra sampled allocation |
| --- | ---: | ---: | ---: | ---: | ---: |
| 20 rows | 16.04 | 15.69 | 0.35 µs | 7/8 | 0.79 KiB/op |
| 1,000 rows | 272.45 | 256.62 | 14.81 µs | 8/8 | 42.19 KiB/op |

The allocation differences are differences of arm medians over three sampling
rounds. All three 1,000-row rounds allocated more with BigInts. CPU medians were
274.20 versus 257.65 µs on that workload. These controls omit ORM construction,
decoding, column metadata and ownership proof. They are not an end-to-end
optimization result, and their deltas cannot be assigned as an exact fraction
of a different run's ORM gap.

This is a native SQLite transport opportunity, outside the requested engine-only
change scope, and is not evidence about Cloudflare's provider. Do not disable
safe integers globally. Bigint and fixed-decimal results require exact values;
custom parsers also observe the carrier. A nuance to earlier analysis: strict
`s.int` overflow refusal alone does not require BigInt transport, since rounded
out-of-range int64 values still fail `Number.isSafeInteger`. However, the current
async execution path can observe a changed parser and fall back to borrowed
results. Once transport has rounded an integer, that fallback cannot restore the
original value. A restricted number transport needs a sound execution/ownership
design, not just a scalar-type flag.

Sources: [native dispatch](../../../../src/drivers/sqlite3/index.ts:210),
installed `better-sqlite3/src/util/data.cpp:33–47`, and copied Drizzle
`better-sqlite3/session.js:28`.

**2. The engine does more per-cell work, but closure allocation is not the main growing cost.**

Drizzle's interpreted mapper copies five of the six post fields directly and
converts the boolean. Our compiled reader checks raw absence/null, invokes the
driver and adapter parser chain, applies strict scalar/domain decoding, and
assigns a fresh result field. On 1,000 rows, that is 6,000 cell visits. Scalar
type/list/identifier dispatch is already selected outside the row loop.

The current [CPU profiles](profile-summary.json) put `decodeProjection` at 24.50%
inclusive of VibORM's non-GC sampled time on rows1000. The complete positional
row-structure validator is 2.36% self. These are sampled locations, not additive
wall-time budgets, and Drizzle's different profile denominator cannot be
subtracted from them.

The [allocation attribution](attribution-all.json) is useful for rejecting an
overly broad closure theory:

- `fieldReader` construction samples about 1.0 KiB per operation for both 20
  and 1,000 rows; `compileScalar` is similarly about 0.8–1.0 KiB.
- The inner provider continuation's source frame samples roughly 0.34 versus
  1.09 KiB, not an allocation proportional to thousands of full closure objects.
  V8 can inline or eliminate closures; source syntax alone does not prove heap
  allocation.
- Result object construction grows from about 1.9 to 93.8 KiB, but Drizzle also
  constructs fresh row objects. Native fetch allocation is the largest growing
  source in our profile.

The engine opportunity is fewer dispatch layers within the existing strict
reader owner, not weaker checks. Preserve hook lookup/receiver behavior,
continuation transformations, exception handling, raw null refusal and
physical-versus-carried semantics. The earlier identity-hook bypass failed its
wall-time evaluation; these observations do not justify reinstating it.

Sources: [provider chain](../../../../src/query-engine/raptor3/shared/query.ts:797),
[positional reader](../../../../src/query-engine/raptor3/shared/query.ts:5246),
[scalar wrapper](../../../../src/query-engine/raptor3/shared/query.ts:5322),
and copied Drizzle `utils.js:143–177`.

**3. First-use construction is the larger target for short-lived clients.**

The new [fresh-client comparison](fresh-peer.json) creates a new schema, client,
driver and database for every query. Code/module imports are warm; fixture
seeding, result checks and cleanup are outside the timed phases. Five blocks of
20 paired samples follow 20 warmup pairs per workload.

| Phase | VibORM µs | Drizzle µs |
| --- | ---: | ---: |
| Schema + client, 20-row workload | 346.42 | 90.32 |
| First 20-row query | 542.63 | 230.24 |
| Schema + client, 1,000-row workload | 309.72 | 84.38 |
| First 1,000-row query | 1,461.37 | 870.55 |

Figures are medians of block means. Each of the five blocks favors Drizzle, but
the magnitude varies substantially: first-20-row block means range from
308–707 µs for VibORM and 122–329 µs for Drizzle. Do not treat these as stable
Workers latency estimates. This explicitly reconstructs schemas; it does not
represent a request that keeps module-level schema state, nor a genuinely cold
isolate, nor networked database execution. Connection timing is recorded
separately and uses each library's stock initialization.

The fresh CPU profile corroborates first-use admission and schema construction;
it includes fixture seeding, so its percentages are not first-query shares.
The code exposes specific unnecessary construction:

- `getFindManyArgs` and `getFindFirstArgs` eagerly build the `distinct` enum
  even when no distinct option is supplied. Most sibling options already use
  `lazyRef`. Deferring this schema is a narrow first-use candidate.
- `getArgsSchemas` creates 14 builder closures, `getCoreSchemas` creates 21,
  and `lazyRecord` installs another getter closure for each declared property.
  Unused schemas remain lazy, but their shells still cost construction. The
  existing `LazyScalarSchemas` demonstrates shared accessors with per-instance
  state; an analogous compact representation needs measurement and must keep
  circular resolution, introspection and stable schema identity intact.
- Schema topology/domain validation is real required work. Removing it or
  shifting its errors to a later query would change the contract. Its presence
  in a profile does not make it redundant.

Sources: [read args](../../../../src/validation/model/args/find.ts:169),
[operation shells](../../../../src/validation/model/args/index.ts:91),
[core shells](../../../../src/validation/model/core/index.ts:181),
[lazy storage](../../../../src/validation/lazy.ts:17).

**4. SQL construction has smaller, concrete opportunities.**

VibORM builds explicit aliases for every projected field and renders `WHERE 1`
for unfiltered reads. Native controls, with the same safe-integer mode and `.all`
method on both arms, find the complete Drizzle SQL shape about 1.85 µs cheaper
on rows20 and 2.42 µs on textId. They do not isolate one SQL clause as the cause.
Both row-query shapes use the primary-key index; filtered20 scans and sorts in
both libraries. Query plans and complete native opcodes are retained in
[native-controls.json](native-controls.json).

Removing redundant projection aliases alone saves about 0.36 µs in the native
rows20 control, with lower wall time in 8/8 blocks. Its rows1000 wall result is
not corroborated by lower arm-median CPU, so there is no established scalable
gain. Removing `WHERE 1` or changing single-row `.all` to `.get` produces only
small, mixed-direction results. Removing filtered20's ID tie-break is lower in
only 4/8 blocks, with a median paired delta of 0.075 µs: it does not explain the
current gap and would change behavior on ties.

A safer engine/adapter-wide micro is to retain exactly the existing SQL while
compressing its fragment graph: `identifiers.aliased()` creates an extra raw Sql
child merely to carry an already-quoted alias. Put that text into the parent
fragment's literal segment instead. Six projected columns would create six
fewer Sql nodes and roughly six fewer arrays per operation. This is source-backed
removable work; its full-operation speedup remains unmeasured.

Omitting a truly absent WHERE at the query owner can also remove a true literal
and clause wrapper. Keep actual membership, cursor, filter and identity guards,
including meaningful empty/vacuous predicate behavior. These are smaller
candidates than first-use construction or row decoding.

Sources: [alias fragments](../../../../src/adapters/shared/standard-sql.ts:266),
[selection predicates](../../../../src/query-engine/raptor3/shared/query.ts:3340).

**Recommended order within the engine scope**

1. Target first-use construction: defer the unused distinct schema, then evaluate
   compact operation/core lazy shells. Measure new-client first operations as
   well as warm operations. This fits the short-lived-client goal without
   relying on cross-request caching.
2. For large reads, isolate the strict reader's dispatch cost before changing
   it. Keep decoding and provider hooks authoritative; do not promise recovery
   of the whole 66 µs gap or repeat the discarded hook bypass.
3. Bundle exact-SQL alias-fragment compression and genuinely absent-WHERE
   construction as one small fixed-cost experiment. Expect a small opportunity,
   not an across-the-board 20% gain.
4. Deprioritize correlation accessor allocation, duplicate positional array
   checks, more pagination copies and individual scalar-filter branches. Their
   measured footprints are too small to explain the observed difference.

Filtered20 is a separate limit: native `all` occupies 73.19% of VibORM's current
non-GC sampled profile, while the complete decoder is only 2.31% inclusive.
Its database scan/sort dominates. The earlier three micro changes did not show
a reproducible wall-time gain, and this investigation does not overturn that.

**Evidence and limits**

Four bounded diagnostic campaigns ran: current warm CPU/allocation profiles,
native causal controls, new-client paired timings, and a new-client CPU profile.
Every result fixture was checked; no correctness suite was rerun. Source and
frozen-build hashes remain unchanged. No production optimization was applied.

The native experiment uses eight blocks per contrast, independently randomized
group order, reversed paired arm order, and GC before each arm. Its allocation
rounds are randomized but not perfectly balanced. The earlier ORM baseline's
arm/workload ordering is coupled; its small candidate/baseline differences must
remain qualified. Host load was nonzero throughout. CPU/allocation profiles are
instrumented diagnostic cohorts, not replacement throughput benchmarks.

All execution logs confirm bounded-launcher teardown. Native controls took
13.99 s and 253.5 MiB peak sampled process-group RSS; that RSS is harness-wide,
not per-operation memory. Recorded identities and final source verification are
in [verification.json](verification.json). The native harness records its input
witness bytes and completion-time script hash; it does not claim a before/after
seal of its own script. Three independent source/audit reviews were reconciled
against these artifacts.
