# Engine micro-optimization experiments — 2026-09-30

Kept three narrow changes: compact alias fragments, omit the WHERE/conjunction when every predicate source is absent, and defer the unused `distinct` enum in `findMany`/`findFirst`. The repeatable warm win is the unfiltered 20-row operation. These changes do not close the large-read or filtered20 gap. No query/statement cache or SQLite transport change was introduced.

## Final comparison

Node 24.21.0 / V8 13.6 on Apple M4 Pro, SQLite through the same better-sqlite3 12.6.0 module. Drizzle is the pinned `1.0.0-rc.5-5935859`, interpreted mapper (`jit: false`). Each call constructs a fresh public operation/builder and native statement. Five fresh comparison processes each ran 18 blocks covering all six arm orders; workload order was independently shuffled.

Raw times below are medians of the five process medians. Changes are medians of within-block paired changes, summarized per process, then across processes. These statistics need not equal a percentage calculated from the marginal raw medians. Allocation is separate 4,096-byte V8 sampling over six balanced cohorts, including collected objects; it excludes native allocations and is not retained memory.

| Operation | Before wall µs | After wall µs | Drizzle wall µs | Paired wall change | Paired allocation change |
| --- | ---: | ---: | ---: | ---: | ---: |
| Filtered 20 | 94.53 | 94.76 | 87.75 | +0.37% | -0.11% |
| 20 rows | 29.58 | 29.04 | 23.96 | -2.61% | -4.35% |
| 1,000 rows | 375.58 | 374.75 | 305.87 | -0.09% | -0.16% |
| Text-ID findFirst | 18.81 | 18.71 | 14.61 | -0.61% | -1.61% |

The 20-row wall gain is 2.61% with 0.41 percentage-point MAD across process-level paired medians; all five processes favor the candidate. Its CPU change is −1.79% (MAD 0.42 points). The paired gap relative to Drizzle shrinks by **3.24 percentage points**, but VibORM remains roughly 20% slower on that operation.

Filtered20 is **+0.37% slower**, with 0.21-point MAD. All five process medians have the same direction, so this is disclosed rather than labeled a gain; its magnitude is below 2×MAD. The text-ID wall change is −0.61% with 0.30-point MAD, a much weaker result. The 1,000-row change is within variation. CPU here is process user+system time, including runtime compilation/GC; it is not an isolated engine CPU budget.

| Operation | Before CPU µs | After CPU µs | Drizzle CPU µs | Before allocated KiB/op | After allocated KiB/op | Drizzle allocated KiB/op |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Filtered 20 | 103.41 | 104.16 | 103.54 | 30.94 | 30.83 | 14.59 |
| 20 rows | 34.41 | 34.18 | 33.27 | 33.42 | 31.75 | 17.64 |
| 1,000 rows | 408.22 | 404.37 | 376.52 | 377.89 | 377.11 | 317.14 |
| Text-ID findFirst | 22.81 | 22.60 | 20.36 | 24.51 | 24.06 | 10.13 |

## Experiments and decisions

- **Scalar reader wrapper fusion: rejected.** The separate screen showed essentially unchanged rows1000 wall (−0.06%, MAD 1.07 points) and allocation (−0.15%). Removing a source-level function call did not establish a runtime gain. The existing decoder and strict provider/codec boundaries remain intact.
- **Shared argument/core lazy-shell classes: rejected.** They removed 70 per-instance builder/getter closures and reduced first-preparation allocation by about 13–14% in the causal diagnostic (about 7–8% including new schema/client). First-query wall was unchanged in the full-operation screen; preparation wall remained within variation. The larger typed class/helper rewrite and receiver/lifetime differences were not justified for this pass.
- **Lazy distinct construction: kept.** This is two replacements with the existing `lazyRef` primitive. The enum is built only when supplied; normalization, unknown-field rejection and JSON-schema introspection continue through existing owners.
- **Alias fragment compression: kept.** Already-quoted alias text moves into the parent Sql literal segment. Expressions remain nested Sql values and retain parameter order. It removes one raw Sql child and a net array per alias while preserving emitted SQL.
- **Absent WHERE: kept with the original nonempty construction.** Membership, filter, cursor, identity and explicit condition are all checked. Existing nonempty predicates still go through the original conjunction expression, including false/empty logical predicates. Statement observers see the intentional removal of `WHERE 1`/`WHERE TRUE` on condition-free selects.
- **Dynamic condition-array rewrite: rejected.** The first SQL bundle saved allocation and improved rows20, but filtered20 regressed +0.80% across five processes (MAD 0.35 points). Alias-only and select-only controls did not isolate a single definitive cause; the final narrower variant restores the old nonempty construction and reduces the combined filtered20 movement to +0.37%. We do not claim proof that one array caused the entire regression.

## First-use construction

The distinct-only causal diagnostic creates a new model graph, driver and client, then prepares its first public operation without opening/seeding SQLite. Five fresh processes each use ten blocks of 80 alternating samples per arm and four separate allocation cohorts. Exact SQL/parameter witnesses pass before and after. This separates preparation from database work; it is **process-warmed Node, not Cloudflare isolate startup**.

| Fresh operation | First-preparation wall change | First-preparation allocation change | Schema/client + preparation allocation change |
| --- | ---: | ---: | ---: |
| 20 rows | -1.83% | -5.52% | -1.98% |
| Text-ID findFirst | -2.72% | -3.13% | -1.78% |

First-preparation CPU results were inconsistent; there is no reliable first-use CPU claim. In the final full SQLite first-query cohort, rows20 measured a paired −2.92% wall change over five rounds within one process, but CPU varied widely. This is supporting diagnostic evidence, not an independent five-process full first-query result.

## Correctness and retained memory

- Final focused run: **99 tests passed** in six files covering lazy distinct construction/normalization, identifier quoting and nested parameters in all three dialect renderers, absent/empty/false filters, internal identity/condition guards, SQLite cursor/distinct/nested pagination and filters. The complete native TypeScript check passed. Only SQLite executed database workloads.
- Earlier prototype check: 157 passed / one failed because the experimental shared-shell scalar-update getter passed an incorrect factory argument. That wiring was fixed and the affected seven tests re-passed before measurement; the complete shared-shell prototype was subsequently removed. The decoder placement/list tests passed during screening; the decoder implementation itself was restored.
- Final 200,000-operation soak: post-GC heap ranged **10.06–10.43 MiB**, ending about **0.18 MiB** above its warmed start. All **420** sampled operation/result references and **336** overlap references were collected. Holding 500 handles raised heap to about 20.38 MiB; releasing them returned it to about 10.33 MiB.
- Separate 1,000-client disposal diagnostic: all **5,000** sampled clients, drivers, native wrappers and models were collected. The final 500-client window stayed within **10.765–10.827 MiB**. The earlier 100-client ramp therefore was not treated as proof of continuing growth.
- The already-reported arbitrary-property client proxy cache still retains about **7.69 MiB per 10,000 distinct unknown properties**. It remains excluded at the user’s direction. These bounded probes support no accumulating engine retention in the tested workloads, not a universal leak-free guarantee.

## Evidence and reproduction

The measured baseline was rebuilt from the pre-experiment frozen source with the same packaging flags as the candidates. Old unnormalized build output was not compared. Each comparison seals source, built modules, harness, lockfile and the copied Drizzle installation before and after; all checks passed. The final working source exactly matches the measured final snapshot. Larger discarded prototypes exist only in experiment patches/snapshots.

Host load changed substantially across the exploratory campaign, falling from roughly 23–27 early to lower values during final confirmation. Absolute values from different screens are not compared as an optimization delta. All Node builds, measurements and checks ran serially through the bounded workspace-lock launchers; no coverage process was interrupted. This is a local experiment, not a full operation-pipeline release/adoption gate, and no publication was requested or performed.

- [Final summary](final-summary.json), [first-use summary](first-use-summary.json), and [final source/test patch](final.patch).
- Final raw comparisons: [1](final-confirm-1.json), [2](final-confirm-2.json), [3](final-confirm-3.json), [4](final-confirm-4.json), [5](final-confirm-5.json).
- [Full-operation comparator](compare.mjs), [first-use diagnostic](schema-first-use.mjs), [retention](final-retention.json), [client disposal](final-lifecycle.json).
- [Final focused tests](final-focused.log), [whole-estate typecheck](final-typecheck.log), [verification identities](verification.json).

To repeat the final comparison, use the pinned Node executable with `scripts/run-node-safe.mjs --rss-limit-mb=1024 768 120000`, then `compare.mjs --baseline <normalized-baseline>/dist --candidate <final>/dist --drizzle-dir <pinned-rc5> --output <new-report>.json --allow-sql-change --blocks 18 --allocation-rounds 6 --fresh-rounds 5 --fresh-samples 24`. The exact snapshot and peer paths are embedded in each report’s seal.
